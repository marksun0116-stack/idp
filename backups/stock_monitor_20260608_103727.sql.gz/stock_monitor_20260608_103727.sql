--
-- PostgreSQL database dump
--

\restrict fkFwGrqKthiTvLMcqcw4gH9uCJtg0TiPkCx4ZEHprYevpDPEfb9mgM51fVWZpCn

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO postgres;

--
-- Name: holdings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holdings (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    symbol character varying(20) NOT NULL,
    shares double precision NOT NULL,
    cost_basis double precision,
    purchase_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    manual_price double precision
);


ALTER TABLE public.holdings OWNER TO postgres;

--
-- Name: holdings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.holdings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.holdings_id_seq OWNER TO postgres;

--
-- Name: holdings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.holdings_id_seq OWNED BY public.holdings.id;


--
-- Name: investment_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_accounts (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    account_type character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.investment_accounts OWNER TO postgres;

--
-- Name: investment_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investment_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investment_accounts_id_seq OWNER TO postgres;

--
-- Name: investment_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investment_accounts_id_seq OWNED BY public.investment_accounts.id;


--
-- Name: segment_momentum; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.segment_momentum (
    id bigint NOT NULL,
    snapshot_date date NOT NULL,
    sector character varying(100) NOT NULL,
    gainers_count integer DEFAULT 0 NOT NULL,
    losers_count integer DEFAULT 0 NOT NULL,
    avg_change double precision,
    momentum_score double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.segment_momentum OWNER TO postgres;

--
-- Name: segment_momentum_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.segment_momentum_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.segment_momentum_id_seq OWNER TO postgres;

--
-- Name: segment_momentum_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.segment_momentum_id_seq OWNED BY public.segment_momentum.id;


--
-- Name: stock_alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_alerts (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    symbol character varying(20) NOT NULL,
    alert_type character varying(20) NOT NULL,
    condition character varying(20) NOT NULL,
    target_value double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_stock_alert_condition CHECK (((condition)::text = ANY ((ARRAY['above'::character varying, 'below'::character varying, 'spike'::character varying])::text[]))),
    CONSTRAINT chk_stock_alert_type CHECK (((alert_type)::text = ANY ((ARRAY['price'::character varying, 'rsi'::character varying, 'volume'::character varying])::text[]))),
    CONSTRAINT chk_stock_alert_value CHECK ((target_value > (0)::double precision))
);


ALTER TABLE public.stock_alerts OWNER TO postgres;

--
-- Name: stock_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_alerts_id_seq OWNER TO postgres;

--
-- Name: stock_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_alerts_id_seq OWNED BY public.stock_alerts.id;


--
-- Name: stock_intraday_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_intraday_cache (
    id bigint NOT NULL,
    symbol character varying(20) NOT NULL,
    bar_time bigint NOT NULL,
    trading_date date NOT NULL,
    close double precision NOT NULL,
    high double precision,
    low double precision,
    volume bigint
);


ALTER TABLE public.stock_intraday_cache OWNER TO postgres;

--
-- Name: stock_intraday_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_intraday_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_intraday_cache_id_seq OWNER TO postgres;

--
-- Name: stock_intraday_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_intraday_cache_id_seq OWNED BY public.stock_intraday_cache.id;


--
-- Name: stock_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_metadata (
    symbol character varying(20) NOT NULL,
    company_name character varying(255),
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sector character varying(100),
    industry character varying(200),
    exchange character varying(10),
    ipo_year smallint
);


ALTER TABLE public.stock_metadata OWNER TO postgres;

--
-- Name: stock_price_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_price_history (
    id bigint NOT NULL,
    symbol character varying(20) NOT NULL,
    price_date date NOT NULL,
    close double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    high double precision,
    low double precision,
    volume bigint
);


ALTER TABLE public.stock_price_history OWNER TO postgres;

--
-- Name: stock_price_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_price_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_price_history_id_seq OWNER TO postgres;

--
-- Name: stock_price_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_price_history_id_seq OWNED BY public.stock_price_history.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    create_date timestamp with time zone DEFAULT now() NOT NULL,
    last_modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: watchlist_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.watchlist_items (
    id bigint NOT NULL,
    symbol character varying(32) NOT NULL,
    watchlist_id bigint NOT NULL,
    create_date timestamp with time zone DEFAULT now() NOT NULL,
    last_modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.watchlist_items OWNER TO postgres;

--
-- Name: watchlist_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.watchlist_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watchlist_items_id_seq OWNER TO postgres;

--
-- Name: watchlist_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.watchlist_items_id_seq OWNED BY public.watchlist_items.id;


--
-- Name: watchlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.watchlists (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    create_date timestamp with time zone DEFAULT now() NOT NULL,
    last_modified timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.watchlists OWNER TO postgres;

--
-- Name: watchlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.watchlists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watchlists_id_seq OWNER TO postgres;

--
-- Name: watchlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.watchlists_id_seq OWNED BY public.watchlists.id;


--
-- Name: holdings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings ALTER COLUMN id SET DEFAULT nextval('public.holdings_id_seq'::regclass);


--
-- Name: investment_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts ALTER COLUMN id SET DEFAULT nextval('public.investment_accounts_id_seq'::regclass);


--
-- Name: segment_momentum id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segment_momentum ALTER COLUMN id SET DEFAULT nextval('public.segment_momentum_id_seq'::regclass);


--
-- Name: stock_alerts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_alerts ALTER COLUMN id SET DEFAULT nextval('public.stock_alerts_id_seq'::regclass);


--
-- Name: stock_intraday_cache id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_intraday_cache ALTER COLUMN id SET DEFAULT nextval('public.stock_intraday_cache_id_seq'::regclass);


--
-- Name: stock_price_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_price_history ALTER COLUMN id SET DEFAULT nextval('public.stock_price_history_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: watchlist_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlist_items ALTER COLUMN id SET DEFAULT nextval('public.watchlist_items_id_seq'::regclass);


--
-- Name: watchlists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlists ALTER COLUMN id SET DEFAULT nextval('public.watchlists_id_seq'::regclass);


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	create initial schema	SQL	V1__create_initial_schema.sql	1930131683	postgres	2026-06-08 16:47:57.825078	44	t
2	2	add audit columns	SQL	V2__add_audit_columns.sql	363993966	postgres	2026-06-08 16:47:57.894623	11	t
3	3	create stock price history	SQL	V3__create_stock_price_history.sql	-431181768	postgres	2026-06-08 16:47:57.930208	23	t
4	4	create stock metadata	SQL	V4__create_stock_metadata.sql	-1102660000	postgres	2026-06-08 16:47:57.967279	8	t
5	5	add ohlv to stock price history	SQL	V5__add_ohlv_to_stock_price_history.sql	-69904915	postgres	2026-06-08 16:47:57.98698	6	t
6	6	create investment tables	SQL	V6__create_investment_tables.sql	1715406108	postgres	2026-06-08 16:47:58.007125	48	t
7	7	make cost basis nullable	SQL	V7__make_cost_basis_nullable.sql	-1822550329	postgres	2026-06-08 16:47:58.067985	3	t
8	8	add manual price to holdings	SQL	V8__add_manual_price_to_holdings.sql	1498972982	postgres	2026-06-08 16:47:58.083327	3	t
9	9	add sector to stock metadata	SQL	V9__add_sector_to_stock_metadata.sql	810648263	postgres	2026-06-08 16:47:58.131579	19	t
10	10	create stock intraday cache	SQL	V10__create_stock_intraday_cache.sql	891321199	postgres	2026-06-08 16:47:58.162347	18	t
11	11	create segment momentum	SQL	V11__create_segment_momentum.sql	69191757	postgres	2026-06-08 16:47:58.191658	23	t
12	12	add exchange to stock metadata	SQL	V12__add_exchange_to_stock_metadata.sql	-1808446663	postgres	2026-06-08 16:47:58.225117	3	t
13	13	create stock alerts	SQL	V13__create_stock_alerts.sql	1259008069	postgres	2026-06-08 16:47:58.239332	19	t
\.


--
-- Data for Name: holdings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holdings (id, account_id, symbol, shares, cost_basis, purchase_date, created_at, manual_price) FROM stdin;
1	1	AAPL	3300	4.73	\N	2026-06-08 16:48:55.397569+00	\N
2	1	AMD	900	142.43	\N	2026-06-08 16:48:55.426752+00	\N
3	1	AMZN	200	130.13	\N	2026-06-08 16:48:55.450443+00	\N
4	1	APLD	100	37	\N	2026-06-08 16:48:55.474821+00	\N
5	1	AVGO	5	483	\N	2026-06-08 16:48:55.497623+00	\N
6	1	GOOG	60	189.71	\N	2026-06-08 16:48:55.521352+00	\N
7	1	INTC	50	118.93	\N	2026-06-08 16:48:55.546013+00	\N
8	1	ML DIRECT DEP	11969	1	\N	2026-06-08 16:48:55.571266+00	\N
9	1	MSFT	50	350.5	\N	2026-06-08 16:48:55.596334+00	\N
10	1	NNE	200	28.76	\N	2026-06-08 16:48:55.61918+00	\N
11	1	NVDA	1200	41.1	\N	2026-06-08 16:48:55.648941+00	\N
12	1	OKLO	500	59.01	\N	2026-06-08 16:48:55.670418+00	\N
13	1	QCOM	50	229.36	\N	2026-06-08 16:48:55.690545+00	\N
14	1	RSP	70	147.9	\N	2026-06-08 16:48:55.70979+00	\N
15	1	SMR	1000	11.02	\N	2026-06-08 16:48:55.730237+00	\N
16	1	SOFI	500	9.49	\N	2026-06-08 16:48:55.749772+00	\N
17	1	TSM	100	125.37	\N	2026-06-08 16:48:55.772422+00	\N
18	1	WULF	200	14.7	\N	2026-06-08 16:48:55.797336+00	\N
19	2	APLD	100	10	\N	2026-06-08 16:49:32.118986+00	\N
20	2	BABA	75	100.69	\N	2026-06-08 16:49:32.141742+00	\N
21	2	BIDU	50	77.08	\N	2026-06-08 16:49:32.161388+00	\N
23	2	CRWV	30	105.56	\N	2026-06-08 16:49:32.202809+00	\N
24	2	DELL	10	540.97	\N	2026-06-08 16:49:32.223632+00	\N
25	2	DIS	347	\N	\N	2026-06-08 16:49:32.242551+00	\N
26	2	GLD	100	353.7	\N	2026-06-08 16:49:32.263262+00	\N
27	2	MSFT	100	46.7	\N	2026-06-08 16:49:32.285146+00	\N
28	2	NFLX	150	94.26	\N	2026-06-08 16:49:32.304507+00	\N
29	2	SLV	100	59.36	\N	2026-06-08 16:49:32.329918+00	\N
30	2	TSLA	30	17.68	\N	2026-06-08 16:49:32.352012+00	\N
31	2	WULF	200	9.47	\N	2026-06-08 16:49:32.371592+00	\N
32	2	CASH-DEPOSIT	5611.79	1	\N	2026-06-08 16:52:08.598305+00	1
33	3	AMD	150	114.09	\N	2026-06-08 16:52:43.649847+00	\N
35	3	SMR	1400	15.95	\N	2026-06-08 16:52:43.68618+00	\N
36	3	CASH-DEPOSIT	15023.87	1	\N	2026-06-08 16:53:24.373789+00	1
44	4	APGZX	443.381	105.09	\N	2026-06-08 16:56:19.011137+00	\N
45	4	CDDYX	2257.044	38.57	\N	2026-06-08 16:56:19.027653+00	\N
46	4	FXAIX	202.46	216.79	\N	2026-06-08 16:56:19.043552+00	\N
47	4	RWMGX	671.377	68.63	\N	2026-06-08 16:56:19.059203+00	\N
48	4	VTHRX	1016.723	43.02	\N	2026-06-08 16:56:19.07767+00	\N
43	4	74686Q207	608440.35	1	\N	2026-06-08 16:56:18.993929+00	1
49	5	AMD	300	193.72	\N	2026-06-08 16:57:36.859312+00	\N
51	5	COIN	50	240.25	\N	2026-06-08 16:57:36.894894+00	\N
52	5	CSGP	3	297.86	\N	2026-06-08 16:57:36.909346+00	\N
53	5	FIG	300	37.58	\N	2026-06-08 16:57:36.923409+00	\N
54	5	GLD	700	379.3	\N	2026-06-08 16:57:36.938077+00	\N
55	5	GOOG	50	303.54	\N	2026-06-08 16:57:36.953379+00	\N
56	5	LPCN	236	22.2	\N	2026-06-08 16:57:36.968973+00	\N
57	5	MSFT	100	436.68	\N	2026-06-08 16:57:36.985207+00	\N
58	5	NIO	250	46.95	\N	2026-06-08 16:57:37.000336+00	\N
59	5	NNE	500	37.73	\N	2026-06-08 16:57:37.015435+00	\N
60	5	NVAX	800	46.1	\N	2026-06-08 16:57:37.030916+00	\N
61	5	NVDA	400	186.09	\N	2026-06-08 16:57:37.04617+00	\N
62	5	OKLO	300	109.94	\N	2026-06-08 16:57:37.060851+00	\N
63	5	QQQ	50	628.87	\N	2026-06-08 16:57:37.07678+00	\N
64	5	QS	500	10.16	\N	2026-06-08 16:57:37.092977+00	\N
65	5	SKLZ	50	281.3	\N	2026-06-08 16:57:37.108872+00	\N
66	5	SMR	2500	21.27	\N	2026-06-08 16:57:37.126545+00	\N
67	5	SYRS	438	33.39	\N	2026-06-08 16:57:37.143594+00	\N
50	5	BDP - BANK DEPOSIT	64107.77	1	\N	2026-06-08 16:57:36.879247+00	1
\.


--
-- Data for Name: investment_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_accounts (id, user_id, name, account_type, created_at) FROM stdin;
1	1	ML	BROKERAGE	2026-06-08 16:48:41.452963+00
2	1	F	BROKERAGE	2026-06-08 16:49:12.553931+00
3	1	CS	BROKERAGE	2026-06-08 16:52:26.961674+00
4	1	F - 401K	401K	2026-06-08 16:54:24.586286+00
5	1	C - IRA	IRA	2026-06-08 16:57:20.385828+00
\.


--
-- Data for Name: segment_momentum; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.segment_momentum (id, snapshot_date, sector, gainers_count, losers_count, avg_change, momentum_score, created_at) FROM stdin;
\.


--
-- Data for Name: stock_alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_alerts (id, user_id, symbol, alert_type, condition, target_value, created_at) FROM stdin;
\.


--
-- Data for Name: stock_intraday_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_intraday_cache (id, symbol, bar_time, trading_date, close, high, low, volume) FROM stdin;
\.


--
-- Data for Name: stock_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_metadata (symbol, company_name, updated_at, sector, industry, exchange, ipo_year) FROM stdin;
ALDFW	Aldel Financial II Inc. Warrants	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2024
ANSC	Agriculture & Natural Solutions Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2024
BIOA	BioAge Labs Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
BIRD	Allbirds Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Apparel	Nasdaq	2021
BIVI	BioVie Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
BIVIW	BioVie Inc. Warrant	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
BIXI	Bitcoin Infrastructure Acquisition Corp Ltd. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2025
BIXIU	Bitcoin Infrastructure Acquisition Corp Ltd. Unit	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BIXIW	Bitcoin Infrastructure Acquisition Corp Ltd. Warrant	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2025
BJDX	Bluejay Diagnostics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
BJRI	BJ's Restaurants Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Restaurants	Nasdaq	\N
BKHA	Black Hawk Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
BKHAR	Black Hawk Acquisition Corporation Rights	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
BKNG	Booking Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Transportation Services	Nasdaq	\N
BKR	Baker Hughes Company Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Oil and Gas Field Machinery	Nasdaq	\N
BL	BlackLine Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2016
BLBD	Blue Bird Corporation Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Construction/Ag Equipment/Trucks	Nasdaq	2014
BLFS	BioLife Solutions Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
BLIN	Bridgeline Digital Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2007
BLKB	Blackbaud Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2004
BLLN	BillionToOne Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical Specialities	Nasdaq	2025
BLMN	Bloomin' Brands Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Restaurants	Nasdaq	2012
BLNE	Beeline Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
BLNK	Blink Charging Co. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Industrial Specialties	Nasdaq	\N
BLRK	Bluerock Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BLTE	Belite Bio Inc American Depositary Shares	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
BLUW	Blue Water Acquisition Corp. III Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2025
BLUWW	Blue Water Acquisition Corp. III Warrant.	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2025
BLZE	Backblaze Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
BLZR	Trailblazer Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BLZRU	Trailblazer Acquisition Corp. Unit	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2025
BLZRW	Trailblazer Acquisition Corp. Warrant	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BMBL	Bumble Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
BMEA	Biomea Fusion Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
BMRA	Biomerica Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	\N
BMRC	Bank of Marin Bancorp Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BMRN	BioMarin Pharmaceutical Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1999
BNAI	Brand Engagement Network Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	2021
BNAIW	Brand Engagement Network Inc. Warrant	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	2021
BNBX	BNB Plus Corp. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
BNC	CEA Industries Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
BNCWW	CEA Industries Inc. Warrant	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	\N
BNCWZ	CEA Industries Inc. Warrant	2026-06-08 16:48:03.035838+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
BNGO	Bionano Genomics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2018
BNKK	Bonk Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	2020
BNTC	Benitec Biopharma Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
BNZI	Banzai International Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
BNZIW	Banzai International Inc. Warrant	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
BODI	The Beachbody Company Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
BOF	BranchOut Food Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Staples	Packaged Foods	Nasdaq	2023
BOKF	BOK Financial Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BOLD	Boundless Bio Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
BOLT	Bolt Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
BOOM	DMC Global Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Industrial Specialties	Nasdaq	\N
BOTJ	Bank of the James Financial Group Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BOXL	Boxlight Corporation Class A Common Stock	2026-06-08 16:48:03.035838+00	Real Estate	Other Consumer Services	Nasdaq	2017
BPAC	Blueport Acquisition Ltd Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BPACU	Blueport Acquisition Ltd Units	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BPOP	Popular Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BRTX	BioRestorative Therapies Inc. Common Stock (NV)	2026-06-08 16:48:03.035838+00	Health Care	Managed Health Care	Nasdaq	\N
BRUN	Boost Run Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	\N
BRUNW	Boost Run Inc. Warrant	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	\N
ACAA	Averin Capital Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
BRZE	Braze Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
BSBK	Bogota Financial Corp. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Banks	Nasdaq	2020
BSET	Bassett Furniture Industries Incorporated Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Home Furnishings	Nasdaq	\N
BSRR	Sierra Bancorp Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BSVN	Bank7 Corp. Common stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	2018
BSY	Bentley Systems Incorporated Class B Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
BTAI	BioXcel Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
BTBD	BT Brands Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Restaurants	Nasdaq	2021
BTBDW	BT Brands Inc. Warrant	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Restaurants	Nasdaq	2021
BTBT	Bit Digital Inc. Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	2018
BTCS	BTCS Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
BTMD	Biote Corp. Class A Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
BTOC	Armlogi Holding Corp. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Office Equipment/Supplies/Services	Nasdaq	2024
BTOG	Bit Origin Limited Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	2019
BTSG	BrightSpring Health Services Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Nursing Services	Nasdaq	2024
BTSGU	BrightSpring Health Services Inc. Tangible Equity Unit	2026-06-08 16:48:03.035838+00	Health Care	Medical/Nursing Services	Nasdaq	2024
BULL	Webull Corporation Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
BULLW	Webull Corporation Warrants	2026-06-08 16:48:03.035838+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
BUSE	First Busey Corporation Class A Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BUSEP	First Busey Corporation Depositary Shares Each Representing a 1/40thInterest in a Share of 8.25% Fixed-Rate Series B Non-Cumulative Perpetual Preferred Stock $0.001 par value	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BVFL	BV Financial Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Savings Institutions	Nasdaq	2023
BVS	Bioventus Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
BWB	Bridgewater Bancshares Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	2018
CCNE	CNB Financial Corporation Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CCNEP	CNB Financial Corporation Depositary Shares each representing a 1/40th ownership interest in a share of 7.125% Series A Fixed-Rate Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CCOI	Cogent Communications Holdings Inc.	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	\N
CCRN	Cross Country Healthcare Inc. Common Stock $0.0001 Par Value	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Professional Services	Nasdaq	2001
CCSI	Consensus Cloud Solutions Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
CCXI	Churchill Capital Corp XI Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2026
CDIO	Cardio Diagnostics Holdings Inc. Common stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	2022
CDIOW	Cardio Diagnostics Holdings Inc. Warrant	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	2022
CDLX	Cardlytics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2018
CDNA	CareDx Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical Specialities	Nasdaq	2014
CDNL	Cardinal Infrastructure Group Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Military/Government/Technical	Nasdaq	2025
CDNS	Cadence Design Systems Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
CDT	CDT Equity Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
CDTTW	CDT Equity Inc. Warrant	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
CDW	CDW Corporation Common Stock	2026-06-08 16:48:03.05225+00	Technology	Retail: Computer Software & Peripheral Equipment	Nasdaq	2013
CDXS	Codexis Inc. Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Major Chemicals	Nasdaq	2010
CDZIP	Cadiz Inc. Depositary Shares	2026-06-08 16:48:03.05225+00	Utilities	Water Supply	Nasdaq	\N
CECO	CECO Environmental Corp. Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Pollution Control Equipment	Nasdaq	1998
CEG	Constellation Energy Corporation Common Stock	2026-06-08 16:48:03.05225+00	Utilities	Electric Utilities: Central	Nasdaq	\N
CELC	Celcuity Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical Specialities	Nasdaq	2017
CELH	Celsius Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
CELU	Celularity Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
CELUW	Celularity Inc. Warrant	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
CELZ	Creative Medical Technology Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
CENT	Central Garden & Pet Company Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Consumer Specialties	Nasdaq	1993
CENTA	Central Garden & Pet Company Class A Common Stock Nonvoting	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Consumer Specialties	Nasdaq	\N
CENX	Century Aluminum Company Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Aluminum	Nasdaq	1996
CEPF	Cantor Equity Partners IV Inc. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CEPO	Cantor Equity Partners I Inc. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CEPS	Cantor Equity Partners VI Inc. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2026
CEPT	Cantor Equity Partners II Inc. Class A Ordinary Share	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CEPV	Cantor Equity Partners V Inc. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CERS	Cerus Corporation Common Stock	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	1997
CERT	Certara Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
ALCO	Alico Inc. Common Stock	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	\N
CETX	Cemtrex Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Electrical Products	Nasdaq	\N
CETY	Clean Energy Technologies Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Metal Fabrications	Nasdaq	\N
CEVA	CEVA Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
CFBK	CF Bankshares Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CFFI	C&F Financial Corporation Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CFFN	Capitol Federal Financial Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Savings Institutions	Nasdaq	\N
CG	The Carlyle Group Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Investment Managers	Nasdaq	2012
CGABL	The Carlyle Group Inc. 4.625% Subordinated Notes due 2061	2026-06-08 16:48:03.05225+00	Finance	Investment Managers	Nasdaq	\N
CGBD	Carlyle Secured Lending Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	2017
CGCT	Cartesian Growth Corporation III Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CGCTU	Cartesian Growth Corporation III Unit	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CGCTW	Cartesian Growth Corporation III Warrant	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CGEM	Cullinan Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
CGNX	Cognex Corporation Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Industrial Machinery/Components	Nasdaq	1989
CGO	Calamos Global Total Return Fund Common Stock	2026-06-08 16:48:03.05225+00	Finance	Investment Managers	Nasdaq	2005
CGON	CG Oncology Inc. Common stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
CGTX	Cognition Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
CHAR	Charlton Aria Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2024
CHARR	Charlton Aria Acquisition Corporation Rights	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2024
CHCI	Comstock Holding Companies Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Finance	Real Estate	Nasdaq	2004
CHCO	City Holding Company Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CHDN	Churchill Downs Incorporated Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
CHEF	The Chefs' Warehouse Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Food Distributors	Nasdaq	2011
CHI	Calamos Convertible Opportunities and Income Fund Common Stock	2026-06-08 16:48:03.05225+00	Finance	Investment Managers	Nasdaq	2002
CHMG	Chemung Financial Corp Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CHPG	ChampionsGate Acquisition Corporation Class A Ordinary Share	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CHPGR	ChampionsGate Acquisition Corporation Rights	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CHRD	Chord Energy Corporation Common Stock	2026-06-08 16:48:03.05225+00	Energy	Oil & Gas Production	Nasdaq	\N
CHRN	ChronoScale Corporation Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
CHRS	Coherus Oncology Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2014
CHRW	C.H. Robinson Worldwide Inc. Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Integrated Freight & Logistics	Nasdaq	1997
CHSCL	CHS Inc Class B Cumulative Redeemable Preferred Stock Series 4	2026-06-08 16:48:03.05225+00	Industrials	Farming/Seeds/Milling	Nasdaq	\N
CHSCM	CHS Inc Class B Reset Rate Cumulative Redeemable Preferred Stock Series 3	2026-06-08 16:48:03.05225+00	Industrials	Farming/Seeds/Milling	Nasdaq	\N
CHSCN	CHS Inc Preferred Class B Series 2 Reset Rate	2026-06-08 16:48:03.05225+00	Industrials	Farming/Seeds/Milling	Nasdaq	\N
CHSCO	CHS Inc. Class B Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.05225+00	Industrials	Farming/Seeds/Milling	Nasdaq	\N
CHSCP	CHS Inc. 8%  Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.05225+00	Industrials	Farming/Seeds/Milling	Nasdaq	\N
CHTR	Charter Communications Inc. Class A Common Stock New	2026-06-08 16:48:03.05225+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
CHW	Calamos Global Dynamic Income Fund Common Stock	2026-06-08 16:48:03.05225+00	Finance	Investment Managers	Nasdaq	2007
CHY	Calamos Convertible and High Income Fund Common Stock	2026-06-08 16:48:03.05225+00	Finance	Investment Managers	Nasdaq	2003
CHYM	Chime Financial Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	2025
CIFR	Cipher Digital Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	2020
CINF	Cincinnati Financial Corporation Common Stock	2026-06-08 16:48:03.05225+00	Finance	Property-Casualty Insurers	Nasdaq	\N
CING	Cingulate Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
CINGW	Cingulate Inc. Warrants	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
CISO	CISO Global Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Professional Services	Nasdaq	\N
CIVB	Civista Bancshares Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CJMB	Callan JMB Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Business Services	Nasdaq	2025
CLAR	Clarus Corporation Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
CLBK	Columbia Financial Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Savings Institutions	Nasdaq	2018
CLDX	Celldex Therapeutics Inc.	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	\N
CLFD	Clearfield Inc. Common Stock	2026-06-08 16:48:03.05225+00	Utilities	Telecommunications Equipment	Nasdaq	\N
CLIR	ClearSign Technologies Corporation Common Stock (DE)	2026-06-08 16:48:03.05225+00	Industrials	Industrial Machinery/Components	Nasdaq	2012
CLMB	Climb Global Solutions Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Retail: Computer Software & Peripheral Equipment	Nasdaq	\N
CLMT	Calumet Inc. Common Stock	2026-06-08 16:48:03.05225+00	Energy	Integrated oil Companies	Nasdaq	2006
CLNE	Clean Energy Fuels Corp. Common Stock	2026-06-08 16:48:03.05225+00	Utilities	Natural Gas Distribution	Nasdaq	2007
CLNN	Clene Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CLOV	Clover Health Investments Corp. Class A Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical Specialities	Nasdaq	\N
CLPT	ClearPoint Neuro Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
CLRB	Cellectar Biosciences Inc.  Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ACAAU	Averin Capital Acquisition Corp. Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ATLO	Ames National Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
ATLX	Atlas Lithium Corporation Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	Nasdaq	\N
ATNI	ATN International Inc. Common Stock	2026-06-08 16:48:03.035838+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
ATOM	Atomera Incorporated Common Stock	2026-06-08 16:48:03.035838+00	Technology	Semiconductors	Nasdaq	2016
ATOS	Atossa Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2012
ATRA	Atara Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2014
ATRC	AtriCure Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2005
ATRO	Astronics Corporation Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Military/Government/Technical	Nasdaq	\N
CLRO	ClearOne Inc. Common Stock	2026-06-08 16:48:03.05225+00	Utilities	Telecommunications Equipment	Nasdaq	\N
CLSK	CleanSpark Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
CLSKW	CleanSpark Inc. Warrant	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
CLST	Catalyst Bancorp Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Savings Institutions	Nasdaq	2021
CLYM	Climb Bio Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
CMCO	Columbus McKinnon Corporation Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Construction/Ag Equipment/Trucks	Nasdaq	1996
CMCSA	Comcast Corporation Class A Common Stock	2026-06-08 16:48:03.05225+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
CMCT	Creative Media & Community Trust Corporation Common stock	2026-06-08 16:48:03.05225+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
CME	CME Group Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2002
CMII	Columbus Circle Capital Corp II Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2026
CMIIU	Columbus Circle Capital Corp II Unit	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2026
CMIIW	Columbus Circle Capital Corp II Warrant	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2026
CMPX	Compass Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
CMRC	Commerce.com Inc. Series 1 Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
CMTL	Comtech Telecommunications Corp. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	\N
CMTV	Community Bancorp. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CNDT	Conduent Incorporated Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Business Services	Nasdaq	\N
CNOB	ConnectOne Bancorp Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CNOBP	ConnectOne Bancorp Inc. Depositary Shares each representing a 1/40th interest in a share of 5.25% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CNSP	CNS Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
CNTN	Canton Strategic Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
CNTX	Context Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
CNTY	Century Casinos Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	\N
CNVS	Cineverse Corp. Class A Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Consumer Electronics/Video Chains	Nasdaq	\N
CNXC	Concentrix Corporation Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
CNXN	PC Connection Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	\N
CNXU	Conexeu Sciences Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Industrial Specialties	Nasdaq	\N
COAG	Hemab Therapeutics Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2026
COCH	Envoy Medical Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Industrial Specialties	Nasdaq	2021
COCHW	Envoy Medical Inc Warrant	2026-06-08 16:48:03.05225+00	Health Care	Industrial Specialties	Nasdaq	2021
COCO	The Vita Coco Company Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	2021
COST	Costco Wholesale Corporation Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Department/Specialty Retail Stores	Nasdaq	\N
COYA	Coya Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
CPB	The Campbell's Company Common Stock	2026-06-08 16:48:03.05225+00	Consumer Staples	Packaged Foods	Nasdaq	\N
CPBI	Central Plains Bancshares Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Savings Institutions	Nasdaq	2023
CPHC	Canterbury Park Holding Corporation 'New' Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
CPIX	Cumberland Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2009
CPRT	Copart Inc. (DE) Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	1994
CPRX	Catalyst Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2006
ACAAW	Averin Capital Acquisition Corp. Warrants	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ACAD	ACADIA Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1985
ACDC	ProFrac Holding Corp. Class A Common Stock	2026-06-08 16:48:03.020027+00	Energy	Oilfield Services/Equipment	Nasdaq	2022
ACET	Adicet Bio Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
ACFN	Acorn Energy Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Military/Government/Technical	Nasdaq	\N
ACGC	ACP Holdings Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ACGCU	ACP Holdings Acquisition Corp. Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ACGCW	ACP Holdings Acquisition Corp. Warrants	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ACHC	Acadia Healthcare Company Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical Specialities	Nasdaq	\N
ACHV	Achieve Life Sciences Inc. Common Shares	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	\N
ACIC	American Coastal Insurance Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Property-Casualty Insurers	Nasdaq	\N
ACIW	ACI Worldwide Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
ACLS	Axcelis Technologies Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Industrial Machinery/Components	Nasdaq	2000
ACMR	ACM Research Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	Industrial Machinery/Components	Nasdaq	2017
CPSH	CPS Technologies Corp. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Building Materials	Nasdaq	\N
CPSS	Consumer Portfolio Services Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	1992
CPZ	Calamos Long/Short Equity & Dynamic Income Trust Common Stock	2026-06-08 16:48:03.05225+00	Finance	Trusts Except Educational Religious and Charitable	Nasdaq	2019
CRAI	CRA International Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Other Consumer Services	Nasdaq	1998
CRAN	Crane Harbor Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2026
CRANR	Crane Harbor Acquisition Corp. II Rights	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2026
CRANU	Crane Harbor Acquisition Corp. II Units	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CRAQ	Cal Redwood Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CRAQU	Cal Redwood Acquisition Corp. Units	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CRBP	Corbus Pharmaceuticals Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CRBU	Caribou Biosciences Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
CRCT	Cricut Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	Industrial Machinery/Components	Nasdaq	2021
CRDF	Cardiff Oncology Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
CRDO	Credo Technology Group Holding Ltd Ordinary Shares	2026-06-08 16:48:03.05225+00	Technology	Semiconductors	Nasdaq	2022
CREX	Creative Realities Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	\N
CRIS	Curis Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
CRMD	CorMedix Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CRMT	America's Car-Mart Inc Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	\N
CRNC	Cerence Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
CRNX	Crinetics Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
CROX	Crocs Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Shoe Manufacturing	Nasdaq	2006
CRSR	Corsair Gaming Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer peripheral equipment	Nasdaq	2020
CRUS	Cirrus Logic Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Semiconductors	Nasdaq	1989
CRVL	CorVel Corp. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Specialty Insurers	Nasdaq	\N
CRVO	CervoMed Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CRVS	Corvus Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
CRWD	CrowdStrike Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2019
CRWS	Crown Crafts Inc Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Textiles	Nasdaq	\N
CRWV	CoreWeave Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
CSAI	Cloudastructure Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
ACNB	ACNB Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Major Banks	Nasdaq	\N
CSBR	Champions Oncology Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
CSCO	Cisco Systems Inc. Common Stock (DE)	2026-06-08 16:48:03.05225+00	Telecommunications	Computer Communications Equipment	Nasdaq	1990
CSGP	CoStar Group Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Real Estate	Nasdaq	1998
CSPI	CSP Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	1982
CSQ	Calamos Strategic Total Return Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance Companies	Nasdaq	2004
CSTL	Castle Biosciences Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical Specialities	Nasdaq	2019
CSWC	Capital Southwest Corporation Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Textiles	Nasdaq	\N
CUBWW	Lionheart Holdings Warrant	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2024
CUE	Cue Biopharma Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
CULP	Culp Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Textiles	Nasdaq	\N
CURI	CuriosityStream Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Movies/Entertainment	Nasdaq	2020
CURX	Curanex Pharmaceuticals Inc Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
CV	CapsoVision Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2025
CVBF	CVB Financial Corporation Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
CVCO	Cavco Industries Inc. Common Stock When Issued	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Homebuilding	Nasdaq	\N
CVGI	Commercial Vehicle Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	2004
CVKD	Cadrenal Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
CVLT	Commvault Systems Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2006
CVRX	CVRx Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
CVV	CVD Equipment Corporation Common Stock	2026-06-08 16:48:03.071768+00	Technology	Industrial Machinery/Components	Nasdaq	\N
CWBC	Community West Bancshares Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
CWD	CaliberCos Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Finance	Real Estate	Nasdaq	2023
CXAI	CXApp Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	2021
DERM	Journey Medical Corporation Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
DETX	Liberty Defense Holdings Ltd. Common Shares	2026-06-08 16:48:03.071768+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
DFDV	DeFi Development Corp. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Finance: Consumer Services	Nasdaq	2023
DFDVW	DeFi Development Corp. Warrant	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	\N
DFLI	Dragonfly Energy Holdings Corp. Common Stock (NV)	2026-06-08 16:48:03.071768+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
DFLIW	Dragonfly Energy Holdings Corp. Warrant	2026-06-08 16:48:03.071768+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
DFNS	T3 Defense Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Professional Services	Nasdaq	2020
DFNSW	T3 Defense Inc. Warrants	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Professional Services	Nasdaq	2020
DFTX	Definium Therapeutics Inc. Common Shares	2026-06-08 16:48:03.071768+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
DGICA	Donegal Group Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Finance	Property-Casualty Insurers	Nasdaq	\N
DGICB	Donegal Group Inc. Class B Common Stock	2026-06-08 16:48:03.071768+00	Finance	Property-Casualty Insurers	Nasdaq	1986
DGII	Digi International Inc. Common Stock	2026-06-08 16:48:03.071768+00	Telecommunications	Computer Communications Equipment	Nasdaq	1989
DH	Definitive Healthcare Corp. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
DHC	Diversified Healthcare Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.071768+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
DHCNI	Diversified Healthcare Trust 5.625% Senior Notes due 2042	2026-06-08 16:48:03.071768+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
DHCNL	Diversified Healthcare Trust 6.25% Senior Notes Due 2046	2026-06-08 16:48:03.071768+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
DIBS	1stdibs.com Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2021
DIOD	Diodes Incorporated Common Stock	2026-06-08 16:48:03.071768+00	Technology	Semiconductors	Nasdaq	\N
DJCO	Daily Journal Corp. (S.C.) Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Newspapers/Magazines	Nasdaq	\N
DJT	Trump Media & Technology Group Corp. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2024
DJTWW	Trump Media & Technology Group Corp. Warrants	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
DKNG	DraftKings Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2019
DLHC	DLH Holdings Corp.	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Professional Services	Nasdaq	\N
DLPN	Dolphin Entertainment Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
DLTH	Duluth Holdings Inc. Class B Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	2015
DLTR	Dollar Tree Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Department/Specialty Retail Stores	Nasdaq	1995
DMAA	Drugs Made In America Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2025
DMAAR	Drugs Made In America Acquisition Corp. Rights	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DMAAU	Drugs Made In America Acquisition Corp. Units	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DMAC	DiaMedica Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
DMII	Drugs Made In America Acquisition II Corp. Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DMIIR	Drugs Made In America Acquisition II Corp. Right	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DMIIU	Drugs Made In America Acquisition II Corp. Unit	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2025
DMLP	Dorchester Minerals L.P. Common Units Representing Limited Partnership Interests	2026-06-08 16:48:03.071768+00	Energy	Oil & Gas Production	Nasdaq	\N
DMRC	Digimarc Corporation Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
DNLI	Denali Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2017
DNMX	Dynamix Corporation III Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DNMXU	Dynamix Corporation III Unit	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DNMXW	Dynamix Corporation III Warrants	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DNTH	Dianthus Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
DNUT	Krispy Kreme Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Staples	Food Chains	Nasdaq	2021
DOCU	DocuSign Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1989
DOMH	Dominari Holdings Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
DOMO	Domo Inc. Class B Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2018
DORM	Dorman Products Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
DPZ	Domino's Pizza Inc Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Food Distributors	Nasdaq	2004
DRCT	Direct Digital Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Advertising	Nasdaq	2022
DRDB	Roman DBDR Acquisition Corp. II Ordinary shares	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2025
DRDBU	Roman DBDR Acquisition Corp. II Unit	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
DRDBW	Roman DBDR Acquisition Corp. II Warrants	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2025
DRH	Diamondrock Hospitality Company Common Stock	2026-06-08 16:48:03.071768+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2005
DRMA	Dermata Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
DRMAW	Dermata Therapeutics Inc. Warrant	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
DRVN	Driven Brands Holdings Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Automotive Aftermarket	Nasdaq	2021
DSGN	Design Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
DSGR	Distribution Solutions Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Industrial Specialties	Nasdaq	\N
DSP	Viant Technology Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
DTCX	Datacentrex Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
DTI	Drilling Tools International Corporation Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Oil and Gas Field Machinery	Nasdaq	2021
DTIL	Precision BioSciences Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
DTSQ	DT Cloud Star Acquisition Corporation Ordinary Shares	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
DTSQR	DT Cloud Star Acquisition Corporation Right	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
DTSQU	DT Cloud Star Acquisition Corporation Units	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
DTST	Data Storage Corporation Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
DUOL	Duolingo Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
DUOT	Duos Technologies Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
DWSN	Dawson Geophysical Company Common Stock	2026-06-08 16:48:03.071768+00	Energy	Oil & Gas Production	Nasdaq	\N
DWTX	Dogwood Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
DXCM	DexCom Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Dental Instruments	Nasdaq	2005
DXLG	Destination XL Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	\N
DXPE	DXP Enterprises Inc. Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
DXR	Daxor Corporation Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
DYAI	Dyadic International Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
DYN	Dyne Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
DYNC	Dynamix Corporation Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
DYOR	Insight Digital Partners II Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DYORW	Insight Digital Partners II Warrants	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
EA	Electronic Arts Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
EBAY	eBay Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Business Services	Nasdaq	1998
EBC	Eastern Bankshares Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Savings Institutions	Nasdaq	2020
EBMT	Eagle Bancorp Montana Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	2010
ECBK	ECB Bancorp Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Banks	Nasdaq	2022
ECOR	electroCore Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2018
ECPG	Encore Capital Group Inc Common Stock	2026-06-08 16:48:03.071768+00	Finance	Finance Companies	Nasdaq	\N
EDBL	Edible Garden AG Incorporated Common Stock	2026-06-08 16:48:03.071768+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	2022
EDBLW	Edible Garden AG Incorporated Warrant	2026-06-08 16:48:03.071768+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	2022
EDIT	Editas Medicine Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2016
EDSA	Edesa Biotech Inc. Common Shares	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
EDUC	Educational Development Corporation Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Consumer Specialties	Nasdaq	\N
EEFT	Euronet Worldwide Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	1997
EEIQ	EpicQuest Education Group International Limited Common Stock	2026-06-08 16:48:03.071768+00	Real Estate	Other Consumer Services	Nasdaq	2021
EFOI	Energy Focus Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Building Products	Nasdaq	\N
EFSC	Enterprise Financial Services Corporation Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
EFSCP	Enterprise Financial Services Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of 5% Fixed Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
EFSI	Eagle Financial Services Inc Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
CBK	Commercial Bancgroup Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	2025
CBLL	CeriBell Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2024
CBNK	Capital Bancorp Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	2018
CBRL	Cracker Barrel Old Country Store Inc Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Restaurants	Nasdaq	1981
CBRS	Cerebras Systems Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	Semiconductors	Nasdaq	2026
CBSH	Commerce Bancshares Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CBUS	Cibus Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Agricultural Chemicals	Nasdaq	2017
CCAP	Crescent Capital BDC Inc. Common stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
CCAQ	Collective Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CCAQU	Collective Acquisition Corp. Units	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CCAQW	Collective Acquisition Corp. Warrants	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
CCB	Coastal Financial Corporation Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	2018
CCBG	Capital City Bank Group Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
EGAN	eGain Corporation Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1999
EGBN	Eagle Bancorp Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
EHTH	eHealth Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Specialty Insurers	Nasdaq	2006
EIKN	Eikon Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2026
ELAB	PMGC Holdings Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
ELDN	Eledon Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
ELMT	The Elmet Group Co. Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Metal Fabrications	Nasdaq	2026
ELSE	Electro-Sensors Inc. Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
EMIS	Emmis Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
EML	Eastern Company (The) Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Industrial Machinery/Components	Nasdaq	\N
EMPD	Empery Digital Inc. Common stock	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2021
ENPH	Enphase Energy Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Semiconductors	Nasdaq	2012
ENSC	Ensysce Biosciences Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ENSG	The Ensign Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Hospital/Nursing Management	Nasdaq	2007
ENTA	Enanta Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
ENTG	Entegris Inc. Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Plastic Products	Nasdaq	2000
ENVB	Enveric Biosciences Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ENVX	Enovix Corporation Common Stock	2026-06-08 16:48:03.071768+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
EOLS	Evolus Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
EOSE	Eos Energy Enterprises Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
EPSN	Epsilon Energy Ltd. Common Share	2026-06-08 16:48:03.071768+00	Energy	Oil & Gas Production	Nasdaq	\N
EQIX	Equinix Inc. Common Stock REIT	2026-06-08 16:48:03.071768+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2000
EQPT	EquipmentShare.com Inc Class A Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	2026
ERAS	Erasca Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
ERIE	Erie Indemnity Company Class A Common Stock	2026-06-08 16:48:03.071768+00	Finance	Specialty Insurers	Nasdaq	\N
ERII	Energy Recovery Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Industrial Machinery/Components	Nasdaq	2008
ERNA	Ernexa Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ESCA	Escalade Incorporated Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
ESLA	Estrella Immunopharma Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
ESLAW	Estrella Immunopharma Inc. Warrant	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
ESOA	Energy Services of America Corporation Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Water Sewer Pipeline Comm & Power Line Construction	Nasdaq	\N
ESPR	Esperion Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
ESQ	Esquire Financial Holdings Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Commercial Banks	Nasdaq	2017
ETON	Eton Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
ETS	Elite Express Holding Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Trucking Freight/Courier Services	Nasdaq	2025
ACNT	Ascent Industries Co. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Steel/Iron Ore	Nasdaq	\N
ACON	Aclarion Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical Specialities	Nasdaq	2022
ACONW	Aclarion Inc. Warrant	2026-06-08 16:48:03.020027+00	Health Care	Medical Specialities	Nasdaq	2022
ACRS	Aclaris Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
ACRV	Acrivon Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
ACT	Enact Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Finance	Specialty Insurers	Nasdaq	2021
ACTG	Acacia Research Corporation (Acacia Tech) Common Stock	2026-06-08 16:48:03.020027+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
ACTU	Actuate Therapeutics Inc. Common stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
ACXP	Acurx Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
ADAC	American Drive Acquisition Company Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ADACW	American Drive Acquisition Company Warrant	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ADAM	Adamas Trust Inc. Common Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAMG	Adamas Trust Inc. 9.125% Senior Notes Due 2030	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAMH	Adamas Trust Inc. 9.875% Senior Notes Due 2030	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAMI	Adamas Trust Inc. 9.125% Senior Notes Due 2029	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAML	Adamas Trust Inc. 6.875% Series F Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock $0.01 par value per share	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
EU	enCore Energy Corp. Common Shares	2026-06-08 16:48:03.071768+00	Basic Materials	Other Metals and Minerals	Nasdaq	\N
EURK	Eureka Acquisition Corp Class A Ordinary Share	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
EURKR	Eureka Acquisition Corp Right	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
EURKU	Eureka Acquisition Corp Unit	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
EVCM	EverCommerce Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
EVER	EverQuote Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2018
EVGO	EVgo Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
EVGOW	EVgo Inc. Warrants	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
EVLV	Evolv Technologies Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer peripheral equipment	Nasdaq	2020
EVLVW	Evolv Technologies Holdings Inc. Warrant	2026-06-08 16:48:03.071768+00	Technology	Computer peripheral equipment	Nasdaq	2020
EVOX	Evolution Global Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
EVOXU	Evolution Global Acquisition Corp Units	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
EVOXW	Evolution Global Acquisition Corp Warrants	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
EVRG	Evergy Inc. Common Stock	2026-06-08 16:48:03.071768+00	Utilities	Power Generation	Nasdaq	\N
EVTV	Envirotech Vehicles Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
EWBC	East West Bancorp Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
EWTX	Edgewise Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
EXC	Exelon Corporation Common Stock	2026-06-08 16:48:03.071768+00	Utilities	Power Generation	Nasdaq	\N
EXE	Expand Energy Corporation Common Stock	2026-06-08 16:48:03.071768+00	Energy	Oil & Gas Production	Nasdaq	\N
EXEL	Exelixis Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2000
EXFY	Expensify Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
EXLS	ExlService Holdings Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Business Services	Nasdaq	2006
EXOZ	eXoZymes Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
EXPE	Expedia Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Transportation Services	Nasdaq	\N
EXPO	Exponent Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Professional Services	Nasdaq	\N
EXTR	Extreme Networks Inc. Common Stock	2026-06-08 16:48:03.071768+00	Telecommunications	Computer Communications Equipment	Nasdaq	1999
EXYN	Exyn Technologies Inc. Common Stock	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2026
EXYNW	Exyn Technologies Inc. Warrant	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2026
EYE	National Vision Holdings Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Ophthalmic Goods	Nasdaq	2017
CDZI	CADIZ Inc. Common Stock	2026-06-08 16:48:03.05225+00	Utilities	Water Supply	Nasdaq	\N
EYPT	EyePoint Inc. Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	\N
EZPW	EZCORP Inc. Class A Non Voting Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	1991
EZRA	Reliance Global Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Specialty Insurers	Nasdaq	\N
FA	First Advantage Corporation Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	2021
FABC	Fabric.AI Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	\N
FACT	FACT II Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
FACTU	FACT II Acquisition Corp. Unit	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2024
FACTW	FACT II Acquisition Corp. Warrant	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2024
FANG	Diamondback Energy Inc. Common Stock	2026-06-08 16:48:03.071768+00	Energy	Oil & Gas Production	Nasdaq	2012
FAST	Fastenal Company Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	1987
FBLA	FB Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Banks	Nasdaq	2024
FBLG	FibroBiologics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
FBNC	First Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	1987
FBRX	Forte Biosciences Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
FBYD	Falcon's Beyond Global Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
FBYDW	Falcon's Beyond Global Inc. Warrants	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
FCAP	First Capital Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	\N
FCBC	First Community Bankshares Inc. (VA) Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FCCO	First Community Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FCEL	FuelCell Energy Inc. Common Stock	2026-06-08 16:48:03.090451+00	Energy	Industrial Machinery/Components	Nasdaq	\N
FCFS	FirstCash Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	1991
FCNCA	First Citizens BancShares Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FCNCN	First Citizens BancShares Inc. Depositary Shares each representing a 1/40th interest in a share of 6.625% Non-Cumulative Perpetual Preferred Stock Series E	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FCNCO	First Citizens BancShares Inc. 5.625% Non-Cumulative Perpetual Preferred Stock Series C	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FCNCP	First Citizens BancShares Inc. Depositary Shares	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FCUV	Focus Universal Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
FDBC	Fidelity D & D Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FDMT	4D Molecular Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
FDSB	Fifth District Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	2024
FDUS	Fidus Investment Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Finance/Investors Services	Nasdaq	2011
FEAM	5E Advanced Materials Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	Nasdaq	\N
FEED	ENvue Medical Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Industrial Specialties	Nasdaq	\N
FEIM	Frequency Electronics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Electrical Products	Nasdaq	\N
FGBI	First Guaranty Bancshares Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	\N
FGBIP	First Guaranty Bancshares Inc. 6.75% Series A Fixed-Rate Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	\N
FGI	FGI Industries Ltd. Ordinary Shares	2026-06-08 16:48:03.090451+00	Industrials	Industrial Specialties	Nasdaq	2022
FGII	FG Imperii Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
FGIIU	FG Imperii Acquisition Corp. Units	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
FGIIW	FG Imperii Acquisition Corp. Warrants	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
FGIWW	FGI Industries Ltd. Warrant	2026-06-08 16:48:03.090451+00	Industrials	Industrial Specialties	Nasdaq	2022
FGMC	FG Merger II Corp. Common stock	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
FGMCR	FG Merger II Corp. Rights	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
FGMCU	FG Merger II Corp. Unit	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
FGNX	FG Nexus Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Property-Casualty Insurers	Nasdaq	2014
FGNXP	FG Nexus Inc. 8.00% Cumulative Preferred Stock	2026-06-08 16:48:03.090451+00	Finance	Property-Casualty Insurers	Nasdaq	\N
FHB	First Hawaiian Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	2016
FHTX	Foghorn Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
FIBK	First Interstate BancSystem Inc. Common Stock (DE)	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	2010
FIEE	FiEE Inc Common Stock	2026-06-08 16:48:03.090451+00	Utilities	Telecommunications Equipment	Nasdaq	\N
FIGX	FIGX Capital Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
FIGXU	FIGX Capital Acquisition Corp. Units	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2025
FIGXW	FIGX Capital Acquisition Corp. Warrant	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
FINW	FinWise Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	2021
FIP	FTAI Infrastructure Inc. Common Stock	2026-06-08 16:48:03.090451+00	Energy	Oil Refining/Marketing	Nasdaq	\N
FISI	Financial Institutions Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	1999
FISV	Fiserv Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Business Services	Nasdaq	1986
FITB	Fifth Third Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FITBI	Fifth Third Bancorp Depositary Shares	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FITBM	Fifth Third Bancorp Depositary Shares Representing a 1/40th Ownership Interest in a Share of 6.875% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series M	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FITBO	Fifth Third Bancorp Depositary Shares each representing a 1/1000th ownership interest in a share of Non-Cumulative Perpetual Preferred Stock Series K	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FITBP	Fifth Third Bancorp Depositary Shares each representing 1/40th share of Fifth Third 6.00% Non-Cumulative Perpetual Class B Preferred Stock Series A	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FIVE	Five Below Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Department/Specialty Retail Stores	Nasdaq	2012
FIVN	Five9 Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	EDP Services	Nasdaq	2014
FIZZ	National Beverage Corp. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
FKWL	Franklin Wireless Corp. Common Stock	2026-06-08 16:48:03.090451+00	Utilities	Telecommunications Equipment	Nasdaq	\N
FLD	Fold Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	2025
FLDDW	Fold Holdings Inc. Warrant	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	2025
FLGT	Fulgent Genetics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical Specialities	Nasdaq	2016
FLL	Full House Resorts Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	\N
FLNA	Filana Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
FLNC	Fluence Energy Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
FLNT	Fluent Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Advertising	Nasdaq	\N
FLUX	Flux Power Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
FLWS	1-800-FLOWERS.COM Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	1999
FLXS	Flexsteel Industries Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Home Furnishings	Nasdaq	\N
FLY	Firefly Aerospace Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Military/Government/Technical	Nasdaq	2025
FLYE	Fly-E Group Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Aerospace	Nasdaq	2024
FLYW	Flywire Corporation Voting Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Business Services	Nasdaq	2021
FMAC	Future Money Acquisition Corporation Ordinary Shares	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
FMACU	Future Money Acquisition Corporation Units	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
FMAO	Farmers & Merchants Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	\N
FMBH	First Mid Bancshares Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FMNB	Farmers National Banc Corp. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FNGR	FingerMotion Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
FNKO	Funko Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	2017
FNLC	First Bancorp Inc  (ME) Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FNRN	First Northern Community Bancorp Common stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	\N
FNWB	First Northwest Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Banks	Nasdaq	2015
FNWD	Finward Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FONR	Fonar Corporation Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	1981
FORM	FormFactor Inc. FormFactor Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Semiconductors	Nasdaq	2003
FORR	Forrester Research Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Diversified Commercial Services	Nasdaq	1996
FOSL	Fossil Group Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Consumer Specialties	Nasdaq	1993
FOX	Fox Corporation Class B Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Broadcasting	Nasdaq	\N
FOXA	Fox Corporation Class A Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Broadcasting	Nasdaq	\N
FOXF	Fox Factory Holding Corp. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Motor Vehicles	Nasdaq	2013
FOXX	Foxx Development Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Telecommunications	Computer Communications Equipment	Nasdaq	\N
FOXXW	Foxx Development Holdings Inc. Warrant	2026-06-08 16:48:03.090451+00	Telecommunications	Computer Communications Equipment	Nasdaq	\N
FRAF	Franklin Financial Services Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FRBA	First Bank Common Stock	2026-06-08 16:48:03.090451+00	Finance	Commercial Banks	Nasdaq	2013
FRD	Friedman Industries Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Steel/Iron Ore	Nasdaq	\N
FRGT	Freight Technologies Inc. Ordinary Shares	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Professional Services	Nasdaq	2017
FRME	First Merchants Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FRMEP	First Merchants Corporation Depository Shares	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FRMI	Fermi Inc. Common Stock	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2025
FRMM	Forum Markets Incorporated Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
FROG	JFrog Ltd. Ordinary Shares	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
FRPH	FRP Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Real Estate	Nasdaq	\N
FRPT	Freshpet Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Staples	Packaged Foods	Nasdaq	2014
FRSH	Freshworks Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
FRST	Primis Financial Corp. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	2006
FRVO	Fervo Energy Company Class A common stock	2026-06-08 16:48:03.090451+00	Utilities	Electric Utilities: Central	Nasdaq	2026
FSBC	Five Star Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	2021
FSBW	FS Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Banks	Nasdaq	2012
FSEA	First Seacoast Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Savings Institutions	Nasdaq	2019
FSHP	Flag Ship Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2024
FSHPU	Flag Ship Acquisition Corp. Unit	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2024
FSLR	First Solar Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Semiconductors	Nasdaq	2006
FSLY	Fastly Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
FSTR	L.B. Foster Company Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Metal Fabrications	Nasdaq	\N
FSUN	FirstSun Capital Bancorp Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FTRE	Fortrea Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical Specialities	Nasdaq	\N
FULC	Fulcrum Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
DBCAW	D. Boral Acquisition I Corp. Warrants	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2026
DBGI	Digital Brands Group Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	2025
DBX	Dropbox Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2018
DCGO	DocGo Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Nursing Services	Nasdaq	2020
DCOY	Decoy Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
DCTH	Delcath Systems Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
DDOG	Datadog Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2019
FULT	Fulton Financial Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FULTP	Fulton Financial Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of Fixed Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FUNC	First United Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FUND	Sprott Focus Trust Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Investment Managers	Nasdaq	\N
FUSB	First US Bancshares Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FUSE	Fusemachines Inc. Common stock	2026-06-08 16:48:03.090451+00	Technology	EDP Services	Nasdaq	\N
FUSEW	Fusemachines Inc. Warrants	2026-06-08 16:48:03.090451+00	Technology	EDP Services	Nasdaq	\N
FVAV	Fortress Value Acquisition Corp. V Class A Ordinary Shares	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2026
FVCB	FVCBankcorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FWDI	Forward Industries Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Plastic Products	Nasdaq	\N
FWONA	Liberty Media Corporation Series A Liberty Formula One Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Broadcasting	Nasdaq	\N
FWONK	Liberty Media Corporation Series C Liberty Formula One Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Broadcasting	Nasdaq	\N
FWRD	Forward Air Corporation Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Integrated Freight & Logistics	Nasdaq	\N
FWRG	First Watch Restaurant Group Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Restaurants	Nasdaq	2021
FXACU	FortuneX Acquisition Corporation Units	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
FXNC	First National Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
GABC	German American Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
GAIA	Gaia Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Movies/Entertainment	Nasdaq	1999
GAIN	Gladstone Investment Corporation Business Development Company	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	2005
GAING	Gladstone Investment Corporation 7.125% Notes due 2031	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GAINI	Gladstone Investment Corporation 7.875% Notes due 2030	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GAINZ	Gladstone Investment Corporation 4.875% Notes due 2028	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GALT	Galectin Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
GAME	GameSquare Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
GANX	Gain Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
GBDC	Golub Capital BDC Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	2010
GBFH	GBank Financial Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Commercial Banks	Nasdaq	\N
GBLI	Global Indemnity Group LLC Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Property-Casualty Insurers	Nasdaq	\N
GCBC	Greene County Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Banks	Nasdaq	\N
GCGRU	General Catalyst Global Resilience Merger Corp. Units	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2026
GCMG	GCM Grosvenor Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Investment Managers	Nasdaq	\N
GCT	GigaCloud Technology Inc Class A Ordinary Shares	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2022
GCTK	GlucoTrack Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
GDC	GD Culture Group Limited Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Steel/Iron Ore	Nasdaq	2015
GDRX	GoodRx Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Technology	EDP Services	Nasdaq	2020
GDYN	Grid Dynamics Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2018
GECC	Great Elm Capital Corp. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GECCG	Great Elm Capital Corp. 7.75% Notes Due 2030	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GECCH	Great Elm Capital Corp. 8.125% Notes Due 2029	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	\N
GECCI	Great Elm Capital Corp. 8.50% NOTES DUE 2029	2026-06-08 16:48:03.090451+00	Finance	Finance Companies	Nasdaq	\N
GEG	Great Elm Group Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
GEGGL	Great Elm Group Inc.  7.25% Notes due 2027	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
GEHC	GE HealthCare Technologies Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical Electronics	Nasdaq	\N
GEMI	Gemini Space Station Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2025
GEN	Gen Digital Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
GENB	Generate Biomedicines Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2026
ADAMM	Adamas Trust Inc. 7.875% Series E Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAMN	Adamas Trust Inc. 8.00% Series D Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAMO	Adamas Trust Inc. 9.250% Senior Notes Due 2031	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADAMZ	Adamas Trust Inc. 7.000% Series G Cumulative Redeemable Preferred Stock $0.01 par value per share	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
ADBE	Adobe Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1986
ADEA	Adeia Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2003
ADGM	Adagio Medical Holdings Inc Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
ADI	Analog Devices Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	\N
ADIL	Adial Pharmaceuticals Inc Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
ADMA	ADMA Biologics Inc Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
ADP	Automatic Data Processing Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Diversified Commercial Services	Nasdaq	\N
ADPT	Adaptive Biotechnologies Corporation Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
ADSK	Autodesk Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
ADTN	ADTRAN Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Utilities	Telecommunications Equipment	Nasdaq	1994
ADTX	Aditxt Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
ADUS	Addus HomeCare Corporation Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Nursing Services	Nasdaq	2009
ADV	Advantage Solutions Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Business Services	Nasdaq	2019
AEHR	Aehr Test Systems Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Electrical Products	Nasdaq	1997
AEI	Alset Inc. Common Stock (TX)	2026-06-08 16:48:03.020027+00	Finance	Real Estate	Nasdaq	2020
AEIS	Advanced Energy Industries Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Industrial Machinery/Components	Nasdaq	1995
AEMD	Aethlon Medical Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
AENT	Alliance Entertainment Holding Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Durable Goods	Nasdaq	\N
AENTW	Alliance Entertainment Holding Corporation Warrant	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Durable Goods	Nasdaq	\N
AEP	American Electric Power Company Inc. Common Stock	2026-06-08 16:48:03.020027+00	Utilities	Electric Utilities: Central	Nasdaq	\N
AERT	Aeries Technology Inc. Class A Ordinary Share	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Professional Services	Nasdaq	2021
AERTW	Aeries Technology Inc. Warrant	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Professional Services	Nasdaq	2021
AEVA	Aeva Technologies Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
GENK	GEN Restaurant Group Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Restaurants	Nasdaq	2023
AEYE	AudioEye Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
GENVR	Gen Digital Inc. Contingent Value Rights	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
GEOS	Geospace Technologies Corporation Common Stock (Texas)	2026-06-08 16:48:03.090451+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
GERN	Geron Corporation Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1996
GEVO	Gevo Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Major Chemicals	Nasdaq	2011
GFS	GlobalFoundries Inc. Ordinary Shares	2026-06-08 16:48:03.090451+00	Technology	Semiconductors	Nasdaq	2021
GGRP	The Glimpse Group Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	EDP Services	Nasdaq	2021
GH	Guardant Health Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical Specialities	Nasdaq	2018
GIFT	Giftify Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	\N
GIII	G-III Apparel Group LTD. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Apparel	Nasdaq	1989
GILD	Gilead Sciences Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	1992
GIPR	Generation Income Properties Inc. Common Stock	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
GIW	GigCapital8 Corp. Class A Ordinary Shares	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
GIWWR	GigCapital8 Corp. Rights	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
GIX	GigCapital9 Corp. Class A Ordinary Share	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
GIXXR	GigCapital9 Corp. Rights	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
GIXXU	GigCapital9 Corp. Units	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2026
GLAD	Gladstone Capital Corporation Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Textiles	Nasdaq	2001
GLIBA	Liberty Capital Corporation Series A GCI Group Common Stock	2026-06-08 16:48:03.090451+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
GLIBK	Liberty Capital Corporation Series C GCI Group Common Stock	2026-06-08 16:48:03.090451+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
GLND	Greenland Energy Company Common Stock	2026-06-08 16:48:03.090451+00	Energy	Oil & Gas Production	Nasdaq	\N
GLNDW	Greenland Energy Company Warrant	2026-06-08 16:48:03.090451+00	Energy	Oil & Gas Production	Nasdaq	\N
GLOO	Gloo Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Technology	EDP Services	Nasdaq	2025
GLPI	Gaming and Leisure Properties Inc. Common Stock	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
GLSI	Greenwich LifeSciences Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
GLUE	Monte Rosa Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
GLXY	Galaxy Digital Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
GNLN	Greenlane Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Durable Goods	Nasdaq	2019
GNLX	Genelux Corporation Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
GNPX	Genprex Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
GNSS	Genasys Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Staples	Consumer Electronics/Appliances	Nasdaq	\N
GNTX	Gentex Corporation Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
GO	Grocery Outlet Holding Corp. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Staples	Food Chains	Nasdaq	2019
GOAI	Eva Live Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
GOCO	GoHealth Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Specialty Insurers	Nasdaq	2020
GOGO	Gogo Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	2013
GOOD	Gladstone Commercial Corporation Real Estate Investment Trust	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate	Nasdaq	2003
GOODN	Gladstone Commercial Corporation 6.625% Series E Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate	Nasdaq	\N
GOODO	Gladstone Commercial Corporation 6.00% Series G Cumulative Redeemable Preferred Stock par value $0.001 per share	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate	Nasdaq	\N
GOOG	Alphabet Inc. Class C Capital Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2004
GOOGL	Alphabet Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2004
GOSS	Gossamer Bio Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
GOVX	GeoVax Labs Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
GPAC	General Purpose Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2026
GPACW	General Purpose Acquisition Corp. Warrant	2026-06-08 16:48:03.090451+00	Industrials	Major Chemicals	Nasdaq	2026
GPAT	GP-Act III Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2024
GPATU	GP-Act III Acquisition Corp. Units	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2024
GPATW	GP-Act III Acquisition Corp. Warrants	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2024
GPCR	Structure Therapeutics Inc. American Depositary Shares	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
GPRE	Green Plains Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Major Chemicals	Nasdaq	\N
GPRO	GoPro Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Industrial Machinery/Components	Nasdaq	2014
GRAL	GRAIL Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical Specialities	Nasdaq	\N
GRDX	GridAI Technologies Corp. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
GREE	Greenidge Generation Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GREEL	Greenidge Generation Holdings Inc. 8.50% Senior Notes due 2026	2026-06-08 16:48:03.090451+00	Finance	Finance: Consumer Services	Nasdaq	\N
GRI	GRI Bio Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
GRML	Greenland Mines Ltd. Common Stock	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2022
GRMLW	Greenland Mines Ltd Warrant	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2022
GROW	U.S. Global Investors Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Investment Managers	Nasdaq	\N
GRPN	Groupon Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Advertising	Nasdaq	2011
AFBI	Affinity Bancshares Inc. Common Stock (MD)	2026-06-08 16:48:03.020027+00	Finance	Banks	Nasdaq	2017
DYNCU	Dynamix Corporation Unit	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
GRWG	GrowGeneration Corp. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	\N
GSAT	Globalstar Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	2025
GSBC	Great Southern Bancorp Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	1989
GSHD	Goosehead Insurance Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Finance	Specialty Insurers	Nasdaq	2018
GSHR	Gesher Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
GSHRW	Gesher Acquisition Corp. II Warrants	2026-06-08 16:48:03.090451+00	Finance	Blank Checks	Nasdaq	2025
GSIT	GSI Technology Common Stock	2026-06-08 16:48:03.090451+00	Technology	Semiconductors	Nasdaq	2007
GSRF	GSR IV Acquisition Corp. Class A ordinary share	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
GSRFR	GSR IV Acquisition Corp. Rights	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2025
GSRVU	GSR V Acquisition Corp. Units	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2026
GT	The Goodyear Tire & Rubber Company Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Automotive Aftermarket	Nasdaq	\N
HBAN	Huntington Bancshares Incorporated Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HHS	Harte Hanks Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Advertising	Nasdaq	\N
HIFS	Hingham Institution for Savings Common Stock	2026-06-08 16:48:03.10371+00	Finance	Banks	Nasdaq	\N
HIND	Vyome Holdings Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2016
HIT	Health In Tech Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Finance	Specialty Insurers	Nasdaq	2024
HLIT	Harmonic Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	1995
HLMN	Hillman Solutions Corp. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Industrial Machinery/Components	Nasdaq	2020
HLNE	Hamilton Lane Incorporated Class A Common Stock	2026-06-08 16:48:03.10371+00	Finance	Investment Managers	Nasdaq	2017
HLXC	Helix Acquisition Corp. III Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
HMH	HMH Holding Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Oil and Gas Field Machinery	Nasdaq	2026
HNNA	Hennessy Advisors Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Investment Managers	Nasdaq	\N
HNNAZ	Hennessy Advisors Inc. 4.875% Notes due 2026	2026-06-08 16:48:03.10371+00	Finance	Investment Managers	Nasdaq	\N
HNRG	Hallador Energy Company Common Stock	2026-06-08 16:48:03.10371+00	Energy	Coal Mining	Nasdaq	\N
HNST	The Honest Company Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2021
HNVR	Hanover Bancorp Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	2022
HOFT	Hooker Furnishings Corporation Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Home Furnishings	Nasdaq	\N
HOLO	MicroCloud Hologram Inc. Ordinary Shares	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
HOLOW	MicroCloud Hologram Inc. Warrant	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
HON	Honeywell International Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Aerospace	Nasdaq	\N
HOOD	Robinhood Markets Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2021
HOPE	Hope Bancorp Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HOUR	Hour Loop Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2022
HOVNP	Hovnanian Enterprises Inc Dep Shr Srs A Pfd	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Homebuilding	Nasdaq	\N
HOVR	New Horizon Aircraft Ltd. Class A Ordinary Share	2026-06-08 16:48:03.10371+00	Industrials	Aerospace	Nasdaq	2023
HOVRW	New Horizon Aircraft Ltd. Warrant	2026-06-08 16:48:03.10371+00	Industrials	Aerospace	Nasdaq	2023
HOWL	Werewolf Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
HPK	HighPeak Energy Inc. Common Stock	2026-06-08 16:48:03.10371+00	Energy	Oil & Gas Production	Nasdaq	\N
HQI	HireQuest Inc. Common Stock (DE)	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Professional Services	Nasdaq	\N
HQY	HealthEquity Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Business Services	Nasdaq	2014
HRMY	Harmony Biosciences Holdings Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
HROW	Harrow Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
HRTX	Heron Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
HRZN	Horizon Technology Finance Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Finance: Consumer Services	Nasdaq	2010
HSCS	HeartSciences Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Industrial Specialties	Nasdaq	2022
HSDT	Solana Company Class A Common Stock (DE)	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
HSIC	Henry Schein Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical Specialities	Nasdaq	1995
HSPT	Horizon Space Acquisition II Corp. Ordinary share	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
HSPTR	Horizon Space Acquisition II Corp. Right	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
HSPTU	Horizon Space Acquisition II Corp. Units	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2024
HST	Host Hotels & Resorts Inc. Common Stock	2026-06-08 16:48:03.10371+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
HSTM	HealthStream Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2000
HTFL	Heartflow Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2025
HTLD	Heartland Express Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Trucking Freight/Courier Services	Nasdaq	1986
HTO	H2O America Common Stock	2026-06-08 16:48:03.10371+00	Utilities	Water Supply	Nasdaq	\N
HTZ	Hertz Global Holdings Inc Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Rental/Leasing Companies	Nasdaq	\N
HTZWW	Hertz Global Holdings Inc Warrant	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Rental/Leasing Companies	Nasdaq	\N
HUBG	Hub Group Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Integrated Freight & Logistics	Nasdaq	1996
HUMA	Humacyte Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
AFCG	Advanced Flower Capital Inc. Common Stock	2026-06-08 16:48:03.020027+00	Finance	Real Estate	Nasdaq	2021
ERNAW	Ernexa Therapeutics Inc. Warrants	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	\N
FFIV	F5 Inc. Common Stock	2026-06-08 16:48:03.090451+00	Telecommunications	Computer Communications Equipment	Nasdaq	1999
HUMAW	Humacyte Inc. Warrant	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
HURA	TuHURA Biosciences Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
HURC	Hurco Companies Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
HURN	Huron Consulting Group Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Professional Services	Nasdaq	2004
HUT	Hut 8 Corp. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Finance: Consumer Services	Nasdaq	\N
HVII	Hennessy Capital Investment Corp. VII Ordinary Shares	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
HVIIU	Hennessy Capital Investment Corp. VII Unit	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
HVMC	Highview Merger Corp. Class A Ordinary Share	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
HVMCW	Highview Merger Corp. Warrants	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
HWBK	Hawthorn Bancshares Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HWC	Hancock Whitney Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HWCPZ	Hancock Whitney Corporation 6.25% Subordinated Notes due 2060	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HWH	HWH International Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Other Pharmaceuticals	Nasdaq	2022
HWKN	Hawkins Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Specialty Chemicals	Nasdaq	\N
HYFM	Hydrofarm Holdings Group Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Consumer Specialties	Nasdaq	2020
HYMC	Hycroft Mining Holding Corporation Class A Common Stock	2026-06-08 16:48:03.10371+00	Basic Materials	Precious Metals	Nasdaq	2018
HYNE	Hoyne Bancorp Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Banks	Nasdaq	2025
HYPD	Hyperion DeFi Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
HYPR	Hyperfine Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2021
IAC	IAC Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
IACO	Idea Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IACOU	Idea Acquisition Corp. Units	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IACOW	Idea Acquisition Corp. Warrants	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IACQU	Irenic Acquisition Corp. Unit	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IART	Integra LifeSciences Holdings Corporation Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
IBAC	IB Acquisition Corp. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2024
IBACR	IB Acquisition Corp. Right	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2024
IBCP	Independent Bank Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
IBIO	iBio Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
IBKR	Interactive Brokers Group Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2019
IBOC	International Bancshares Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
IBRX	ImmunityBio Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2015
ICCC	ImmuCell Corporation Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	1987
ICFI	ICF International Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Professional Services	Nasdaq	2006
ICHR	Ichor Holdings Ordinary Shares	2026-06-08 16:48:03.10371+00	Technology	Semiconductors	Nasdaq	2016
ICMB	Investcorp Credit Management BDC Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Finance: Consumer Services	Nasdaq	2014
ICU	SeaStar Medical Holding Corporation Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
ICUCW	SeaStar Medical Holding Corporation Warrant	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
ICUI	ICU Medical Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	1992
IDACU	Iron Dome Acquisition I Corp. Units	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
IDAI	T Stamp Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
IDCC	InterDigital Inc. Common Stock	2026-06-08 16:48:03.10371+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
IDN	Intellicheck Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1999
IDXX	IDEXX Laboratories Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	1991
IDYA	IDEAYA Biosciences Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
IEAG	Infinite Eagle Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IEAGR	Infinite Eagle Acquisition Corp. Rights	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IEAGU	Infinite Eagle Acquisition Corp. Unit	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
IEP	Icahn Enterprises L.P. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
IESC	IES Holdings Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Engineering & Construction	Nasdaq	\N
IGAC	Invest Green Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
IGACU	Invest Green Acquisition Corporation Units	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
III	Information Services Group Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Professional Services	Nasdaq	\N
IIIV	i3 Verticals Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2018
IKT	Inhibikase Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
ILLR	Triller Group Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Investment Managers	Nasdaq	2019
ILLRW	Triller Group Inc. Warrant	2026-06-08 16:48:03.10371+00	Finance	Investment Managers	Nasdaq	2019
AFJK	Aimei Health Technology Co. Ltd Ordinary Share	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2024
AFJKR	Aimei Health Technology Co. Ltd Right	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2024
AFJKU	Aimei Health Technology Co. Ltd Unit	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2023
AFRM	Affirm Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Finance	Finance: Consumer Services	Nasdaq	2021
AGEN	Agenus Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2000
AGIO	Agios Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
AGNC	AGNC Investment Corp. Common Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2008
AGNCL	AGNC Investment Corp. Depositary Shares Each Representing a 1/1000th Interest in a Share of 7.75% Series G Fixed-Rate Reset Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
AGNCM	AGNC Investment Corp. Depositary Shares rep 6.875% Series D Fixed-to-Floating Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
AGNCN	AGNC Investment Corp. Depositary Shares Each Representing a 1/1000th Interest in a Share of 7.00% Series C Fixed-To-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
AGNCO	AGNC Investment Corp. Depositary Shares each representing a 1/1000th interest in a share of 6.50% Series E Fixed-to-Floating Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
AGNCP	AGNC Investment Corp. Depositary Shares Each Representing a 1/1000th Interest in a Share of 6.125% Series F Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
AGNCZ	AGNC Investment Corp. Depositary Shares Each Representing a 1/1000th Interest in a Share of 8.75% Series H Fixed-Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	\N
AGNT	eXp World Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Finance	Real Estate	Nasdaq	\N
AGPU	Axe Compute Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Industrial Specialties	Nasdaq	\N
AGYS	Agilysys Inc. Common Stock (DE)	2026-06-08 16:48:03.020027+00	Technology	EDP Services	Nasdaq	\N
AHCO	AdaptHealth Corp. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Nursing Services	Nasdaq	2018
AIAI	AIAI Holdings Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	EDP Services	Nasdaq	\N
AIDX	20/20 Biolabs Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Precision Instruments	Nasdaq	\N
AIFA	All In FutureTech Alliance Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2017
AIFC	AI Financial Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Finance: Consumer Services	Nasdaq	\N
AIFF	Firefly Neuroscience Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
AIMD	Ainos Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer peripheral equipment	Nasdaq	\N
AIMDW	Ainos Inc. Warrants	2026-06-08 16:48:03.020027+00	Technology	Computer peripheral equipment	Nasdaq	\N
AIOT	PowerFleet Inc. Common Stock	2026-06-08 16:48:03.020027+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
ILLU	Illumination Acquisition Corp I Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2026
ILLUU	Illumination Acquisition Corp I Units	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
ILLUW	Illumination Acquisition Corp I Warrant	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
ILMN	Illumina Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical Specialities	Nasdaq	2000
ILPT	Industrial Logistics Properties Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.10371+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2018
IMA	ImageneBio Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
IMDX	Insight Molecular Diagnostics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	\N
IMKTA	Ingles Markets Incorporated Class A Common Stock	2026-06-08 16:48:03.10371+00	Consumer Staples	Food Chains	Nasdaq	1987
IMMR	Immersion Corporation Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer peripheral equipment	Nasdaq	1999
IMMX	Immix Biopharma Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
IMNM	Immunome Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
IMNN	Imunon Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
IMRX	Immuneering Corporation Class A Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
IMSR	Terrestrial Energy Inc. Common Stock	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2024
IMSRW	Terrestrial Energy Inc. Warrant	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2024
IMUX	Immunic Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
IMVT	Immunovant Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
IMXI	International Money Express Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Business Services	Nasdaq	2017
INAB	IN8bio Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
INACR	Indigo Acquisition Corp. Right	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
INACU	Indigo Acquisition Corp. Unit	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
INBK	First Internet Bancorp Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
INBKZ	First Internet Bancorp 6.0% Fixed-to-Floating Rate Subordinated Notes Due 2029	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
INBS	Intelligent Bio Solutions Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2020
INBX	Inhibrx Biosciences Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
INCY	Incyte Corp. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	\N
INDB	Independent Bank Corp. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
INDI	indie Semiconductor Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Technology	Semiconductors	Nasdaq	\N
INDP	Indaptus Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
INGN	Inogen Inc Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Industrial Specialties	Nasdaq	2014
INHD	Inno Holdings Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Steel/Iron Ore	Nasdaq	2023
INKT	MiNK Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
INMB	INmune Bio Inc. Common stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
INNV	InnovAge Holding Corp. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Nursing Services	Nasdaq	2021
INO	Inovio Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
INOD	Innodata Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	EDP Services	Nasdaq	1993
INSE	Inspired Entertainment Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2014
INSG	Inseego Corp. Common Stock	2026-06-08 16:48:03.10371+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
INSM	Insmed Incorporated Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
INTA	Intapp Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
INTC	Intel Corporation Common Stock	2026-06-08 16:48:03.10371+00	Technology	Semiconductors	Nasdaq	\N
INTG	Intergroup Corporation (The) Common Stock	2026-06-08 16:48:03.10371+00	Real Estate	Building operators	Nasdaq	\N
INTS	Intensity Therapeutics Inc. Common stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2023
INTU	Intuit Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1993
INTZ	Intrusion Inc. Common Stock	2026-06-08 16:48:03.10371+00	Telecommunications	Computer Communications Equipment	Nasdaq	\N
INV	Innventure Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	\N
INVA	Innoviva Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2004
INVE	Identiv Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer peripheral equipment	Nasdaq	\N
IONS	Ionis Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
IOSP	Innospec Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Major Chemicals	Nasdaq	\N
IOVA	Iovance Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
IPAR	Interparfums Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	\N
IPCX	Inflection Point Acquisition Corp. III Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
IPCXR	Inflection Point Acquisition Corp. III Rights	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
IPDN	Professional Diversity Network Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2013
IPEX	Inflection Point Acquisition Corp. V Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
IPEXR	Inflection Point Acquisition Corp. V Rights	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
IPFX	Inflection Point Acquisition Corp. VI Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IPFXU	Inflection Point Acquisition Corp. VI Units	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IPFXW	Inflection Point Acquisition Corp. VI Warrant	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
IPGP	IPG Photonics Corporation Common Stock	2026-06-08 16:48:03.10371+00	Technology	Semiconductors	Nasdaq	2006
IPM	Intelligent Protection Management Corp. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
IPSC	Century Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
IPST	IP Strategy Holdings Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	2024
IPW	iPower Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	2021
IPWR	Ideal Power Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Semiconductors	Nasdaq	2013
IPX	IperionX Limited American Depositary Share	2026-06-08 16:48:03.10371+00	Basic Materials	Other Metals and Minerals	Nasdaq	\N
IQST	iQSTEL Inc. Common Stock	2026-06-08 16:48:03.10371+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
IRD	Opus Genetics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
IRDM	Iridium Communications Inc Common Stock	2026-06-08 16:48:03.10371+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
IRHO	Iron Horse Acquisitions II Corp. Common Stock	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
IRHOR	Iron Horse Acquisitions Corp. II Rights	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
IRHOU	Iron Horse Acquisitions II Corp. Units	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2025
IRIX	IRIDEX Corporation Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	1996
IRMD	iRadimed Corporation Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2014
IRON	Disc Medicine Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
IRTC	iRhythm Holdings Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2016
IRWD	Ironwood Pharmaceuticals Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2010
ISBA	Isabella Bank Corporation Common stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
ISPC	iSpecimen Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2021
ISPR	Ispire Technology Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	2023
ISRG	Intuitive Surgical Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Industrial Specialties	Nasdaq	2000
ISSC	Innovative Solutions and Support Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	EDP Services	Nasdaq	2000
ISTR	Investar Holding Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	2014
ITHA	ITHAX Acquisition Corp III Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
ITHAW	ITHAX Acquisition Corp III Warrants	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
ITIC	Investors Title Company Common Stock	2026-06-08 16:48:03.10371+00	Finance	Specialty Insurers	Nasdaq	\N
ITRI	Itron Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Electrical Products	Nasdaq	1993
IVDA	Iveda Solutions Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
IVDAW	Iveda Solutions Inc. Warrant	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
KEQU	Kewaunee Scientific Corporation Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Medical Specialities	Nasdaq	\N
KFFB	Kentucky First Federal Bancorp Common Stock	2026-06-08 16:48:03.119395+00	Finance	Savings Institutions	Nasdaq	2005
KFII	K&F Growth Acquisition Corp. II Class A Ordinary shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
KFIIR	K&F Growth Acquisition Corp. II Rights	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
KFIIU	K&F Growth Acquisition Corp. II Unit	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
KGEI	Kolibri Global Energy Inc. Common stock	2026-06-08 16:48:03.119395+00	Energy	Oil & Gas Production	Nasdaq	\N
KHC	The Kraft Heinz Company Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Packaged Foods	Nasdaq	\N
KIDS	OrthoPediatrics Corp. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	2017
KIDZ	Classover Holdings Inc. Class B Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Other Consumer Services	Nasdaq	\N
KIDZW	Classover Holdings Inc. Warrants	2026-06-08 16:48:03.119395+00	Real Estate	Other Consumer Services	Nasdaq	\N
KINS	Kingstone Companies Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Property-Casualty Insurers	Nasdaq	\N
KITT	Nauticus Robotics Inc. Common stock	2026-06-08 16:48:03.119395+00	Industrials	Industrial Machinery/Components	Nasdaq	2021
KITTW	Nauticus Robotics Inc. Warrant	2026-06-08 16:48:03.119395+00	Industrials	Industrial Machinery/Components	Nasdaq	2021
KLAC	KLA Corporation Common Stock	2026-06-08 16:48:03.119395+00	Technology	Electronic Components	Nasdaq	1980
KLRA	Kailera Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2026
KLRS	Kalaris Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
KLTR	Kaltura Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
KLXE	KLX Energy Services Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Energy	Oilfield Services/Equipment	Nasdaq	\N
KMB	Kimberly-Clark Corporation Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Containers/Packaging	Nasdaq	\N
KMTS	Kestra Medical Technologies Ltd. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	2025
KNSA	Kiniksa Pharmaceuticals International plc Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
KOD	Kodiak Sciences Inc Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
KOPN	Kopin Corporation Common Stock	2026-06-08 16:48:03.119395+00	Technology	Semiconductors	Nasdaq	1992
KOSS	Koss Corporation Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Consumer Electronics/Appliances	Nasdaq	\N
KOYN	CSLM Digital Asset Acquisition Corp III Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
KOYNU	CSLM Digital Asset Acquisition Corp III Units	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
KOYNW	CSLM Digital Asset Acquisition Corp III Warrants	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
KPLT	Katapult Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	2019
KPLTW	Katapult Holdings Inc. Warrant	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	2019
KPRX	Kiora Pharmaceuticals Inc.  Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
KPTI	Karyopharm Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
KRAQW	KRAKacquisition Corp Warrants	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2026
KRMD	KORU Medical Systems Inc. Common Stock (DE)	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
KRNY	Kearny Financial Corp Common Stock	2026-06-08 16:48:03.119395+00	Finance	Savings Institutions	Nasdaq	2005
KROS	Keros Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
KRRO	Korro Bio Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
KRT	Karat Packaging Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Plastic Products	Nasdaq	2021
KRUS	Kura Sushi USA Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Restaurants	Nasdaq	2019
KRYS	Krystal Biotech Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2017
KSCP	Knightscope Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Telecommunications Equipment	Nasdaq	2022
KTCC	Key Tronic Corporation Common Stock	2026-06-08 16:48:03.119395+00	Technology	Electrical Products	Nasdaq	1983
KTOS	Kratos Defense & Security Solutions Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Military/Government/Technical	Nasdaq	\N
KTTA	Pasithea Therapeutics Corp. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
KTTAW	Pasithea Therapeutics Corp. Warrant	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
KURA	Kura Oncology Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
KUST	Kustom Entertainment Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	\N
KVAC	Keen Vision Acquisition Corporation Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2023
KVACW	Keen Vision Acquisition Corporation Warrant	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2023
KVHI	KVH Industries Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	1996
KYMR	Kymera Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
KYNB	Kyntra Bio Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
KYTX	Kyverna Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
LAB	Standard BioTools Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2011
LABT	Lakewood-Amedex Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LAKE	Lakeland Industries Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Industrial Specialties	Nasdaq	1986
LAMR	Lamar Advertising Company Class A Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Real Estate Investment Trusts	Nasdaq	1996
LAND	Gladstone Land Corporation Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Real Estate Investment Trusts	Nasdaq	1993
LANDO	Gladstone Land Corporation 6.00% Series B Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.119395+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
LANDP	Gladstone Land Corporation 6.00% Series C Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.119395+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
LARK	Landmark Bancorp Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
LASE	Laser Photonics Corporation Common Stock	2026-06-08 16:48:03.119395+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2022
LASR	nLIGHT Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Semiconductors	Nasdaq	2018
LATA	Galata Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LATAU	Galata Acquisition Corp. II Units	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
LATAW	Galata Acquisition Corp. II Warrant	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LAUR	Laureate Education Inc. Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Other Consumer Services	Nasdaq	2017
LBRDA	Liberty Broadband Corporation Class A Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
LBRDK	Liberty Broadband Corporation Class C Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
LBRDP	Liberty Broadband Corporation Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
LBRX	LB Pharmaceuticals Inc Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
LCCC	Lakeshore Acquisition III Corp. Ordinary Shares	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LCCCR	Lakeshore Acquisition III Corp. Rights	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LCCCU	Lakeshore Acquisition III Corp. Unit	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LCID	Lucid Group Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Auto Manufacturing	Nasdaq	\N
LCNB	LCNB Corporation Common Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
LCUT	Lifetime Brands Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Industrial Machinery/Components	Nasdaq	1991
LE	Lands' End Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	\N
LECO	Lincoln Electric Holdings Inc. Common Shares	2026-06-08 16:48:03.119395+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
LEE	Lee Enterprises Incorporated Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Newspapers/Magazines	Nasdaq	\N
LEGH	Legacy Housing Corporation Common Stock (TX)	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Homebuilding	Nasdaq	2018
LEGN	Legend Biotech Corporation American Depositary Shares	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
LENZ	LENZ Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
LESL	Leslie's Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2020
LFAC	Leapfrog Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2026
LFACW	Leapfrog Acquisition Corporation Warrants	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2026
LFCR	Lifecore Biomedical Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LFMD	LifeMD Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Nursing Services	Nasdaq	\N
LFMDP	LifeMD Inc. 8.875% Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Nursing Services	Nasdaq	\N
LFST	LifeStance Health Group Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Nursing Services	Nasdaq	2021
LFUS	Littelfuse Inc. Common Stock	2026-06-08 16:48:03.119395+00	Energy	Electrical Products	Nasdaq	\N
DBRG^J	DigitalBridge Group Inc. 7.125% Series J	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
AIP	Arteris Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	2021
AIRE	reAlpha Tech Corp. Common Stock	2026-06-08 16:48:03.020027+00	Finance	Real Estate	Nasdaq	\N
AIRG	Airgain Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	2016
AIRJ	AirJoule Technologies Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Industrial Machinery/Components	Nasdaq	2022
AIRJW	AirJoule Technologies Corporation Warrant	2026-06-08 16:48:03.020027+00	Industrials	Industrial Machinery/Components	Nasdaq	2022
AIRO	AIRO Group Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Aerospace	Nasdaq	2025
AIRS	AirSculpt Technologies Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Nursing Services	Nasdaq	2021
AIRT	Air T Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	\N
AIRTP	Air T Inc. Air T Funding Alpha Income Trust Preferred Securities	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	\N
AISP	Airship AI Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
AISPW	Airship AI Holdings Inc. Warrants	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
AIXC	AIxCrypto Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
AKAM	Akamai Technologies Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Business Services	Nasdaq	1999
AKBA	Akebia Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
AKTS	Aktis Oncology Inc. Common stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2026
ALAB	Astera Labs Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	2024
ALBT	Avalon GloboCare Corp. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
ALDF	Aldel Financial II Inc. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2024
ALDFU	Aldel Financial II Inc. Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2024
GTBP	GT Biopharma Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LFVN	Lifevantage Corporation Common Stock (Delaware)	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LGIH	LGI Homes Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Homebuilding	Nasdaq	2013
LGN	Legence Corp. Class A Common stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Engineering & Construction	Nasdaq	2025
LGND	Ligand Pharmaceuticals Incorporated Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LGVN	Longeveron Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
LHAI	Linkhome Holdings Inc. Common stock	2026-06-08 16:48:03.119395+00	Finance	Real Estate	Nasdaq	2025
LIDR	AEye Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	2021
LIDRW	AEye Inc. Warrant	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	2021
LIEN	Chicago Atlantic BDC Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Finance: Consumer Services	Nasdaq	2022
LIF	Life360 Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	EDP Services	Nasdaq	2024
LIFE	Ethos Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Finance	Specialty Insurers	Nasdaq	2026
LILA	Liberty Latin America Ltd. Class A Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
LILAK	Liberty Latin America Ltd. Class C Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
LILPV	Liberty Latin America Ltd. 9.0% Fixed Rate Cumulative Perpetual Redeemable Series A Preference Shares	2026-06-08 16:48:03.119395+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
LIMN	Liminatus Pharma Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	\N
LIN	Linde plc Ordinary Shares	2026-06-08 16:48:03.119395+00	Basic Materials	Major Chemicals	Nasdaq	\N
LINC	Lincoln Educational Services Corporation Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Other Consumer Services	Nasdaq	2005
LIND	Lindblad Expeditions Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Transportation Services	Nasdaq	2013
LINE	Lineage Inc. Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2024
ALDX	Aldeyra Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
GTEN	Gores Holdings X Inc. Class A ordinary shares	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
GTENU	Gores Holdings X Inc. Units	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
GTENW	Gores Holdings X Inc. Warrants	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
GTIM	Good Times Restaurants Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Restaurants	Nasdaq	\N
GTLB	GitLab Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
GTM	ZoomInfo Technologies Inc Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
GUACU	Berto Acquisition Corp. II Unit	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
GUTS	Fractyl Health Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Medical/Dental Instruments	Nasdaq	2024
GWAV	Greenwave Technology Solutions Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Metal Fabrications	Nasdaq	\N
GWRS	Global Water Resources Inc. Common Stock	2026-06-08 16:48:03.10371+00	Utilities	Water Supply	Nasdaq	2016
GXAI	Gaxos.ai Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2023
GYRO	Gyrodyne LLC Common Stock	2026-06-08 16:48:03.10371+00	Real Estate	Building operators	Nasdaq	\N
LINK	Interlink Electronics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Computer peripheral equipment	Nasdaq	\N
LITE	Lumentum Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
LITS	Lite Strategy Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2003
LIVE	Live Ventures Incorporated Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	\N
LIXT	Lixte Biotechnology Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LKFN	Lakeland Financial Corporation Common Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
LKQ	LKQ Corporation Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Motor Vehicles	Nasdaq	2003
LKSP	Lake Superior Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
LKSPR	Lake Superior Acquisition Corp. Rights	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
LLYVA	Liberty Live Holdings Inc. Series A Liberty Live Group Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
LLYVK	Liberty Live Holdings Inc. Series C Liberty Live Group Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
LMAT	LeMaitre Vascular Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	2006
LMB	Limbach Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Engineering & Construction	Nasdaq	\N
LMFA	LM Funding America Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Finance: Consumer Services	Nasdaq	2015
LMNR	Limoneira Co Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	\N
LMRI	Lumexa Imaging Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical Specialities	Nasdaq	2025
LNAI	Lunai Bioworks Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LNSR	LENSAR Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
LNT	Alliant Energy Corporation Common Stock	2026-06-08 16:48:03.119395+00	Utilities	Power Generation	Nasdaq	\N
LNTH	Lantheus Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	2015
LNZA	LanzaTech Global Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Major Chemicals	Nasdaq	2021
LNZAW	LanzaTech Global Inc. Warrant	2026-06-08 16:48:03.119395+00	Industrials	Major Chemicals	Nasdaq	2021
LOAN	Manhattan Bridge Capital Inc	2026-06-08 16:48:03.119395+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
LOCO	El Pollo Loco Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Restaurants	Nasdaq	2014
LOGI	Logitech International S.A. Ordinary Shares	2026-06-08 16:48:03.119395+00	Technology	Computer peripheral equipment	Nasdaq	1997
LOKV	Live Oak Acquisition Corp. V Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
LOKVU	Live Oak Acquisition Corp. V Units	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LONA	LeonaBio Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
LOPE	Grand Canyon Education Inc. Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Other Consumer Services	Nasdaq	2008
LOVE	The Lovesac Company Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2018
LPAA	Launch One Acquisition Corp. Class A Ordinary shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2024
LPAAW	Launch One Acquisition Corp. Warrant	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2024
LPBB	Launch Two Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2024
LPBBW	Launch Two Acquisition Corp. Warrant	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2024
LPCN	Lipocine Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LPCV	Launchpad Cadenza Acquisition Corp I Class A Ordinary Share	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2026
LPCVW	Launchpad Cadenza Acquisition Corp I Warrant	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2026
LPLA	LPL Financial Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2010
LPRO	Open Lending Corporation Common Stock	2026-06-08 16:48:03.119395+00	Finance	Finance: Consumer Services	Nasdaq	\N
LPSN	LivePerson Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2000
LPTH	LightPath Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Technology	Semiconductors	Nasdaq	1996
LQDA	Liquidia Corporation Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
LQDT	Liquidity Services Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Business Services	Nasdaq	2006
LRCX	Lam Research Corporation Common Stock	2026-06-08 16:48:03.119395+00	Technology	Industrial Machinery/Components	Nasdaq	1984
LRHC	La Rosa Holdings Corp. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Real Estate	Nasdaq	2023
LRMR	Larimar Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
LSBK	Lake Shore Bancorp Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Savings Institutions	Nasdaq	2006
LSCC	Lattice Semiconductor Corporation Common Stock	2026-06-08 16:48:03.119395+00	Technology	Semiconductors	Nasdaq	\N
LSH	Lakeside Holding Limited Common Stock	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2024
LSTA	Lisata Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Misc Health and Biotechnology Services	Nasdaq	\N
LSTR	Landstar System Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Trucking Freight/Courier Services	Nasdaq	1993
LTBR	Lightbridge Corporation Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Professional Services	Nasdaq	\N
LTRN	Lantern Pharma Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
LTRX	Lantronix Inc. Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Computer Communications Equipment	Nasdaq	2000
LTRYW	Sports Entertainment Gaming Global Corporation Warrants	2026-06-08 16:48:03.119395+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2023
LUCD	Lucid Diagnostics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
LUCY	Innovative Eyewear Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Ophthalmic Goods	Nasdaq	2022
LUCYW	Innovative Eyewear Inc. Series A Warrants 8/16/27	2026-06-08 16:48:03.119395+00	Health Care	Ophthalmic Goods	Nasdaq	2022
LUNG	Pulmonx Corporation Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	2020
LUNR	Intuitive Machines Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Industrial Machinery/Components	Nasdaq	2021
LVLU	Lulu's Fashion Lounge Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2021
LVO	LiveOne Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Restaurants	Nasdaq	\N
LWAC	LightWave Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LWACW	LightWave Acquisition Corp. Warrants	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
LWAY	Lifeway Foods Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Packaged Foods	Nasdaq	\N
LWLG	Lightwave Logic Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Containers/Packaging	Nasdaq	\N
LXEO	Lexeo Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2023
LXRX	Lexicon Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
LYEL	Lyell Immunopharma Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
LYFT	Lyft Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Business Services	Nasdaq	2019
LYTS	LSI Industries Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Building Products	Nasdaq	1985
LZ	LegalZoom.com Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	EDP Services	Nasdaq	2021
MACI	Melar Acquisition Corp. I Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2024
MACIU	Melar Acquisition Corp. I Unit	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2024
MACIW	Melar Acquisition Corp. I Warrant	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2024
MAMA	Mama's Creations Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Specialty Foods	Nasdaq	\N
MAMO	Massimo Group Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Industrial Specialties	Nasdaq	2024
MANH	Manhattan Associates Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1998
MAR	Marriott International Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	\N
MARA	MARA Holdings Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	EDP Services	Nasdaq	\N
MARPS	Marine Petroleum Trust Units of Beneficial Interest	2026-06-08 16:48:03.119395+00	Energy	Oil & Gas Production	Nasdaq	\N
MASI	Masimo Corporation Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2007
MASS	908 Devices Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Industrial Machinery/Components	Nasdaq	2020
MAT	Mattel Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
MATW	Matthews International Corporation Class A Common Stock	2026-06-08 16:48:03.119395+00	Telecommunications	Metal Fabrications	Nasdaq	1994
MAYS	J. W. Mays Inc. Common Stock	2026-06-08 16:48:03.119395+00	Real Estate	Building operators	Nasdaq	\N
MAZE	Maze Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2025
MBAV	M3-Brigade Acquisition V Corp. Class A Ordinary shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2024
MBAVU	M3-Brigade Acquisition V Corp. Units	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2024
MBAVW	M3-Brigade Acquisition V Corp. Warrant	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2024
MBBC	Marathon Bancorp Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Banks	Nasdaq	\N
MBIN	Merchants Bancorp Common Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	2017
MBINL	Merchants Bancorp Depositary Shares Each Representing a 1/40thInterest in a Share of 7.25% Fixed Rate Series E Non-CumulativePerpetual Preferred Stock without par value	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
MBINM	Merchants Bancorp Depositary Shares Each Representing a 1/40th Interest in a Share of 8.25% Fixed-Rate Reset Series D Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
MBINN	Merchants Bancorp Depositary Shares Preferred Series C	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
MBIO	Mustang Bio Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
MBNKO	Medallion Bank Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series G par value $1.00 per share	2026-06-08 16:48:03.119395+00	Finance	Commercial Banks	Nasdaq	\N
MBRX	Moleculin Biotech Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
MBUU	Malibu Boats Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Marine Transportation	Nasdaq	2014
MBVIU	M3-Brigade Acquisition VI Corp. Units	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
MBVIW	M3-Brigade Acquisition VI Corp. Warrant	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
MBWM	Mercantile Bank Corporation Common Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	1998
MDB	MongoDB Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2017
MDBH	MDB Capital Holdings LLC Class A common	2026-06-08 16:48:03.132957+00	Finance	Finance: Consumer Services	Nasdaq	2023
MDGL	Madrigal Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2007
MDIA	Mediaco Holding Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Broadcasting	Nasdaq	\N
MDLN	Medline Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	2025
MDLZ	Mondelez International Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Consumer Staples	Packaged Foods	Nasdaq	\N
MDRR	Medalist Diversified Inc. Common Stock	2026-06-08 16:48:03.132957+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2018
MDXG	MiMedx Group Inc Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
MEDP	Medpace Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2016
MEHA	Functional Brands Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
MESH	Meshflow Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2026
MESHW	Meshflow Acquisition Corp. Warrants	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2026
META	Meta Platforms Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2012
METC	Ramaco Resources Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Energy	Coal Mining	Nasdaq	2017
METCB	Ramaco Resources Inc. Class B Common Stock	2026-06-08 16:48:03.132957+00	Energy	Coal Mining	Nasdaq	\N
METCI	Ramaco Resources Inc. 8.250% Senior Notes due 2030	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	\N
METCZ	Ramaco Resources Inc. 8.375% Senior Notes due 2029	2026-06-08 16:48:03.132957+00	Energy	Coal Mining	Nasdaq	\N
MEVO	M Evo Global Acquisition Corp II Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MEVOW	M Evo Global Acquisition Corp II Warrants	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MFIC	MidCap Financial Investment Corporation Common Stock	2026-06-08 16:48:03.132957+00	Finance	Finance/Investors Services	Nasdaq	2004
MFICL	MidCap Financial Investment Corporation 8.00% Notes due 2028	2026-06-08 16:48:03.132957+00	Finance	Finance/Investors Services	Nasdaq	\N
MFIN	Medallion Financial Corp. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Finance: Consumer Services	Nasdaq	\N
MGEE	MGE Energy Inc	2026-06-08 16:48:03.132957+00	Energy	Electric Utilities: Central	Nasdaq	\N
MGNI	Magnite Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
MGNX	MacroGenics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
MGPI	MGP Ingredients Inc.	2026-06-08 16:48:03.132957+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
MGRC	McGrath RentCorp Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	1984
MGRX	Mangoceuticals Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Misc Health and Biotechnology Services	Nasdaq	2023
MGTX	MeiraGTx Holdings plc Ordinary Shares	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
MGX	Metagenomi Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
MGYR	Magyar Bancorp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Savings Institutions	Nasdaq	2006
MIDD	Middleby Corporation (The) Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
MIND	MIND Technology Inc. Common Stock (DE)	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	1994
MIRA	MIRA Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
MIRM	Mirum Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
MITK	Mitek Systems Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer peripheral equipment	Nasdaq	\N
MKLY	McKinley Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
MKLYR	McKinley Acquisition Corporation Rights	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
MKLYU	McKinley Acquisition Corporation Units	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
MKSI	MKS Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	1999
MKTW	MarketWise Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
MKTX	MarketAxess Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2004
MKZR	MacKenzie Realty Capital Inc. Common Stock	2026-06-08 16:48:03.132957+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
MLAA	Mountain Lake Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MLAAW	Mountain Lake Acquisition Corp. II Warrants	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MLAB	Mesa Laboratories Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
MLAC	Mountain Lake Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Industrials	Auto Manufacturing	Nasdaq	2025
MLACR	Mountain Lake Acquisition Corp. Right	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
MLACU	Mountain Lake Acquisition Corp. Units	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2024
MLCI	Mount Logan Capital Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Investment Managers	Nasdaq	\N
MLCIL	Mount Logan Capital Inc. 8.00% Notes Due 2031	2026-06-08 16:48:03.132957+00	Finance	Investment Managers	Nasdaq	\N
MLGO	MicroAlgo Inc. Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Technology	EDP Services	Nasdaq	2021
MLKN	MillerKnoll Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Office Equipment/Supplies/Services	Nasdaq	\N
MLTX	MoonLake Immunotherapeutics Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
MLYS	Mineralys Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
ALEC	Alector Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
ALF	Centurion Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2024
ALFUU	Centurion Acquisition Corp. Unit	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2024
ALGM	Allegro MicroSystems Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	2020
ALGN	Align Technology Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Industrial Specialties	Nasdaq	2001
ALGS	Aligos Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
ALGT	Allegiant Travel Company Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	2006
ALHC	Alignment Healthcare Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical Specialities	Nasdaq	2021
ALIS	Calisa Acquisition Corp Ordinary shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2025
ALISR	Calisa Acquisition Corp Right	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2025
ALKT	Alkami Technology Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
ALLO	Allogene Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
ALLR	Allarity Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ALMR	Alamar Biosciences Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2026
ALMS	Alumis Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
ALMU	Aeluma Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	\N
ALNT	Allient Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Electrical Products	Nasdaq	\N
ALNY	Alnylam Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2004
ALOT	AstroNova Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer peripheral equipment	Nasdaq	1983
IVF	INVO Fertility Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
MMED	MiniMed Group Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	2026
MMLP	Martin Midstream Partners L.P. Limited Partnership	2026-06-08 16:48:03.132957+00	Energy	Oil Refining/Marketing	Nasdaq	2002
MMSI	Merit Medical Systems Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
MNOV	Medicinova Inc Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
MNPR	Monopar Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
MNRO	Monro Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Automotive Aftermarket	Nasdaq	1991
MNSB	MainStreet Bancshares Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
MNSBP	MainStreet Bancshares Inc. Depositary Shares	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
MNST	Monster Beverage Corporation	2026-06-08 16:48:03.132957+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
MNTK	Montauk Renewables Inc. Common Stock	2026-06-08 16:48:03.132957+00	Utilities	Natural Gas Distribution	Nasdaq	2021
MNTS	Momentus Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Military/Government/Technical	Nasdaq	2019
MNTSW	Momentus Inc. Warrant	2026-06-08 16:48:03.132957+00	Industrials	Military/Government/Technical	Nasdaq	2019
MOBI	Mobia Medical Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	2026
MOBX	Mobix Labs Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2021
MOBXW	Mobix Labs Inc Warrants	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2021
MODD	Modular Medical Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
MORN	Morningstar Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Investment Managers	Nasdaq	2005
MOVE	Corvex Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2021
MPAA	Motorcar Parts  of America Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
MPB	Mid Penn Bancorp Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
MPLT	MapLight Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
MPWR	Monolithic Power Systems Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2004
IZEA	IZEA Worldwide Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Advertising	Nasdaq	\N
MQ	Marqeta Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
MRAM	Everspin Technologies Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2016
MRBK	Meridian Corporation Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	2017
MRCY	Mercury Systems Inc Common Stock	2026-06-08 16:48:03.132957+00	Technology	Electrical Products	Nasdaq	1998
MRDN	Meridian Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
MRKR	Marker Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
MRLN	Merlin Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	EDP Services	Nasdaq	2024
MRNA	Moderna Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
MRTN	Marten Transport Ltd. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Trucking Freight/Courier Services	Nasdaq	1986
MRVI	Maravai LifeSciences Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
MRVL	Marvell Technology Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2000
MSAI	MultiSensor AI Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Electronic Components	Nasdaq	2021
MSAIW	MultiSensor AI Holdings Inc. Warrant	2026-06-08 16:48:03.132957+00	Technology	Electronic Components	Nasdaq	2021
MSBI	Midland States Bancorp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	2016
MSBIP	Midland States Bancorp Inc. Depositary Shares Each Representing a 1/40th Interest in a Share of 7.750% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
MSEX	Middlesex Water Company Common Stock	2026-06-08 16:48:03.132957+00	Utilities	Water Supply	Nasdaq	\N
MSFT	Microsoft Corporation Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1986
MSGM	Motorsport Games Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
MSS	Maison Solutions Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Consumer Staples	Food Chains	Nasdaq	2023
MSTR	Strategy Inc Common Stock Class A	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1998
MTCH	Match Group Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
MTEX	Mannatech Incorporated Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
MTRX	Matrix Service Company Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Engineering & Construction	Nasdaq	1990
MTSI	MACOM Technology Solutions Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2012
MTVA	MetaVia Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
MU	Micron Technology Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	\N
MUZE	Muzero Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MUZEU	Muzero Acquisition Corp Unit	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MUZEW	Muzero Acquisition Corp Warrant	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MVBF	MVB Financial Corp. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
MVIS	MicroVision Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Industrial Machinery/Components	Nasdaq	1996
MVST	Microvast Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2019
MVSTW	Microvast Holdings Inc. Warrants	2026-06-08 16:48:03.132957+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2019
MWH	SOLV Energy Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Military/Government/Technical	Nasdaq	2026
MWYN	Marwynn Holdings Inc. Common stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Food Distributors	Nasdaq	2025
MXCT	MaxCyte Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2021
MYFW	First Western Financial Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	2018
MYGN	Myriad Genetics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	1995
MYPS	PLAYSTUDIOS Inc.  Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
MYPSW	PLAYSTUDIOS Inc. Warrant	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
MYRG	MYR Group Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Water Sewer Pipeline Comm & Power Line Construction	Nasdaq	2008
MYSE	Myseum.AI Inc. Common Stock	2026-06-08 16:48:03.132957+00	Telecommunications	Telecommunications Equipment	Nasdaq	2021
MYSEW	Myseum.AI Inc. Series A Warrant	2026-06-08 16:48:03.132957+00	Telecommunications	Telecommunications Equipment	Nasdaq	2021
MYX	Maywood Acquisition Corp. 2 Class A Ordinary Share	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MYXXU	Maywood Acquisition Corp. 2 Units	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
MZTI	The Marzetti Company Common Stock	2026-06-08 16:48:03.132957+00	Consumer Staples	Packaged Foods	Nasdaq	\N
NAGE	Niagen Bioscience Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
NAII	Natural Alternatives International Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
NAKA	Nakamoto Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Nursing Services	Nasdaq	2024
NATH	Nathan's Famous Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Restaurants	Nasdaq	1993
NATR	Nature's Sunshine Products Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
NAUT	Nautilus Biotechnology Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2020
NAVI	Navient Corporation Common Stock	2026-06-08 16:48:03.132957+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
NAVN	Navan Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
NB	NioCorp Developments Ltd. Common Stock	2026-06-08 16:48:03.132957+00	Basic Materials	Metal Mining	Nasdaq	\N
NBBK	NB Bancorp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Banks	Nasdaq	2023
NBIX	Neurocrine Biosciences Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	1996
NBN	Northeast Bank Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NBTB	NBT Bancorp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NCMI	National CineMedia Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Advertising	Nasdaq	2007
NCNO	nCino Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
NCPL	Netcapital Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Finance: Consumer Services	Nasdaq	\N
NCPLW	Netcapital Inc. Warrants	2026-06-08 16:48:03.132957+00	Finance	Finance: Consumer Services	Nasdaq	\N
NCSM	NCS Multistage Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Energy	Oilfield Services/Equipment	Nasdaq	2017
NDAQ	Nasdaq Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
NDLS	Noodles & Company Class A Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Restaurants	Nasdaq	2013
NDRA	ENDRA Life Sciences Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2017
NDSN	Nordson Corporation Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
NECB	NorthEast Community Bancorp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Banks	Nasdaq	2021
NEO	NeoGenomics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Precision Instruments	Nasdaq	\N
NEOG	Neogen Corporation Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	1989
NEOV	NeoVolta Inc. Common Stock	2026-06-08 16:48:03.132957+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
NEOVW	NeoVolta Inc. Warrant	2026-06-08 16:48:03.132957+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
NEPH	Nephros Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
NERV	Minerva Neurosciences Inc Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
NESR	National Energy Services Reunited Corp Ordinary Shares	2026-06-08 16:48:03.132957+00	Energy	Oilfield Services/Equipment	Nasdaq	\N
NEUP	Neuphoria Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
NEWT	NewtekOne Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NEWTG	NewtekOne Inc. 8.50% Fixed Rate Senior Notes due 2029	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NEWTH	NewtekOne Inc. 8.625% Fixed Rate Senior Notes due 2029	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NEWTI	NewtekOne Inc. 8.00% Fixed Rate Senior Notes due 2028	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NEWTO	NewtekOne Inc. 8.50% Fixed Rate Senior Notes due 2031	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	\N
NEWTP	NewtekOne Inc. Depositary Shares Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NEXT	NextDecade Corporation Common Stock	2026-06-08 16:48:03.132957+00	Utilities	Oil & Gas Production	Nasdaq	2015
NFBK	Northfield Bancorp Inc. Common Stock (Delaware)	2026-06-08 16:48:03.132957+00	Finance	Savings Institutions	Nasdaq	2007
NFE	New Fortress Energy Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Utilities	Oil/Gas Transmission	Nasdaq	2019
NFLX	Netflix Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Consumer Electronics/Video Chains	Nasdaq	2002
NHIC	NewHold Investment Corp III Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
NHICU	NewHold Investment Corp III Units	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
NHICW	NewHold Investment Corp III Warrants	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
NHIVU	NewHold Investment Corp IV Units	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
NHP	National Healthcare Properties Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	\N
NHPAP	National Healthcare Properties Inc. 7.375% Series A Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.132957+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
NHPBP	National Healthcare Properties Inc. 7.125% Series B Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.132957+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
NHTC	Natural Health Trends Corp. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Consumer Specialties	Nasdaq	\N
NIOBW	NioCorp Developments Ltd. Warrant	2026-06-08 16:48:03.132957+00	Basic Materials	Metal Mining	Nasdaq	\N
NIXX	Nixxy Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	EDP Services	Nasdaq	\N
NIXXW	Nixxy Inc. Warrant	2026-06-08 16:48:03.132957+00	Technology	EDP Services	Nasdaq	\N
NKSH	National Bankshares Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NKTR	Nektar Therapeutics  Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
NKTX	Nkarta Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
NMFC	New Mountain Finance Corporation Common Stock	2026-06-08 16:48:03.132957+00	Finance	Finance/Investors Services	Nasdaq	\N
NMIH	NMI Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Property-Casualty Insurers	Nasdaq	2013
NMP	NMP Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
NMPAR	NMP Acquisition Corp. Right	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
NMRA	Neumora Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2023
NMRK	Newmark Group Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Finance	Real Estate	Nasdaq	2017
NMTC	NeuroOne Medical Technologies Corporation Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
NN	NextNav Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
NNAVW	NextNav Inc. Warrant	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
NNBR	NN Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Machinery/Components	Nasdaq	1994
NNE	Nano Nuclear Energy Inc. Common Stock	2026-06-08 16:48:03.132957+00	Utilities	Electric Utilities: Central	Nasdaq	2024
NODK	NI Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Property-Casualty Insurers	Nasdaq	2017
NOEM	CO2 Energy Transition Corp. Common Stock	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
NOEMR	CO2 Energy Transition Corp. Right	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
NOEMU	CO2 Energy Transition Corp. Unit	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2024
NOEMW	CO2 Energy Transition Corp. Warrant	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
NOMA	NOMADAR Corp. Class A Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
NOTV	Inotiv Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	\N
NOVT	Novanta Inc. Common Stock	2026-06-08 16:48:03.132957+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
NOVTU	Novanta Inc. Tangible Equity Units	2026-06-08 16:48:03.132957+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
ALOV	Aldabra 4 Liquidity Opportunity Vehicle Inc. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
NPAC	New Providence Acquisition Corp. III Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
NPACW	New Providence Acquisition Corp. III Warrants	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
NPCE	Neuropace Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
NRC	NRC Health Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	\N
NRDS	NerdWallet Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	EDP Services	Nasdaq	2021
NRIM	Northrim BanCorp Inc Common Stock	2026-06-08 16:48:03.132957+00	Finance	Savings Institutions	Nasdaq	\N
NRIX	Nurix Therapeutics Inc. Common stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
NRXP	NRX Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
NSIT	Insight Enterprises Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	1995
NSSC	NAPCO Security Technologies Inc. Common Stock	2026-06-08 16:48:03.132957+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
NSTS	NSTS Bancorp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Savings Institutions	Nasdaq	2022
NSYS	Nortech Systems Incorporated Common Stock	2026-06-08 16:48:03.132957+00	Technology	Industrial Machinery/Components	Nasdaq	\N
NTAP	NetApp Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Electronic Components	Nasdaq	1995
NTCT	NetScout Systems Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	EDP Services	Nasdaq	1999
NTGR	NETGEAR Inc. Common Stock	2026-06-08 16:48:03.132957+00	Utilities	Telecommunications Equipment	Nasdaq	2003
NTHI	NeOnc Technologies Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
NTIC	Northern Technologies International Corporation Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Industrial Specialties	Nasdaq	\N
NTLA	Intellia Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	2016
NTNX	Nutanix Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2016
NTRA	Natera Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical Specialities	Nasdaq	2015
NTRB	Nutriband Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Industrial Specialties	Nasdaq	\N
NTRBW	Nutriband Inc. Warrant	2026-06-08 16:48:03.132957+00	Health Care	Industrial Specialties	Nasdaq	\N
NTRP	NextTrip Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Miscellaneous manufacturing industries	Nasdaq	\N
NTRS	Northern Trust Corporation Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NTRSO	Northern Trust Corporation Depositary Shares Each Representing a 1/1000th Interest in a Share of Series E Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	\N
NTSK	Netskope Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
NTWK	NetSol Technologies Inc. Common  Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
NTWO	Newbury Street II Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2024
NVDA	NVIDIA Corporation Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	1999
NVEC	NVE Corporation Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	\N
NVNO	enVVeno Medical Corporation Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2018
NVTS	Navitas Semiconductor Corporation Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	\N
NVVE	Nuvve Holding Corp. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Electrical Products	Nasdaq	2020
NWBI	Northwest Bancshares Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	2009
NWE	NorthWestern Energy Group Inc. Common Stock	2026-06-08 16:48:03.14768+00	Utilities	Power Generation	Nasdaq	\N
NWFL	Norwood Financial Corp. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
NWL	Newell Brands Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Plastic Products	Nasdaq	\N
NWPX	NWPX Infrastructure Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Steel/Iron Ore	Nasdaq	1995
NWS	News Corporation Class B Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Newspapers/Magazines	Nasdaq	\N
NWSA	News Corporation Class A Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Newspapers/Magazines	Nasdaq	\N
NWTG	Newton Golf Company Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	2023
NXGL	NexGel Inc Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
NXGLW	NexGel Inc Warrant	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
NXL	Nexalin Technology Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2022
NXPL	NextPlat Corp Common Stock	2026-06-08 16:48:03.14768+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
NXPLW	NextPlat Corp Warrants	2026-06-08 16:48:03.14768+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
NXST	Nexstar Media Group Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Broadcasting	Nasdaq	2003
NXT	Nextpower Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Industrial Machinery/Components	Nasdaq	2023
NXTC	NextCure Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
NXXT	NextNRG Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	2021
OABI	OmniAb Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2021
OABIW	OmniAb Inc. Warrant	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2021
OACC	Oaktree Acquisition Corp. III Life Sciences Class A Ordinary Share	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2024
OACCU	Oaktree Acquisition Corp. III Life Sciences Unit	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2024
OACCW	Oaktree Acquisition Corp. III Life Sciences Warrant	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2024
OBAI	Our Bond Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	\N
OBIO	Orchestra BioMed Holdings Inc. Ordinary Shares	2026-06-08 16:48:03.14768+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	2020
OBT	Orange County Bancorp Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OCC	Optical Cable Corporation Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Telecommunications Equipment	Nasdaq	\N
ALOVU	Aldabra 4 Liquidity Opportunity Vehicle Inc. Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ALOVW	Aldabra 4 Liquidity Opportunity Vehicle Inc. Warrants	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ALOY	REalloys Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	EDP Services	Nasdaq	\N
ALRM	Alarm.com Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2015
MBX	MBX Biosciences Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
OCCI	OFS Credit Company Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Trusts Except Educational Religious and Charitable	Nasdaq	2018
OCCIM	OFS Credit Company Inc. 7.875% Series F Term Preferred Stock	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	\N
OCCIN	OFS Credit Company Inc. 5.25% Series E Term Preferred Stock Due 2026	2026-06-08 16:48:03.14768+00	Finance	Trusts Except Educational Religious and Charitable	Nasdaq	\N
OCFC	OceanFirst Financial Corp. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OCGN	Ocugen Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2014
OCSL	Oaktree Specialty Lending Corporation Common Stock	2026-06-08 16:48:03.14768+00	Finance	Finance: Consumer Services	Nasdaq	\N
OCTV	Octave Intelligence plc Class B Ordinary Shares	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
OCUL	Ocular Therapeutix Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
ODFL	Old Dominion Freight Line Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Trucking Freight/Courier Services	Nasdaq	1991
ODTX	Odyssey Therapeutics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2026
OESX	Orion Energy Systems Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Building Products	Nasdaq	2015
OFLX	Omega Flex Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Industrial Specialties	Nasdaq	\N
OFS	OFS Capital Corporation Common Stock	2026-06-08 16:48:03.14768+00	Finance	Finance/Investors Services	Nasdaq	\N
OFSSH	OFS Capital Corporation 4.95% Notes due 2028	2026-06-08 16:48:03.14768+00	Finance	Finance Companies	Nasdaq	\N
OFSSO	OFS Capital Corporation 7.50% Notes due 2028	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	\N
OIM	OneIM Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2026
OIMAU	OneIM Acquisition Corp. Units	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
OIMAW	OneIM Acquisition Corp. Warrant	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2026
OKTA	Okta Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2017
OKUR	OnKure Therapeutics Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
OLB	The OLB Group Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Business Services	Nasdaq	\N
OLED	Universal Display Corporation Common Stock	2026-06-08 16:48:03.14768+00	Technology	Electrical Products	Nasdaq	\N
OLLI	Ollie's Bargain Outlet Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Department/Specialty Retail Stores	Nasdaq	2015
OLOX	Olenox Industries Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	2017
OLPX	Olaplex Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	2021
OM	Outset Medical Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2020
OMCL	Omnicell Inc. Common Stock ($0.001 par value)	2026-06-08 16:48:03.14768+00	Technology	Computer Manufacturing	Nasdaq	2001
OMDA	Omada Health Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Nursing Services	Nasdaq	2025
OMER	Omeros Corporation Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2009
OMEX	Odyssey Marine Exploration Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Marine Transportation	Nasdaq	\N
ON	ON Semiconductor Corporation Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	\N
ONBPO	Old National Bancorp Depositary Shares Each Representing a 1/40th Interest in a Share of Series C Preferred Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
ONBPP	Old National Bancorp Depositary Shares Each Representing a 1/40th Interest in a Share of Series A Preferred Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
ONCH	1RT Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
ONCHU	1RT Acquisition Corp. Units	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
ONCHW	1RT Acquisition Corp. Warrant	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
ONCO	Onconetix Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
ONDS	Ondas Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	\N
ONEW	OneWater Marine Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Auto & Home Supply Stores	Nasdaq	2020
ONFO	Onfolio Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	EDP Services	Nasdaq	2022
ONFOW	Onfolio Holdings Inc. Warrant	2026-06-08 16:48:03.14768+00	Technology	EDP Services	Nasdaq	2022
OPAL	OPAL Fuels Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Utilities	Natural Gas Distribution	Nasdaq	2021
OPBK	OP Bancorp Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	2018
OPCH	Option Care Health Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Nursing Services	Nasdaq	\N
OPEN	Opendoor Technologies Inc Common Stock	2026-06-08 16:48:03.14768+00	Finance	Real Estate	Nasdaq	\N
OPENL	Opendoor Technologies Inc  Series A Warrants each whole warrant exercisable to purchase one share of Common Stock at an exercise price of $13.00 per warrant	2026-06-08 16:48:03.14768+00	Finance	Real Estate	Nasdaq	\N
OPENW	Opendoor Technologies Inc  Series K Warrants each whole warrant exercisable to purchase one share of Common Stock at an exercise price of $9.00 per warrant	2026-06-08 16:48:03.14768+00	Finance	Real Estate	Nasdaq	\N
OPENZ	Opendoor Technologies Inc  Series Z Warrants each whole warrant exercisable to purchase one share of Common Stock at an exercise price of $17.00 per warrant	2026-06-08 16:48:03.14768+00	Finance	Real Estate	Nasdaq	\N
MCAHU	Mountain Crest Acquisition 6 Corp. Units	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2026
MCBS	MetroCity Bankshares Inc. Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	2019
MCFT	MasterCraft Boat Holdings Inc. Common Stock	2026-06-08 16:48:03.132957+00	Industrials	Marine Transportation	Nasdaq	2015
MCHX	Marchex Inc. Class B Common Stock	2026-06-08 16:48:03.132957+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2004
MCRB	Seres Therapeutics Inc. Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
MCRI	Monarch Casino & Resort Inc. Common Stock	2026-06-08 16:48:03.132957+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	1993
OPK	OPKO Health Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
OPRT	Oportun Financial Corporation Common Stock	2026-06-08 16:48:03.14768+00	Finance	Finance: Consumer Services	Nasdaq	2019
OPRX	OptimizeRx Corporation Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Business Services	Nasdaq	\N
OPTX	Syntec Optics Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Technology	Electronic Components	Nasdaq	2022
OPTXW	Syntec Optics Holdings Inc. Warrant	2026-06-08 16:48:03.14768+00	Technology	Electronic Components	Nasdaq	2022
OPXS	Optex Systems Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Electronic Components	Nasdaq	\N
ORBS	Eightco Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	\N
ORGN	Origin Materials Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Major Chemicals	Nasdaq	2020
ORGNW	Origin Materials Inc. Warrants	2026-06-08 16:48:03.14768+00	Industrials	Major Chemicals	Nasdaq	2020
ORGO	Organogenesis Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
ORIC	Oric Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
ORKA	Oruka Therapeutics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	\N
ORLY	O'Reilly Automotive Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Auto & Home Supply Stores	Nasdaq	1993
ORRF	Orrstown Financial Services Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OSBC	Old Second Bancorp Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OSIS	OSI Systems Inc. Common Stock (DE)	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	1997
OSPN	OneSpan Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	EDP Services	Nasdaq	\N
OSRH	OSR Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2023
OSRHW	OSR Holdings Inc. Warrant	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2023
OSS	One Stop Systems Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Manufacturing	Nasdaq	2018
OSUR	OraSure Technologies Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
OTGA	OTG Acquisition Corp. I Class A Ordinary Share	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
OTGAU	OTG Acquisition Corp. I Unit	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
OTLK	Outlook Therapeutics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2016
OTTR	Otter Tail Corporation Common Stock	2026-06-08 16:48:03.14768+00	Utilities	Electric Utilities: Central	Nasdaq	\N
OUST	Ouster Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
OVBC	Ohio Valley Banc Corp. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OVID	Ovid Therapeutics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
OXLC	Oxford Lane Capital Corp. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Investment Managers	Nasdaq	2011
OXLCG	Oxford Lane Capital Corp. 7.95% Notes due 2032	2026-06-08 16:48:03.14768+00	Finance	Investment Managers	Nasdaq	\N
OXLCI	Oxford Lane Capital Corp. 8.75% Notes due 2030	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	\N
OXLCL	Oxford Lane Capital Corp. 6.75% Notes due 2031	2026-06-08 16:48:03.14768+00	Finance	Finance Companies	Nasdaq	\N
OXLCM	Oxford Lane Capital Corp. Preferred Stock Shares 8.25% Series 2031	2026-06-08 16:48:03.14768+00	Finance	Investment Managers	Nasdaq	\N
OXLCN	Oxford Lane Capital Corp. 7.125% Series 2029 Term Preferred Stock	2026-06-08 16:48:03.14768+00	Finance	Investment Managers	Nasdaq	\N
OXLCO	Oxford Lane Capital Corp. Preferred Stock Shares 6.00% Series 2029	2026-06-08 16:48:03.14768+00	Finance	Investment Managers	Nasdaq	\N
OXLCZ	Oxford Lane Capital Corp. 5.00% Notes due 2027	2026-06-08 16:48:03.14768+00	Finance	Finance Companies	Nasdaq	\N
OXSQ	Oxford Square Capital Corp. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2003
OXSQG	Oxford Square Capital Corp. 5.50% Notes due 2028	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
OXSQH	Oxford Square Capital Corp. 7.75% Notes due 2030	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	\N
OYSE	Oyster Enterprises II Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
OYSER	Oyster Enterprises II Acquisition Corp Rights	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
OZK	Bank OZK Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OZKAP	Bank OZK 4.625% Series A Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PAA	Plains All American Pipeline L.P. Common Units representing Limited Partner Interests	2026-06-08 16:48:03.14768+00	Energy	Natural Gas Distribution	Nasdaq	1998
PAAC	Proem Acquisition Corp I Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2026
PAACU	Proem Acquisition Corp I Units	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
PAACW	Proem Acquisition Corp I Warrants	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
PACB	Pacific Biosciences of California Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2010
PACH	Pioneer Acquisition I Corp Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PACHU	Pioneer Acquisition I Corp Units	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PACHW	Pioneer Acquisition I Corp Warrants	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PAGP	Plains GP Holdings L.P. Class A Units representing Limited Partner Interests	2026-06-08 16:48:03.14768+00	Energy	Natural Gas Distribution	Nasdaq	\N
PAHC	Phibro Animal Health Corporation Class A Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
PAL	Proficient Auto Logistics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Transportation Services	Nasdaq	2024
PALI	Palisade Bio Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
PALO	Paloma Acquisition Corp I Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
PALOU	Paloma Acquisition Corp I Units	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
PALOW	Paloma Acquisition Corp I Warrants	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
PAMT	PAMT CORP Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Trucking Freight/Courier Services	Nasdaq	\N
PANL	Pangaea Logistics Solutions Ltd. Common Shares	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Marine Transportation	Nasdaq	2013
PANW	Palo Alto Networks Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer peripheral equipment	Nasdaq	\N
PARK	Park Dental Partners Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Misc Health and Biotechnology Services	Nasdaq	2025
PASG	Passage Bio Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
PATK	Patrick Industries Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
PAVM	PAVmed Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2016
PAYO	Payoneer Global Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Business Services	Nasdaq	\N
PAYS	Paysign Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	EDP Services	Nasdaq	\N
PAYX	Paychex Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Diversified Commercial Services	Nasdaq	1983
PBFS	Pioneer Bancorp Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Banks	Nasdaq	2019
PBHC	Pathfinder Bancorp Inc. Common Stock (MD)	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PBYI	Puma Biotechnology Inc Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PCAP	ProCap Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
PCAPU	ProCap Acquisition Corp Unit	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PCAPW	ProCap Acquisition Corp Warrant	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
PCAR	PACCAR Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Motor Vehicles	Nasdaq	\N
PCB	PCB Bancorp Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	2018
PCRX	Pacira BioSciences Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2011
PCSA	Processa Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PCSC	Perceptive Capital Solutions Corp Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2024
PCT	PureCycle Technologies Inc. Common stock	2026-06-08 16:48:03.14768+00	Industrials	Major Chemicals	Nasdaq	\N
PCTTU	PureCycle Technologies Inc. Unit	2026-06-08 16:48:03.14768+00	Industrials	Major Chemicals	Nasdaq	\N
PCTTW	PureCycle Technologies Inc. Warrant	2026-06-08 16:48:03.14768+00	Industrials	Major Chemicals	Nasdaq	\N
PCTY	Paylocity Holding Corporation Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2014
PCVX	Vaxcyte Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
PCYO	Pure Cycle Corporation Common Stock	2026-06-08 16:48:03.14768+00	Utilities	Water Supply	Nasdaq	\N
PDEX	Pro-Dex Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
PDFS	PDF Solutions Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2001
PDLB	Ponce Financial Group Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Savings Institutions	Nasdaq	2017
PDSB	PDS Biotechnology Corporation Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
PDYN	Palladyne AI Corp. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
PDYNW	Palladyne AI Corp Warrants	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
PEBK	Peoples Bancorp of North Carolina Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PEBO	Peoples Bancorp Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PECEU	Peace Acquisition Corp Units	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2026
PECO	Phillips Edison & Company Inc. Common Stock	2026-06-08 16:48:03.14768+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2021
PENG	Penguin Solutions Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	2017
PENN	PENN Entertainment Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	1994
PEP	PepsiCo Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
PEPG	PepGen Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
PESI	Perma-Fix Environmental Services Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Environmental Services	Nasdaq	\N
PETS	PetMed Express Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Staples	Retail-Drug Stores and Proprietary Stores	Nasdaq	\N
PFBC	Preferred Bank Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PFG	Principal Financial Group Inc Common Stock	2026-06-08 16:48:03.14768+00	Finance	Accident &Health Insurance	Nasdaq	2001
PFIS	Peoples Financial Services Corp. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PFSA	Profusa Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
PFX	PhenixFIN Corporation Common Stock	2026-06-08 16:48:03.14768+00	Finance	Finance: Consumer Services	Nasdaq	\N
PFXNZ	PhenixFIN Corporation  5.25% Notes due 2028	2026-06-08 16:48:03.14768+00	Finance	Finance: Consumer Services	Nasdaq	\N
PGAC	Pantages Capital Acquisition Corporation Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PGACU	Pantages Capital Acquisition Corporation Unit	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2024
PGC	Peapack-Gladstone Financial Corporation Common Stock	2026-06-08 16:48:03.14768+00	Finance	Commercial Banks	Nasdaq	\N
PGEN	Precigen Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PGNY	Progyny Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Misc Health and Biotechnology Services	Nasdaq	2019
PGY	Pagaya Technologies Ltd. Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	Finance	Finance: Consumer Services	Nasdaq	\N
PGYWW	Pagaya Technologies Ltd. Warrants	2026-06-08 16:48:03.14768+00	Finance	Finance: Consumer Services	Nasdaq	\N
ALRS	Alerus Financial Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Major Banks	Nasdaq	2019
MXL	MaxLinear Inc. Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	2010
PHAT	Phathom Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
PHIO	Phio Pharmaceuticals Corp. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PI	Impinj Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Industrial Machinery/Components	Nasdaq	2016
PIII	P3 Health Partners Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Nursing Services	Nasdaq	2021
PIIIW	P3 Health Partners Inc. Warrant	2026-06-08 16:48:03.14768+00	Health Care	Medical/Nursing Services	Nasdaq	2021
PKBK	Parke Bancorp Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PKOH	Park-Ohio Holdings Corp. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Industrial Specialties	Nasdaq	\N
PLAB	Photronics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	1987
PLAY	Dave & Buster's Entertainment Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Restaurants	Nasdaq	2014
PLBC	Plumas Bancorp	2026-06-08 16:48:03.14768+00	Finance	Finance Companies	Nasdaq	\N
PLBY	Playboy Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2020
PLCE	Children's Place Inc. (The) Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	1997
PLMK	Plum Acquisition Corp. IV Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PLMKW	Plum Acquisition Corp. IV Warrants	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2025
PLMR	Palomar Holdings Inc. Common stock	2026-06-08 16:48:03.14768+00	Finance	Property-Casualty Insurers	Nasdaq	2019
PLPC	Preformed Line Products Company Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Water Sewer Pipeline Comm & Power Line Construction	Nasdaq	\N
PLRX	Pliant Therapeutics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
PLSE	Pulse Biosciences Inc Common Stock (DE)	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2016
PLTR	Palantir Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
PLUG	Plug Power Inc. Common Stock	2026-06-08 16:48:03.14768+00	Energy	Industrial Machinery/Components	Nasdaq	1999
PLUS	ePlus inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Retail: Computer Software & Peripheral Equipment	Nasdaq	1996
PLXS	Plexus Corp. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Electrical Products	Nasdaq	\N
PLYX	Polaryx Therapeutics Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PMCB	PharmaCyte  Biotech Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
PMTR	Perimeter Acquisition Corp. I Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
PMTRU	Perimeter Acquisition Corp. I Unit	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
PMTRW	Perimeter Acquisition Corp. I Warrant	2026-06-08 16:48:03.14768+00	Finance	Blank Checks	Nasdaq	2025
PMTS	CPI Card Group Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Publishing	Nasdaq	\N
PMVP	PMV Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
PNBK	Patriot National Bancorp Inc. Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
PNRG	PrimeEnergy Resources Corporation Common Stock	2026-06-08 16:48:03.14768+00	Energy	Oil & Gas Production	Nasdaq	\N
PNTG	The Pennant Group Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Nursing Services	Nasdaq	\N
POCI	Precision Optics Corporation Inc. Common stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
PODC	PodcastOne Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
POLA	Polar Power Inc. Common Stock	2026-06-08 16:48:03.14768+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2016
POLE	Andretti Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2024
POLEU	Andretti Acquisition Corp. II Unit	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2024
POLEW	Andretti Acquisition Corp. II Warrant	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2024
POOL	Pool Corporation Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Industrial Specialties	Nasdaq	1995
POWI	Power Integrations Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	Semiconductors	Nasdaq	1997
POWL	Powell Industries Inc. Common Stock	2026-06-08 16:48:03.14768+00	Energy	Electrical Products	Nasdaq	\N
POWW	Outdoor Holding Company Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Ordnance And Accessories	Nasdaq	\N
POWWP	Outdoor Holding Company 8.75% Series A Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.14768+00	Industrials	Ordnance And Accessories	Nasdaq	\N
PPC	Pilgrim's Pride Corporation Common Stock	2026-06-08 16:48:03.14768+00	Consumer Staples	Meat/Poultry/Fish	Nasdaq	\N
PPHC	Public Policy Holding Company Inc. Common Stock	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2026
PPIH	Perma-Pipe International Holdings Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Pollution Control Equipment	Nasdaq	\N
PPSI	Pioneer Power Solutions Inc. Common Stock	2026-06-08 16:48:03.14768+00	Industrials	Electrical Products	Nasdaq	\N
PSTV	PLUS THERAPEUTICS Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
PTACU	Patriot Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2026
PTC	PTC Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
PTCT	PTC Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
PTEN	Patterson-UTI Energy Inc. Common Stock	2026-06-08 16:48:03.166278+00	Energy	Oil & Gas Production	Nasdaq	1993
PTGX	Protagonist Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
PTLO	Portillo's Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Restaurants	Nasdaq	2021
PTN	Palatin Technologies Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PTON	Peloton Interactive Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	2019
PTOR	Praetorian Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
PTORU	Praetorian Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2026
ALT	Altimmune Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ALTI	AlTi Global Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Finance	Investment Managers	Nasdaq	2021
ALTO	Alto Ingredients Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Major Chemicals	Nasdaq	\N
PTORW	Praetorian Acquisition Corp. Warrant	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
PTRN	Pattern Group Inc. Series A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2025
PUBM	PubMatic Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2020
PULM	Pulmatrix Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
PURR	Hyperliquid Strategies Inc Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	\N
PUSA	Aureus Greenway Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2025
PVLA	Palvella Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PWP	Perella Weinberg Partners Class A Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	2020
PWRL	Powerlaw Corp. Common Stock	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	\N
PXLW	Pixelworks Inc.  Common Stock	2026-06-08 16:48:03.166278+00	Technology	Semiconductors	Nasdaq	2000
PYPL	PayPal Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Diversified Commercial Services	Nasdaq	\N
PYXS	Pyxis Oncology Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
PZZA	Papa John's International Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Restaurants	Nasdaq	1993
QADR	QDRO Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
QADRU	QDRO Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
QADRW	QDRO Acquisition Corp. Warrant	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
QCLS	Q/C Technologies Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	2014
QCOM	QUALCOMM Incorporated Common Stock	2026-06-08 16:48:03.166278+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	1991
QCRH	QCR Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Major Banks	Nasdaq	\N
QDEL	QuidelOrtho Corporation Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	\N
QETA	Quetta Acquisition Corporation Common Stock	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2023
QETAU	Quetta Acquisition Corporation Unit	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2023
QLYS	Qualys Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2012
QMCO	Quantum Corporation Common Stock	2026-06-08 16:48:03.166278+00	Technology	Electronic Components	Nasdaq	\N
QNCX	Quince Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
QNST	QuinStreet Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Business Services	Nasdaq	2010
QQQX	Nuveen NASDAQ 100 Dynamic Overwrite Fund Shares of Beneficial Interest	2026-06-08 16:48:03.166278+00	Finance	Finance Companies	Nasdaq	\N
QRHC	Quest Resource Holding Corporation Common Stock	2026-06-08 16:48:03.166278+00	Utilities	Environmental Services	Nasdaq	\N
QRVO	Qorvo Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Semiconductors	Nasdaq	\N
QS	QuantumScape Corporation Class A Common Stock	2026-06-08 16:48:03.166278+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
QSEA	Quartzsea Acquisition Corporation Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
QSEAR	Quartzsea Acquisition Corporation Rights	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
QSEAU	Quartzsea Acquisition Corporation Units	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
QSI	Quantum-Si Incorporated Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Industrial Machinery/Components	Nasdaq	2020
QSIAW	Quantum-Si Incorporated Warrant	2026-06-08 16:48:03.166278+00	Industrials	Industrial Machinery/Components	Nasdaq	2020
QTI	QT Imaging Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
QTRX	Quanterix Corporation Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2017
QTTB	Q32 Bio Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
QUBT	Quantum Computing Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
QUIK	QuickLogic Corporation Common Stock	2026-06-08 16:48:03.166278+00	Technology	Semiconductors	Nasdaq	1999
QUMS	Quantumsphere Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2025
QUMSR	Quantumsphere Acquisition Corp. Rights	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2025
QUMSU	Quantumsphere Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2025
RAAQ	Real Asset Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RAAQU	Real Asset Acquisition Corp. Unit	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RAAQW	Real Asset Acquisition Corp. Warrants	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RACC	Research Alliance Corporation III Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2026
RAIL	FreightCar America Inc. Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Railroads	Nasdaq	2005
RAIN	Rain Enhancement Technologies Holdco Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Technology	Industrial Machinery/Components	Nasdaq	\N
RAND	Rand Capital Corporation Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	\N
RANG	Range Capital Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RANGR	Range Capital Acquisition Corp. Rights	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RANGU	Range Capital Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2024
RANI	Rani Therapeutics Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
RAPP	Rapport Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
RARE	Ultragenyx Pharmaceutical Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
NUAI	New Era Energy & Digital Inc. Common Stock	2026-06-08 16:48:03.14768+00	Energy	Oil & Gas Production	Nasdaq	\N
NUAIW	New Era Energy & Digital Inc. Warrants	2026-06-08 16:48:03.14768+00	Energy	Oil & Gas Production	Nasdaq	\N
OHACU	Oceanhawk Acquisition Corp. Units	2026-06-08 16:48:03.14768+00	\N	\N	Nasdaq	2026
RAVE	Rave Restaurant Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Food Distributors	Nasdaq	\N
RBB	RBB Bancorp Common Stock	2026-06-08 16:48:03.166278+00	Finance	Major Banks	Nasdaq	2017
RBBN	Ribbon Communications Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	EDP Services	Nasdaq	\N
RBCAA	Republic Bancorp Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Finance	Major Banks	Nasdaq	1998
RBKB	Rhinebeck Bancorp Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Banks	Nasdaq	2019
RCAT	Red Cat Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
RCEL	Avita Medical Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
RCKT	Rocket Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
RCKTW	Rocket Pharmaceuticals Inc. Warrant	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
RCKY	Rocky Brands Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Shoe Manufacturing	Nasdaq	1993
RCMT	RCM Technologies Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Professional Services	Nasdaq	\N
RDAG	Republic Digital Acquisition Company Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RDAGW	Republic Digital Acquisition Company Warrants	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RDI	Reading International Inc Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Movies/Entertainment	Nasdaq	\N
RDIB	Reading International Inc Class B Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Movies/Entertainment	Nasdaq	\N
RDNT	RadNet Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical Specialities	Nasdaq	\N
RDNW	RideNow Group Inc. Class B Common Stock	2026-06-08 16:48:03.166278+00	Technology	EDP Services	Nasdaq	\N
RDVT	Red Violet Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
RDZN	Roadzen Inc. Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Specialty Insurers	Nasdaq	2022
RDZNW	Roadzen Inc. Warrants	2026-06-08 16:48:03.166278+00	Finance	Specialty Insurers	Nasdaq	2022
REAL	The RealReal Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2019
REBN	Reborn Coffee Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Restaurants	Nasdaq	2022
REFI	Chicago Atlantic Real Estate Finance Inc. Common Stock	2026-06-08 16:48:03.166278+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2021
REFR	Research Frontiers Incorporated Common Stock	2026-06-08 16:48:03.166278+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
REG	Regency Centers Corporation Common Stock	2026-06-08 16:48:03.166278+00	Real Estate	Real Estate Investment Trusts	Nasdaq	1993
REGCO	Regency Centers Corporation 5.875% Series B Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.166278+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
REGCP	Regency Centers Corporation 6.25% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.166278+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
REGN	Regeneron Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1991
REKR	Rekor Systems Inc. Common Stock	2026-06-08 16:48:03.166278+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
RELL	Richardson Electronics Ltd. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Electronic Components	Nasdaq	1983
RELY	Remitly Global Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Business Services	Nasdaq	2021
RENT	Rent the Runway Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2021
RENX	RenX Enterprises Corp. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Real Estate	Nasdaq	\N
REPL	Replimune Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
REVB	Revelation Biosciences Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
REVBW	Revelation Biosciences Inc. Warrant	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
REYN	Reynolds Consumer Products Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Containers/Packaging	Nasdaq	2020
RFIL	RF Industries Ltd. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Electrical Products	Nasdaq	\N
RGCO	RGC Resources Inc. Common Stock	2026-06-08 16:48:03.166278+00	Utilities	Oil & Gas Production	Nasdaq	\N
RGEN	Repligen Corporation Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	1986
RGLD	Royal Gold Inc. Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Precious Metals	Nasdaq	\N
RGNX	REGENXBIO Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2015
RGP	Resources Connection Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Business Services	Nasdaq	\N
RGS	Regis Corporation Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Other Consumer Services	Nasdaq	1991
RGTI	Rigetti Computing Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	EDP Services	Nasdaq	\N
RGTIW	Rigetti Computing Inc. Warrants	2026-06-08 16:48:03.166278+00	Technology	EDP Services	Nasdaq	\N
RICK	RCI Hospitality Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Restaurants	Nasdaq	1995
RIGL	Rigel Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2000
RILY	BRC Group Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
RILYG	BRC Group Holdings Inc. 5.00% Senior Notes due 2026	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
RILYL	BRC Group Holdings Inc. Depositary Shares each representing 1/1000th in a share of 7.375% Series B Cumulative Perpetual Preferred Stock par value $0.0001	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
RILYN	BRC Group Holdings Inc. 6.50% Senior Notes Due 2026	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
RILYP	BRC Group Holdings Inc. Depositary Shares each representing a 1/1000th fractional interest in a share of Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
OLMA	Olema Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
RILYT	BRC Group Holdings Inc. 6.00% Senior Notes Due 2028	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
RILYZ	BRC Group Holdings Inc. 5.25% Senior Notes due 2028	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	\N
RIME	Algorhythm Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Staples	Diversified Electronic Products	Nasdaq	\N
RIOT	Riot Platforms Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	\N
RIVN	Rivian Automotive Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Auto Manufacturing	Nasdaq	2021
RJET	Republic Airways Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	2018
RKDA	Arcadia Biosciences Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	2015
RKLB	Rocket Lab Corporation Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Military/Government/Technical	Nasdaq	2020
RKTO	Rocket One Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
RLAY	Relay Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
RLMD	Relmada Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
RLYB	Rallybio Corporation Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
RMBI	Richmond Mutual Bancorporation Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Major Banks	Nasdaq	2019
RMBS	Rambus Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Semiconductors	Nasdaq	1997
RMCF	Rocky Mountain Chocolate Factory Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Staples	Specialty Foods	Nasdaq	\N
RMCO	Royalty Management Holding Corporation Class A Common Stock	2026-06-08 16:48:03.166278+00	Miscellaneous	Multi-Sector Companies	Nasdaq	2023
RMCOW	Royalty Management Holding Corporation Warrant	2026-06-08 16:48:03.166278+00	Miscellaneous	Multi-Sector Companies	Nasdaq	2023
RMIX	Suncrete Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Building Materials	Nasdaq	\N
RMNI	Rimini Street Inc. (DE) Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Business Services	Nasdaq	2015
RMR	The RMR Group Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Professional Services	Nasdaq	\N
RMSG	Real Messenger Corporation Ordinary Shares	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
RMSGW	Real Messenger Corporation Warrants	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
RMTI	Rockwell Medical Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1998
RNA	Atrium Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
RNAC	Cartesian Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
RNAZ	TransCode Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
RNGT	Range Capital Acquisition Corp II Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RNGTU	Range Capital Acquisition Corp II Units	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RNGTW	Range Capital Acquisition Corp II Warrants	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RNTX	Rein Therapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
RNXT	RenovoRx Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
ROAD	Construction Partners Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Military/Government/Technical	Nasdaq	2018
ROC	Rank One Computing Corporation Common stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2026
ROKU	Roku Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	2017
ROOT	Root Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Finance	Property-Casualty Insurers	Nasdaq	2020
ROP	Roper Technologies Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	1992
ROST	Ross Stores Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	1985
RPAY	Repay Holdings Corporation Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Business Services	Nasdaq	2018
RPD	Rapid7 Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2015
RPID	Rapid Micro Biosystems Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2021
RPRX	Royalty Pharma plc Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
RR	Richtech Robotics Inc. Class B Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Industrial Machinery/Components	Nasdaq	2023
RRBI	Red River Bancshares Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2019
RREV	RRE Ventures Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
RREVW	RRE Ventures Acquisition Corp. Warrants	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
RRGB	Red Robin Gourmet Burgers Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Restaurants	Nasdaq	2002
RRR	Red Rock Resorts Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2016
RSSS	Research Solutions Inc Common Stock	2026-06-08 16:48:03.166278+00	Technology	EDP Services	Nasdaq	\N
RSVR	Reservoir Media Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2021
RSVRW	Reservoir Media Inc. Warrant	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2021
RTAC	Renatus Tactical Acquisition Corp I Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RTACU	Renatus Tactical Acquisition Corp I Unit	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RTACW	Renatus Tactical Acquisition Corp I Warrant	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2025
RTB	RTB Digital Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Professional Services	Nasdaq	\N
RUM	Rumble Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
RUMBW	Rumble Inc. Warrant	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
RUN	Sunrun Inc. Common Stock	2026-06-08 16:48:03.166278+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2015
RUSHA	Rush Enterprises Inc. Common Stock Cl A	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	\N
RUSHB	Rush Enterprises Inc. Class B	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	\N
RVMD	Revolution Medicines Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
RVMDW	Revolution Medicines Inc. Warrant	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
RVSB	Riverview Bancorp Inc Common Stock	2026-06-08 16:48:03.166278+00	Finance	Savings Institutions	Nasdaq	\N
RWAY	Runway Growth Finance Corp. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	2021
RWAYI	Runway Growth Finance Corp. 7.25% Notes due 2031	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	\N
RWAYL	Runway Growth Finance Corp. 7.50% Notes due 2027	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	\N
RXRX	Recursion Pharmaceuticals Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
RXST	RxSight Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Ophthalmic Goods	Nasdaq	2021
RXT	Rackspace Technology Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2020
RYM	RYTHM Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	2021
RYTM	Rhythm Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
RZLT	Rezolute Inc. Common Stock (NV)	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
SAAQ	Space Asset Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
SAAQU	Space Asset Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
SAAQW	Space Asset Acquisition Corp. Warrants	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
SABR	Sabre Corporation Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2014
SABS	SAB Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
SABSW	SAB Biotherapeutics Inc. Warrant	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
SAFT	Safety Insurance Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Property-Casualty Insurers	Nasdaq	2002
SAFX	XCF Global Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Major Chemicals	Nasdaq	\N
SAIA	Saia Inc. Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Trucking Freight/Courier Services	Nasdaq	\N
SAIC	Science Applications International Corporation Common Stock	2026-06-08 16:48:03.166278+00	Technology	EDP Services	Nasdaq	\N
SAIL	SailPoint Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
SAMG	Silvercrest Asset Management Group Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Finance	Investment Managers	Nasdaq	2013
SANA	Sana Biotechnology Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
SANM	Sanmina Corporation Common Stock	2026-06-08 16:48:03.166278+00	Technology	Electrical Products	Nasdaq	1993
SATA	Strive Inc. Variable Rate Series A Perpetual Preferred Stock	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	\N
SATS	EchoStar  Corporation Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	\N
SBAC	SBA Communications Corporation Class A Common Stock	2026-06-08 16:48:03.166278+00	Real Estate	Real Estate Investment Trusts	Nasdaq	1999
SBC	SBC Medical Group Holdings Incorporated Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical/Nursing Services	Nasdaq	2022
SBCF	Seacoast Banking Corporation of Florida Common Stock	2026-06-08 16:48:03.166278+00	Finance	Major Banks	Nasdaq	\N
SBCWW	SBC Medical Group Holdings Incorporated Warrants	2026-06-08 16:48:03.166278+00	Health Care	Medical/Nursing Services	Nasdaq	2022
SBET	Sharplink Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
SBFG	SB Financial Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Major Banks	Nasdaq	\N
SBGI	Sinclair Inc. Class A Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Broadcasting	Nasdaq	1995
SBRA	Sabra Health Care REIT Inc. Common Stock	2026-06-08 16:48:03.166278+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SBUX	Starbucks Corporation Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Restaurants	Nasdaq	1992
SCHL	Scholastic Corporation Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Books	Nasdaq	1992
SCII	SC II Acquisition Corp. Class A ordinary share	2026-06-08 16:48:03.166278+00	\N	\N	Nasdaq	2026
SGP	SpyGlass Pharma Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2026
SGRP	SPAR Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Business Services	Nasdaq	\N
SGRY	Surgery Partners Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Hospital/Nursing Management	Nasdaq	2015
SHAZ	SharonAI Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Technology	EDP Services	Nasdaq	\N
SHBI	Shore Bancshares Inc Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	\N
SHC	Sotera Health Company Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Misc Health and Biotechnology Services	Nasdaq	2020
SHEN	Shenandoah Telecommunications Co Common Stock	2026-06-08 16:48:03.181061+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
SHFS	SHF Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	2021
SHFSW	SHF Holdings Inc. Warrants	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	2021
SHIM	Shimmick Corporation Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Military/Government/Technical	Nasdaq	2023
SHLS	Shoals Technologies Group Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	2021
SHOO	Steven Madden Ltd. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Shoe Manufacturing	Nasdaq	1993
SHPH	Shuttle Pharmaceuticals Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
SIBN	SI-BONE Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2018
SIDU	Sidus Space Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Telecommunications	Telecommunications Equipment	Nasdaq	2021
SIEB	Siebert Financial Corp. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
SIGA	SIGA Technologies Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PEGA	Pegasystems Inc. Common Stock	2026-06-08 16:48:03.14768+00	Technology	EDP Services	Nasdaq	1996
SIGI	Selective Insurance Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Property-Casualty Insurers	Nasdaq	\N
SIGIP	Selective Insurance Group Inc. Depositary Shares each representing a 1/1000th interest in a share of 4.60% Non-Cumulative Preferred Stock Series B	2026-06-08 16:48:03.181061+00	Finance	Property-Casualty Insurers	Nasdaq	\N
SILO	Silo Pharma Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Apparel	Nasdaq	\N
SIMA	SIM Acquisition Corp. I Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2024
SIMAU	SIM Acquisition Corp. I Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2024
SIMAW	SIM Acquisition Corp. I Warrant	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2024
SINT	SiNtx Technologies Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2014
SION	Sionna Therapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
SIRI	SiriusXM Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Broadcasting	Nasdaq	\N
SITM	SiTime Corporation Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	2019
SKIN	SkinHealth Systems Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2020
SKWD	Skyward Specialty Insurance Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Property-Casualty Insurers	Nasdaq	2023
SKYA	SkyAI Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2022
SKYAW	SkyAI Inc. Warrant	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	2022
SKYE	Skye Bioscience Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
SKYQ	Sky Quarry Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Environmental Services	Nasdaq	2024
SKYT	SkyWater Technology Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	2021
SKYW	SkyWest Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	1986
SKYX	SKYX Platforms Corp. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Building Products	Nasdaq	2022
SLAB	Silicon Laboratories Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	2000
SLDB	Solid Biosciences Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
SLDE	Slide Insurance Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Property-Casualty Insurers	Nasdaq	2025
SLDP	Solid Power Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
SLDPW	Solid Power Inc. Warrant	2026-06-08 16:48:03.181061+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
SLE	Super League Enterprise Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2019
SLM	SLM Corporation Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	\N
SLMBP	SLM Corporation Floating Rate Non-Cumulative Preferred Stock Series B	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	\N
SLNG	Stabilis Solutions Inc. Common Stock	2026-06-08 16:48:03.181061+00	Utilities	Oil/Gas Transmission	Nasdaq	\N
SLNH	Soluna Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	EDP Services	Nasdaq	\N
SLNHP	Soluna Holdings Inc 9.0% Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.181061+00	Technology	EDP Services	Nasdaq	\N
SLP	Simulations Plus Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	EDP Services	Nasdaq	\N
SLRC	SLR Investment Corp. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance/Investors Services	Nasdaq	2010
SLS	SELLAS Life Sciences Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
SLSN	Solesence Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	\N
SMBC	Southern Missouri Bancorp Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Banks	Nasdaq	\N
SMCI	Super Micro Computer Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Manufacturing	Nasdaq	2020
SMID	Smith-Midland Corporation Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Building Materials	Nasdaq	\N
SMMT	Summit Therapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
SMPL	The Simply Good Foods Company Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Packaged Foods	Nasdaq	\N
SMSI	Smith Micro Software Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1995
SMTC	Semtech Corporation Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	\N
SMTI	Sanara MedTech Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Industrial Specialties	Nasdaq	\N
SMTK	SmartKem Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	\N
SMXT	Solarmax Technology Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Engineering & Construction	Nasdaq	2024
SNAL	Snail Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2022
SNBR	Sleep Number Corporation Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Home Furnishings	Nasdaq	\N
SND	Smart Sand Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	Nasdaq	2016
SNDX	Syndax Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
SNES	SenesTech Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Agricultural Chemicals	Nasdaq	2016
SNEX	StoneX Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
SNFCA	Security National Financial Corporation Class A Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	\N
SNGX	Soligenix Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
SNOA	Sonoma Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2007
SNPS	Synopsys Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1992
SNSE	Sensei Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
SNTI	Senti Biosciences Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
SNWV	SANUWAVE Health Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
SNYR	Synergy CHC Corp. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Other Pharmaceuticals	Nasdaq	2024
ALXO	ALX Oncology Holdings Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
ALZN	Alzamend Neuro Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
AMAL	Amalgamated Financial Corp. Common Stock (DE)	2026-06-08 16:48:03.020027+00	Finance	Major Banks	Nasdaq	2018
AMAN	Amanat Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AMAT	Applied Materials Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	1972
PRAA	PRA Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	2002
PRAX	Praxis Precision Medicines Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
PRCH	Porch Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
PRCT	PROCEPT BioRobotics Corporation Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
PROK	ProKidney Corp. Class A Ordinary Shares	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
PRSO	Peraso Inc. Common Stock	2026-06-08 16:48:03.166278+00	Technology	Semiconductors	Nasdaq	\N
SOCA	Solarius Capital Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SOCAU	Solarius Capital Acquisition Corp. Units	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SOFI	SoFi Technologies Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	\N
SOLS	Solstice Advanced Materials Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Aerospace	Nasdaq	\N
SONM	DNA X Inc. Common Stock	2026-06-08 16:48:03.181061+00	Utilities	Telecommunications Equipment	Nasdaq	2019
SONO	Sonos Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Consumer Electronics/Appliances	Nasdaq	2018
SORN	Soren Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SORNU	Soren Acquisition Corp. Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SORNW	Soren Acquisition Corp. Warrant	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SOTK	Sono-Tek Corporation Common Stock	2026-06-08 16:48:03.181061+00	Technology	Industrial Machinery/Components	Nasdaq	\N
SOUN	SoundHound AI Inc Class A Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
SOUNW	SoundHound AI Inc. Warrant	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2021
SOWG	Sow Good Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Packaged Foods	Nasdaq	\N
SPAI	Safe Pro Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Industrial Specialties	Nasdaq	2024
SPEG	Silver Pegasus Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SPEGU	Silver Pegasus Acquisition Corp Unit	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SPFI	South Plains Financial Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	2019
SPKL	Spark I Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2023
SPKLU	Spark I Acquisition Corp. Unit	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2023
SPKLW	Spark I Acquisition Corp. Warrant	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2023
SPOK	Spok Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
SPRB	Spruce Biosciences Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
SPRO	Spero Therapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
SPRY	ARS Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
SPSC	SPS Commerce Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2010
SPT	Sprout Social Inc Class A Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2019
SPTX	Seaport Therapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2026
SPWH	Sportsman's Warehouse Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2014
SPWR	SunPower Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	\N
SPWRW	SunPower Inc. Warrants	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	\N
SQFT	Presidio Property Trust Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2020
SQFTP	Presidio Property Trust Inc. 9.375% Series D Cumulative Redeemable Perpetual Preferred Stock $0.01 par value per share	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SQFTW	Presidio Property Trust Inc. Series A Common Stock Purchase Warrants	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SRBK	SR Bancorp Inc. Common stock	2026-06-08 16:48:03.181061+00	Finance	Banks	Nasdaq	2023
SRCE	1st Source Corporation Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	\N
SRPT	Sarepta Therapeutics Inc. Common Stock (DE)	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
SRRK	Scholar Rock Holding Corporation Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
SRTA	Strata Critical Medical Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Transportation Services	Nasdaq	2019
SRTS	Sensus Healthcare Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2016
SRZN	Surrozen Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
SRZNW	Surrozen Inc. Warrant	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
SSAC	SPACSphere Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SSACR	SPACSphere Acquisition Corp. Rights	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SSACU	SPACSphere Acquisition Corp. Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SSACW	SPACSphere Acquisition Corp. Warrant	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SSBI	Summit State Bank Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	2006
SSEA	Starry Sea Acquisition Corp\tOrdinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SSNC	SS&C Technologies Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2010
SSP	E.W. Scripps Company (The) Class A Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Broadcasting	Nasdaq	\N
SSSS	SuRo Capital Corp. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	2011
SSSSL	SuRo Capital Corp. 6.00% Notes due 2026	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	\N
SSTI	SoundThinking Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2017
SSYS	Stratasys Ltd. Ordinary Shares (Israel)	2026-06-08 16:48:03.181061+00	Technology	Computer peripheral equipment	Nasdaq	1994
STAA	STAAR Surgical Company Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Ophthalmic Goods	Nasdaq	\N
STBA	S&T Bancorp Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	\N
STEP	StepStone Group Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Finance	Investment Managers	Nasdaq	2020
STEX	Streamex Corp. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
STHO	Star Holdings Shares of Beneficial Interest	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate	Nasdaq	\N
STI	Solidion Technology Inc. Common Stock	2026-06-08 16:48:03.181061+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2022
STIM	Neuronetics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2018
STKS	The ONE Group Hospitality Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Restaurants	Nasdaq	\N
STLD	Steel Dynamics Inc.	2026-06-08 16:48:03.181061+00	Industrials	Steel/Iron Ore	Nasdaq	1996
STOK	Stoke Therapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
STRA	Strategic Education Inc. Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Other Consumer Services	Nasdaq	1996
STRC	Strategy Inc Variable Rate Series A Perpetual Stretch Preferred Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
STRD	Strategy Inc 10.00% Series A Perpetual Stride Preferred Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
STRF	Strategy Inc 10.00% Series A Perpetual Strife Preferred Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
STRK	Strategy Inc 8.00% Series A Perpetual Strike Preferred Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
STRL	Sterling Infrastructure Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Military/Government/Technical	Nasdaq	\N
STRO	Sutro Biopharma Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
STRR	Star Equity Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Professional Services	Nasdaq	\N
STRRP	Star Equity Holdings Inc. 10% Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	\N
STRS	Stratus Properties Inc. Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Homebuilding	Nasdaq	\N
STRT	STRATTEC SECURITY CORPORATION Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
STRZ	Starz Entertainment Corp. Common Shares	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Movies/Entertainment	Nasdaq	\N
STTK	Shattuck Labs Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
SUIG	Sui Group Holdings Limited Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance Companies	Nasdaq	\N
SUJA	Suja Life Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	2026
SUNE	SUNation Energy Inc. Common Stock	2026-06-08 16:48:03.181061+00	Utilities	Telecommunications Equipment	Nasdaq	\N
SUNS	Sunrise Realty Trust Inc. Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SUPN	Supernus Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2012
SURG	SurgePays Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Advertising	Nasdaq	\N
SVAC	Spring Valley Acquisition Corp. III Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SVACW	Spring Valley Acquisition Corp. III Warrant	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SVAQ	Silicon Valley Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SVAQU	Silicon Valley Acquisition Corp. Units	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SVAQW	Silicon Valley Acquisition Corp. Warrants	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SVC	Service Properties Trust Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SVCC	Stellar V Capital Corp. Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SVCCU	Stellar V Capital Corp. Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SVCCW	Stellar V Capital Corp. Warrant	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SVCO	Silvaco Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2024
SVIV	Spring Valley Acquisition Corp. IV Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SVIVU	Spring Valley Acquisition Corp. IV Units	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SVIVW	Spring Valley Acquisition Corp. IV Warrants	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2026
SVRA	Savara Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
SWAGW	Stran & Company Inc. Warrant	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Advertising	Nasdaq	2021
SWBI	Smith & Wesson Brands Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Ordnance And Accessories	Nasdaq	\N
SWIM	Latham Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Plastic Products	Nasdaq	2021
SWKHL	SWK Holdings Corporation 9.00% Senior Notes due 2027	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	\N
SWKS	Skyworks Solutions Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	\N
SWMR	Swarmer Inc Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2026
SXTP	60 Degrees Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
SYBT	Stock Yards Bancorp Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	\N
SYM	Symbotic Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Industrial Machinery/Components	Nasdaq	2021
SYNA	Synaptics Incorporated Common Stock $0.001 Par Value	2026-06-08 16:48:03.181061+00	Technology	Semiconductors	Nasdaq	2002
SYPR	Sypris Solutions Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
SYRE	Spyre Therapeutics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2016
SZZL	Sizzle Acquisition Corp. II Class A ordinary shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SZZLR	Sizzle Acquisition Corp. II Right	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SZZLU	Sizzle Acquisition Corp. II Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACH	Titan Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACHU	Titan Acquisition Corp. Units	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACHW	Titan Acquisition Corp. Warrants	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACO	Berto Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACOU	Berto Acquisition Corp. Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACOW	Berto Acquisition Corp. Warrant	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
TACT	TransAct Technologies Incorporated Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer peripheral equipment	Nasdaq	1996
TALK	Talkspace Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Nursing Services	Nasdaq	2020
TALKW	Talkspace Inc. Warrant	2026-06-08 16:48:03.181061+00	Health Care	Medical/Nursing Services	Nasdaq	2020
TAOX	Tao Synergies Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TARA	Protara Therapeutics Inc.  Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2014
TARS	Tarsus Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
TASK	TaskUs Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Technology	EDP Services	Nasdaq	2021
TAVI	Tavia Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2024
TAVIR	Tavia Acquisition Corp. Right	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2024
TAVIU	Tavia Acquisition Corp. Unit	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2024
TAYD	Taylor Devices Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
TBBK	The Bancorp Inc Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	2004
TBCH	Turtle Beach Corporation Common Stock	2026-06-08 16:48:03.181061+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
TMUSI	T-Mobile US Inc. 5.500% Senior Notes due June 2070	2026-06-08 16:48:03.196479+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
TMUSL	T-Mobile US Inc. 6.250% Senior Notes due 2069	2026-06-08 16:48:03.196479+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
TMUSZ	T-Mobile US Inc. 5.500% Senior Notes due March 2070	2026-06-08 16:48:03.196479+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
TNDM	Tandem Diabetes Care Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	2013
TNGX	Tango Therapeutics Inc.	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
TNON	Tenon Medical Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	2022
TNXP	Tonix Pharmaceuticals Holding Corp. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TNYA	Tenaya Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
TOI	The Oncology Institute Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Nursing Services	Nasdaq	2020
TOIIW	The Oncology Institute Inc. Warrant	2026-06-08 16:48:03.196479+00	Health Care	Medical/Nursing Services	Nasdaq	2020
TOMZ	TOMI Environmental Solutions Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Major Chemicals	Nasdaq	\N
TONX	TON Strategy Company Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
TPCS	TechPrecision Corporation Common stock	2026-06-08 16:48:03.196479+00	Industrials	Metal Fabrications	Nasdaq	\N
TPG	TPG Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Managers	Nasdaq	2022
TPGXL	TPG Operating Group II L.P. 6.950% Fixed-Rate Junior Subordinated Notes due 2064	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	\N
TPST	Tempest Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TRAW	Traws Pharma Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
TRAX	First Tracks Biotherapeutics Inc. Ordinary Shares	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TRDA	Entrada Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
TREE	LendingTree Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Finance: Consumer Services	Nasdaq	\N
TRGS	TRG Latin America Acquisitions Corp. Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2026
TRGSR	TRG Latin America Acquisitions Corp. Rights	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2026
TRI	Thomson Reuters Corporation Common Shares	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Publishing	Nasdaq	\N
TRIN	Trinity Capital Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Finance: Consumer Services	Nasdaq	2021
TRINI	Trinity Capital Inc. 7.875% Notes Due 2029	2026-06-08 16:48:03.196479+00	Finance	Finance: Consumer Services	Nasdaq	\N
TRINZ	Trinity Capital Inc. 7.875% Notes due 2029	2026-06-08 16:48:03.196479+00	Finance	Finance: Consumer Services	Nasdaq	\N
TRIP	TripAdvisor Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
TRMB	Trimble Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Industrial Machinery/Components	Nasdaq	1990
TRMK	Trustmark Corporation Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
TRNR	Interactive Strength Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Consumer Electronics/Appliances	Nasdaq	2023
TRNS	Transcat Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Electrical Products	Nasdaq	\N
TRON	Tron Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	2023
TROW	T. Rowe Price Group Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	1986
TRS	TriMas Corporation Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Industrial Specialties	Nasdaq	2007
TRUG	TruGolf Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	2021
TRUP	Trupanion Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical Specialities	Nasdaq	\N
TRVI	Trevi Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
TSBK	Timberland Bancorp Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Banks	Nasdaq	\N
TSCO	Tractor Supply Company Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	1994
TSHA	Taysha Gene Therapies Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
TSLA	Tesla Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Auto Manufacturing	Nasdaq	2010
TSSI	TSS Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Professional Services	Nasdaq	\N
TTAN	ServiceTitan Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2024
TTD	The Trade Desk Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2016
TTEC	TTEC Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Professional Services	Nasdaq	1996
TTEK	Tetra Tech Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Military/Government/Technical	Nasdaq	1991
TTGT	TechTarget Inc. Common Stock	2026-06-08 16:48:03.196479+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
TTMI	TTM Technologies Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Electrical Products	Nasdaq	2000
TTRX	Turn Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TTWO	Take-Two Interactive Software Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	1997
TULP	Bloomia Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	\N
TUSK	Mammoth Energy Services Inc. Common Stock	2026-06-08 16:48:03.196479+00	Energy	Oilfield Services/Equipment	Nasdaq	2016
TVA	Texas Ventures Acquisition III Corp Class A Ordinary Share	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TVACW	Texas Ventures Acquisition III Corp Warrants	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TVAI	Thayer Ventures Acquisition Corporation II Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TVAIR	Thayer Ventures Acquisition Corporation II Rights	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TVAIU	Thayer Ventures Acquisition Corporation II Unit	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
TVGN	Tevogen Bio Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2022
TVGNW	Tevogen Bio Holdings Inc. Warrant	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2022
TVRD	Tvardi Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
TVTX	Travere Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TW	Tradeweb Markets Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	2019
TWAV	TaoWeave Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Programming Data Processing	Nasdaq	\N
TWFG	TWFG Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Finance	Specialty Insurers	Nasdaq	2024
TWIN	Twin Disc Incorporated Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
TWLV	Twelve Seas Investment Company III Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2026
TWLVR	Twelve Seas Investment Company III Rights	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2026
TWLVU	Twelve Seas Investment Company III Units	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
TWST	Twist Bioscience Corporation Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
TXG	10x Genomics Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2019
TXMD	TherapeuticsMD Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TXN	Texas Instruments Incorporated Common Stock	2026-06-08 16:48:03.196479+00	Technology	Semiconductors	Nasdaq	\N
TXRH	Texas Roadhouse Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Restaurants	Nasdaq	2004
TYGO	Tigo Energy Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Semiconductors	Nasdaq	2021
TYRA	Tyra Biosciences Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
TZOO	Travelzoo Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Advertising	Nasdaq	\N
UAL	United Airlines Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	\N
UBCP	United Bancorp Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
UBSI	United Bankshares Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
UCTT	Ultra Clean Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Semiconductors	Nasdaq	2004
UEIC	Universal Electronics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Staples	Consumer Electronics/Appliances	Nasdaq	1993
UFCS	United Fire Group Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Property-Casualty Insurers	Nasdaq	\N
UFPI	UFP Industries Inc. Common Stock	2026-06-08 16:48:03.196479+00	Basic Materials	Forest Products	Nasdaq	1993
UFPT	UFP Technologies Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	1993
UG	United-Guardian Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	\N
UGRO	urban-gro Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Industrial Specialties	Nasdaq	\N
UK	Ucommune International Ltd Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Business Services	Nasdaq	2019
ULBI	Ultralife Corporation Common Stock	2026-06-08 16:48:03.196479+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	1992
ULCC	Frontier Group Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	2021
ULH	Universal Logistics Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Trucking Freight/Courier Services	Nasdaq	2005
ULTA	Ulta Beauty Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2007
UMBF	UMB Financial Corporation Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
AMBA	Ambarella Inc. Ordinary Shares	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	2012
AMCI	AMC Robotics Corporation Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Home Furnishings	Nasdaq	2023
AMCX	AMC Global Media Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Telecommunications	Cable & Other Pay Television Services	Nasdaq	\N
AMD	Advanced Micro Devices Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	\N
AMGN	Amgen Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	1983
AMIX	Autonomix Medical Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	2024
AMKR	Amkor Technology Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	1998
AMLX	Amylyx Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
AMOD	Alpha Modus Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
AMODW	Alpha Modus Holdings Inc. Warrant	2026-06-08 16:48:03.020027+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
AMPG	Amplitech Group Inc. Common Stock	2026-06-08 16:48:03.020027+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
AMPGR	Amplitech Group Inc. Series A Right	2026-06-08 16:48:03.020027+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
SCIIU	SC II Acquisition Corp. Units	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SCKT	Socket Mobile Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Manufacturing	Nasdaq	\N
SCLX	Scilex Holding Company Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
SCLXW	Scilex Holding Company Warrant	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
SCNX	Scienture Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Other Pharmaceuticals	Nasdaq	\N
SCOR	comScore Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Business Services	Nasdaq	2018
SCPQ	Social Commerce Partners Corporation Class A Ordinary Shares	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2026
SCPQU	Social Commerce Partners Corporation Unit	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SCPQW	Social Commerce Partners Corporation Warrant	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2026
SCSC	ScanSource Inc. Common Stock	2026-06-08 16:48:03.181061+00	Technology	Retail: Computer Software & Peripheral Equipment	Nasdaq	\N
SCVL	Shoe Carnival Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	1993
UMBFO	UMB Financial Corporation Depositary Shares Each Representing a 1/400th Interest in a Share of 7.750% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
UNB	Union Bankshares Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
UNCY	Unicycive Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
UNIT	Uniti Group Inc. Common Stock	2026-06-08 16:48:03.196479+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
UNTY	Unity Bancorp Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
UONE	Urban One Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Broadcasting	Nasdaq	\N
UONEK	Urban One Inc. Class D Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Broadcasting	Nasdaq	\N
UPB	Upstream Bio Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
UPBD	Upbound Group Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	\N
UPLD	Upland Software Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2014
UPST	Upstart Holdings Inc. Common stock	2026-06-08 16:48:03.196479+00	Finance	Finance: Consumer Services	Nasdaq	2020
UPWK	Upwork Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	EDP Services	Nasdaq	2018
UPXI	Upexi Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	2021
URBN	Urban Outfitters Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	1993
USAR	USA Rare Earth Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Basic Materials	Metal Mining	Nasdaq	2023
USAU	U.S. Gold Corp. Common Stock	2026-06-08 16:48:03.196479+00	Basic Materials	Metal Mining	Nasdaq	\N
USCB	USCB Financial Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	2021
USEG	U.S. Energy Corp. Common Stock (DE)	2026-06-08 16:48:03.196479+00	Energy	Oil & Gas Production	Nasdaq	\N
USGO	U.S. GoldMining Inc. Common stock	2026-06-08 16:48:03.196479+00	Basic Materials	Precious Metals	Nasdaq	2023
USIO	Usio Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
USLM	United States Lime & Minerals Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	Nasdaq	\N
UTHR	United Therapeutics Corporation Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1999
UTMD	Utah Medical Products Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
UVSP	Univest Financial Corporation Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
UYSC	UY Scuti Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
UYSCU	UY Scuti Acquisition Corp. Units	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
VABK	Virginia National Bankshares Corporation Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
VACH	Voyager Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2024
VACHU	Voyager Acquisition Corp Unit	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2024
VACHW	Voyager Acquisition Corp Warrants	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2024
VALU	Value Line Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Managers	Nasdaq	1983
VANI	Vivani Medical Inc. Common Stock (DE)	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2014
VBIO	Valion Bio Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2021
VBNB	VanEck BNB ETF Common Shares of Beneficial Interest	2026-06-08 16:48:03.196479+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
VC	Visteon Corporation Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
VCEL	Vericel Corporation Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
VCTR	Victory Capital Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Managers	Nasdaq	2018
VCYT	Veracyte Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical Specialities	Nasdaq	2013
VECO	Veeco Instruments Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Industrial Machinery/Components	Nasdaq	1994
VEEA	Veea Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2021
VEEAW	Veea Inc. Warrant	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2021
VEEE	Twin Vee PowerCats Co. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Marine Transportation	Nasdaq	2021
VELO	Velo3D Inc. Common stock	2026-06-08 16:48:03.196479+00	Technology	Industrial Machinery/Components	Nasdaq	\N
VERA	Vera Therapeutics Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
VERI	Veritone Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	EDP Services	Nasdaq	2017
VERU	Veru Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
VERX	Vertex Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
VGAS	Verde Clean Fuels Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Major Chemicals	Nasdaq	2021
VGASW	Verde Clean Fuels Inc. Warrant	2026-06-08 16:48:03.196479+00	Industrials	Major Chemicals	Nasdaq	2021
VHC	VirnetX Holding Corp Common Stock	2026-06-08 16:48:03.196479+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
VHCP	Vine Hill Capital Investment Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2026
VHCPU	Vine Hill Capital Investment Corp. II Units	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
VHCPW	Vine Hill Capital Investment Corp. II Warrants	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2026
VHUB	VenHub Global Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Industrial Machinery/Components	Nasdaq	\N
VIASP	Via Renewables Inc. 8.75% Series A Fixed-to-Floating Rate Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.196479+00	Utilities	Power Generation	Nasdaq	\N
VIAV	Viavi Solutions Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Semiconductors	Nasdaq	\N
VICR	Vicor Corporation Common Stock	2026-06-08 16:48:03.196479+00	Technology	Industrial Machinery/Components	Nasdaq	\N
VIR	Vir Biotechnology Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
VIRC	Virco Manufacturing Corporation Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Industrial Specialties	Nasdaq	\N
VISN	Vistance Networks Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	2013
VITL	Vital Farms Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Staples	Packaged Foods	Nasdaq	2020
VIVK	Vivakor Inc. Common Stock	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	\N
VIVS	VivoSim Labs Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
VKTX	Viking Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
VLGEA	Village Super Market Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Consumer Staples	Food Chains	Nasdaq	\N
VLY	Valley National Bancorp Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
VLYPN	Valley National Bancorp 8.250% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series C	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
VLYPO	Valley National Bancorp 5.50% Fixed-to-Floating Rate Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
VLYPP	Valley National Bancorp 6.25% Fixed-to-Floating Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
VMD	Viemed Healthcare Inc. Common Shares	2026-06-08 16:48:03.196479+00	Health Care	Misc Health and Biotechnology Services	Nasdaq	\N
VNCE	Vince Holding Corp. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	\N
VNDA	Vanda Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2006
VNME	Vendome Acquisition Corporation I Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
VNMEU	Vendome Acquisition Corporation I Unit	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
VNMEW	Vendome Acquisition Corporation I Warrant	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
SNDK	Sandisk Corporation Common Stock	2026-06-08 16:48:03.181061+00	Technology	Electronic Components	Nasdaq	\N
VNOM	Viper Energy Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Energy	Oil & Gas Production	Nasdaq	2014
VOR	Vor Biopharma Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
VRA	Vera Bradley Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Apparel	Nasdaq	2010
VRCA	Verrica Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
VRDN	Viridian Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical Specialities	Nasdaq	2014
VREX	Varex Imaging Corporation Common Stock	2026-06-08 16:48:03.196479+00	Technology	Industrial Machinery/Components	Nasdaq	\N
VRM	Vroom Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	\N
VRME	VerifyMe Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	EDP Services	Nasdaq	\N
VRNS	Varonis Systems Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2014
VRRM	Verra Mobility Corporation Class A Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Transportation Services	Nasdaq	2017
VRSK	Verisk Analytics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Diversified Commercial Services	Nasdaq	2009
VRSN	VeriSign Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	EDP Services	Nasdaq	1998
VRTX	Vertex Pharmaceuticals Incorporated Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1991
VSAT	ViaSat Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	1996
VSEC	VSE Corporation Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Military/Government/Technical	Nasdaq	\N
VSECU	VSE Corporation Tangible Equity Units	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	\N
VSEE	VSee Health Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Nursing Services	Nasdaq	2021
VSNT	Versant Media Group Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Broadcasting	Nasdaq	\N
VSTD	Vestand Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Restaurants	Nasdaq	2022
VSTM	Verastem Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2012
VTGN	Vistagen Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
VTIX	Virtuix Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer peripheral equipment	Nasdaq	\N
WING	Wingstop Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Restaurants	Nasdaq	2015
WKHS	Workhorse Group Inc. Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Auto Manufacturing	Nasdaq	\N
WLDN	Willdan Group Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Military/Government/Technical	Nasdaq	2006
WLFC	Willis Lease Finance Corporation Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Industrial Specialties	Nasdaq	1996
WLII	Willow Lane Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
WLIIW	Willow Lane Acquisition Corp. II Warrants	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
WLTH	Wealthfront Corporation Common Stock	2026-06-08 16:48:03.212596+00	Finance	Finance: Consumer Services	Nasdaq	2025
WMG	Warner Music Group Corp. Class A Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2020
WMT	Walmart Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Department/Specialty Retail Stores	Nasdaq	\N
WNEB	Western New England Bancorp Inc. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Savings Institutions	Nasdaq	\N
WOOF	Petco Health and Wellness Company Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2021
WRAP	Wrap Technologies Inc. Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Ordnance And Accessories	Nasdaq	\N
WRLD	World Acceptance Corporation Common Stock	2026-06-08 16:48:03.212596+00	Finance	Finance: Consumer Services	Nasdaq	1991
WSBCO	WesBanco Inc. Depositary Shares each representing 1/40th interest in a share of 7.375% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WSBF	Waterstone Financial Inc. Common Stock (MD)	2026-06-08 16:48:03.212596+00	Finance	Savings Institutions	Nasdaq	2005
WSBK	Winchester Bancorp Inc. Common Stock	2026-06-08 16:48:03.212596+00	\N	\N	Nasdaq	2025
WSC	WillScot Holdings Corporation Class A Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Misc Corporate Leasing Services	Nasdaq	2015
WSFS	WSFS Financial Corporation Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WTBA	West Bancorporation Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WTFC	Wintrust Financial Corporation Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WTFCN	Wintrust Financial Corporation Depositary Shares Each Representing a 1/1000th Interest in a Share of 7.875% Fixed-Rate Reset Non-Cumulative Perpetual Preferred StocK	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WULF	TeraWulf Inc. Common Stock	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	\N
WVVI	Willamette Valley Vineyards Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
WVVIP	Willamette Valley Vineyards Inc. Series A Redeemable Preferred Stock	2026-06-08 16:48:03.212596+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
WW	WW International Inc.  Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
WWD	Woodward Inc. Common Stock	2026-06-08 16:48:03.212596+00	Energy	Industrial Machinery/Components	Nasdaq	\N
WYFI	WhiteFiber Inc. Ordinary Shares	2026-06-08 16:48:03.212596+00	Finance	Finance: Consumer Services	Nasdaq	2025
WYNN	Wynn Resorts Limited Common stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2002
XAIR	Beyond Air Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
XBIO	Xenetic Biosciences Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
XBIT	XBiotech Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
XBP	XBP Global Holdings Inc. Common Stock	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	2021
XBPEW	XBP Europe Holdings Inc. Warrant	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	2021
XCBE	X3 Acquisition Corp. Ltd. Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	\N	\N	Nasdaq	2026
XCBEU	X3 Acquisition Corp. Ltd. Unit	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
XCUR	Exicure Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
XE	X-Energy Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Metal Fabrications	Nasdaq	2026
XEL	Xcel Energy Inc. Common Stock	2026-06-08 16:48:03.212596+00	Utilities	Power Generation	Nasdaq	\N
XELB	Xcel Brands Inc. Common Stock	2026-06-08 16:48:03.212596+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
XELLL	Xcel Energy Inc. 6.25% Junior Subordinated Notes Series due 2085	2026-06-08 16:48:03.212596+00	Utilities	Power Generation	Nasdaq	\N
XERS	Xeris Biopharma Holdings Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
XFOR	X4 Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2017
XGN	Exagen Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Medical Specialities	Nasdaq	2019
XHLD	TEN Holdings Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Business Services	Nasdaq	2025
XLO	Xilio Therapeutics Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
XMAX	XMAX Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Home Furnishings	Nasdaq	\N
XMTR	Xometry Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Business Services	Nasdaq	2021
XNCR	Xencor Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2013
XOMA	XOMA Royalty Corporation Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	1986
XOMAO	XOMA Royalty Corporation Depositary Shares Rep Series B 8.375% Cumulative Preferred Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
XOMAP	XOMA Royalty Corporation 8.625% Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
XOS	Xos Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	2020
XOSWW	Xos Inc. Warrants	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	2020
XPEL	XPEL Inc. Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Industrial Specialties	Nasdaq	\N
XPON	Expion360 Inc. Common Stock	2026-06-08 16:48:03.212596+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2022
XRAY	DENTSPLY SIRONA Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Medical/Dental Instruments	Nasdaq	1987
XRPN	Armada Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2025
XRPNW	Armada Acquisition Corp. II Warrant	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2025
XRX	Xerox Holdings Corporation Common Stock	2026-06-08 16:48:03.212596+00	Technology	Computer peripheral equipment	Nasdaq	\N
XRXDW	Xerox Holdings Corporation Warrants	2026-06-08 16:48:03.212596+00	Technology	Computer peripheral equipment	Nasdaq	\N
XSLL	Xsolla SPAC 1 Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
XSLLU	Xsolla SPAC 1 Units	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
XSLLW	Xsolla SPAC 1 Warrants	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
XTIA	XTI Aerospace Inc. Common Stock	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	2014
XWEL	XWELL Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Other Consumer Services	Nasdaq	\N
XXII	22nd Century Group Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
YDES	YD Bio Limited Ordinary Shares	2026-06-08 16:48:03.212596+00	Health Care	Medical Specialities	Nasdaq	\N
YDESW	YD Bio Limited Warrants	2026-06-08 16:48:03.212596+00	Health Care	Medical Specialities	Nasdaq	\N
YHC	LQR House Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	2023
YHGJ	Yunhong Green CTI Ltd. Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Specialty Chemicals	Nasdaq	\N
YORW	York Water Company (The) Common Stock	2026-06-08 16:48:03.212596+00	Utilities	Water Supply	Nasdaq	\N
YSWY	Yesway Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Consumer Staples	Food Chains	Nasdaq	2026
YYAI	AiRWA Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
Z	Zillow Group Inc. Class C Capital Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Business Services	Nasdaq	\N
ZBIO	Zenas BioPharma Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
ZBRA	Zebra Technologies Corporation Class A Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Industrial Machinery/Components	Nasdaq	1991
ZD	Ziff Davis Inc. Common Stock	2026-06-08 16:48:03.212596+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
ZEO	Zeo Energy Corporation Class A Common Stock	2026-06-08 16:48:03.212596+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
ZEOWW	Zeo Energy Corporation Warrants	2026-06-08 16:48:03.212596+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	2021
ZG	Zillow Group Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Business Services	Nasdaq	2011
ZION	Zions Bancorporation N.A. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
ZIONP	Zions Bancorporation N.A. Depositary Shares (Each representing 1/40th Interest in a Share of Series A Floating-Rate Non-Cumulative Perpetual Preferred Stock)	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
ZKP	Lafayette Digital Acquisition Corp. I Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
ZKPU	Lafayette Digital Acquisition Corp. I Unit	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
ZKPW	Lafayette Digital Acquisition Corp. I Warrant	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2026
ZM	Zoom Communications Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2019
ZNB	Zeta Network Group Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Engineering & Construction	Nasdaq	\N
ZNTL	Zentalis Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
ZS	Zscaler Inc. Common Stock	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	2018
ZSQR	Z Squared Inc. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Finance: Consumer Services	Nasdaq	2020
ZUMZ	Zumiez Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	2005
ZVRA	Zevra Therapeutics Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ZYME	Zymeworks Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
AGL	agilon health inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Misc Health and Biotechnology Services	NYSE	2021
AGM	Federal Agricultural Mortgage Corporation Common Stock	2026-06-08 16:48:03.223058+00	Finance	Finance Companies	NYSE	\N
AGM^D	Federal Agricultural Mortgage Corporation 5.700% Non-Cumulative Preferred Stock Series D	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AMPGZ	Amplitech Group Inc. Series B Right	2026-06-08 16:48:03.020027+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
AMPH	Amphastar Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
AMPL	Amplitude Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
AMRX	Amneal Pharmaceuticals Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
AMSC	American Superconductor Corporation Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Metal Fabrications	Nasdaq	1991
AMSF	AMERISAFE Inc. Common Stock	2026-06-08 16:48:03.020027+00	Finance	Property-Casualty Insurers	Nasdaq	2005
AMSS	AMASS Brands Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
AMST	Amesite Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2020
AMTX	Aemetis Inc. (DE) Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Major Chemicals	Nasdaq	\N
AMZN	Amazon.com Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	1997
ANAB	AnaptysBio Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
ANDE	Andersons Inc. (The) Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Farming/Seeds/Milling	Nasdaq	\N
ANGI	Angi Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Advertising	Nasdaq	\N
ANGO	AngioDynamics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	2004
ANIK	Anika Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
ANIP	ANI Pharmaceuticals Inc.	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ANIX	Anixa Biosciences Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ANNA	AleAnna Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Energy	Oil & Gas Production	Nasdaq	\N
ANNAW	AleAnna Inc. Warrant	2026-06-08 16:48:03.020027+00	Energy	Oil & Gas Production	Nasdaq	\N
ANNX	Annexon Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
TBH	Brag House Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	2025
TBLD	Thornburg Income Builder Opportunities Trust Common Stock	2026-06-08 16:48:03.196479+00	Finance	Investment Managers	Nasdaq	2021
TBRG	TruBridge Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	EDP Services	Nasdaq	2002
TCBI	Texas Capital Bancshares Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	2003
TCBIO	Texas Capital Bancshares Inc. Depositary Shares 5.75% Fixed Rate Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
TCBK	TriCo Bancshares Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
TCBS	Texas Community Bancshares Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Banks	Nasdaq	2021
TCMD	Tactile Systems Technology Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	2016
TCPC	BlackRock TCP Capital Corp. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Finance/Investors Services	Nasdaq	2012
TCRT	Alaunos Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TCRX	TScan Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
TDAC	Translational Development Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TDACU	Translational Development Acquisition Corp. Units	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2024
TDACW	Translational Development Acquisition Corp. Warrants	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TDUP	ThredUp Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2021
TDWD	Tailwind 2.0 Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
TDWDR	Tailwind 2.0 Acquisition Corp. Rights	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
TDWDU	Tailwind 2.0 Acquisition Corp. Unit	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
AGM^E	Federal Agricultural Mortgage Corporation 5.750% Non-Cumulative Preferred Stock Series E	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AGM^F	Federal Agricultural Mortgage Corporation 5.250% Non-Cumulative Preferred Stock Series F	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AGM^G	Federal Agricultural Mortgage Corporation 4.875% Non-Cumulative Preferred Stock Series G	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
TER	Teradyne Inc. Common Stock	2026-06-08 16:48:03.196479+00	Industrials	Electrical Products	Nasdaq	\N
AGM^H	Federal Agricultural Mortgage Corporation 6.500% Non-Cumulative Preferred Stock Series H	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AGM^I	Federal Agricultural Mortgage Corporation 6.875% Non-Cumulative Preferred Stock Series I	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AGX	Argan Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Engineering & Construction	NYSE	\N
AHR	American Healthcare REIT Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
AHRT	AH Realty Trust Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Real Estate	NYSE	2013
AHRT^A	AH Realty Trust Inc. 6.75% Series A Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AHT	Ashford Hospitality Trust Inc Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2003
AHT^D	Ashford Hospitality Trust Inc 8.45% Series D Cumulative Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AHT^F	Ashford Hospitality Trust Inc 7.375% Series F Cumulative Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AHT^G	Ashford Hospitality Trust Inc 7.375% Series G Cumulative Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AHT^H	Ashford Hospitality Trust Inc 7.50% Series H Cumulative Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AHT^I	Ashford Hospitality Trust Inc 7.50% Series I Cumulative Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AI	C3.ai Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Technology	Computer Software: Prepackaged Software	NYSE	2020
AIG	American International Group Inc. New Common Stock	2026-06-08 16:48:03.223058+00	Finance	Life Insurance	NYSE	\N
AII	American Integrity Insurance Group Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2025
AIN	Albany International Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Textiles	NYSE	\N
AIR	AAR Corp. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Aerospace	NYSE	\N
AIT	Applied Industrial Technologies Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Industrial Specialties	NYSE	\N
AIV	Apartment Investment and Management Company Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
AIZ	Assurant Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2004
AIZN	Assurant Inc. 5.25% Subordinated Notes due 2061	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2020
AJG	Arthur J. Gallagher & Co. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Specialty Insurers	NYSE	\N
AKR	Acadia Realty Trust Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
ALB	Albemarle Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Major Chemicals	NYSE	\N
ALB^A	Albemarle Corporation Depositary Shares each representing a 1/20th of 7.25% Series A Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ALG	Alamo Group Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Industrial Machinery/Components	NYSE	\N
ALH	Alliance Laundry Holdings Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Industrial Machinery/Components	NYSE	2025
ALIT	Alight Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Business Services	NYSE	2021
ALK	Alaska Air Group Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Air Freight/Delivery Services	NYSE	\N
ALL	Allstate Corporation (The) Common Stock	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	\N
ALL^B	Allstate Corporation (The) 5.100% Fixed-to-Floating Rate Subordinated Debentures due 2053	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ALL^H	Allstate Corporation (The) Depositary Shares each representing a 1/1000th interest in a share of Fixed Rate Noncumulative Perpetual Preferred Stock Series H	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ALL^I	Allstate Corporation (The) Depositary Shares each representing a 1/1000th interest in a share of Fixed Rate Noncumulative Perpetual Preferred Stock Series I	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ALL^J	Allstate Corporation (The) Depositary Shares each representing a 1/1000th interest in a share of Fixed Rate Noncumulative Perpetual Preferred Stock Series J	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ALLE	Allegion plc Ordinary Shares	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Diversified Commercial Services	NYSE	2013
ALLY	Ally Financial Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	2014
ALSN	Allison Transmission Holdings Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	2012
ALTG	Alta Equipment Group Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Industrial Machinery/Components	NYSE	2019
ALTG^A	Alta Equipment Group Inc. Depositary Shares (each representing 1/1000th in a share of 10% Series A Cumulative Perpetual Preferred Stock)	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ALX	Alexander's Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
AM	Antero Midstream Corporation Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Natural Gas Distribution	NYSE	2017
AMBQ	Ambiq Micro Inc. Common Stock	2026-06-08 16:48:03.223058+00	Technology	Semiconductors	NYSE	2025
AMC	AMC Entertainment Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Movies/Entertainment	NYSE	2013
AME	AMETEK Inc.	2026-06-08 16:48:03.223058+00	Industrials	Industrial Machinery/Components	NYSE	\N
AMG	Affiliated Managers Group Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
AMH	American Homes 4 Rent Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
AMH^G	American Homes 4 Rent Series G cumulative redeemable perpetual preferred shares of beneficial interest	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AMH^H	American Homes 4 Rent Series H cumulative redeemable perpetual Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AMN	AMN Healthcare Services Inc	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Professional Services	NYSE	\N
AMP	Ameriprise Financial Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
AMPX	Amprius Technologies Inc. Common Stock	2026-06-08 16:48:03.223058+00	Miscellaneous	Industrial Machinery/Components	NYSE	2022
AMPY	Amplify Energy Corp. Common Stock	2026-06-08 16:48:03.223058+00	Energy	Oil & Gas Production	NYSE	2016
AMR	Alpha Metallurgical Resources Inc. Common Stock	2026-06-08 16:48:03.223058+00	Energy	Coal Mining	NYSE	2018
AMTB	Amerant Bancorp Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	\N
AMTM	Amentum Holdings Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Business Services	NYSE	2024
AMWL	American Well Corporation Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Business Services	NYSE	2020
AN	AutoNation Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	\N
TRST	TrustCo Bank Corp NY Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
ANET	Arista Networks Inc. Common Stock	2026-06-08 16:48:03.223058+00	Telecommunications	Computer Communications Equipment	NYSE	\N
ANF	Abercrombie & Fitch Company Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
ANG^D	American National Group Inc. Depositary Shares each representing a 1/1000th interest in a share of 7.375% Fixed-Rate Non-Cumulative Preferred Stock Series D	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ANGX	Angel Studios Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Movies/Entertainment	NYSE	2025
ANRO	Alto Neuroscience Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2024
ANVS	Annovis Bio Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2020
AOD	abrdn Total Dynamic Dividend Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2007
AOMD	Angel Oak Mortgage REIT Inc. 9.750% Senior Notes due 2030	2026-06-08 16:48:03.223058+00	Finance	Real Estate	NYSE	2025
AOMN	Angel Oak Mortgage REIT Inc. 9.500% Senior Notes due 2029	2026-06-08 16:48:03.223058+00	Finance	Real Estate	NYSE	2024
AOMR	Angel Oak Mortgage REIT Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Real Estate	NYSE	2021
AON	Aon plc Class A Ordinary Shares (Ireland)	2026-06-08 16:48:03.223058+00	Finance	Specialty Insurers	NYSE	\N
AORT	Artivion Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Medical/Dental Instruments	NYSE	\N
AOS	A.O. Smith Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Consumer Electronics/Appliances	NYSE	\N
AP	Ampco-Pittsburgh Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Fluid Controls	NYSE	\N
APAM	Artisan Partners Asset Management Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2013
APD	Air Products and Chemicals Inc. Common Stock	2026-06-08 16:48:03.223058+00	Basic Materials	Major Chemicals	NYSE	\N
APG	APi Group Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Engineering & Construction	NYSE	2020
APH	Amphenol Corporation Common Stock	2026-06-08 16:48:03.223058+00	Technology	Electrical Products	NYSE	\N
APLE	Apple Hospitality REIT Inc. Common Shares	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
APO	Apollo Global Management Inc. (New) Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
APO^A	Apollo Global Management Inc. 6.75% Series A Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
APOS	Apollo Global Management Inc. 7.625% Fixed-Rate Resettable Junior Subordinated Notes due 2053	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	1987
AQN	Algonquin Power & Utilities Corp. Common Shares	2026-06-08 16:48:03.223058+00	Utilities	Electric Utilities: Central	NYSE	2016
AQNB	Algonquin Power & Utilities Corp. 6.20% Fixed-to-Floating Subordinated Notes Series 2019-A due July 1 2079	2026-06-08 16:48:03.223058+00	Utilities	Electric Utilities: Central	NYSE	2019
AR	Antero Resources Corporation Common Stock	2026-06-08 16:48:03.223058+00	Energy	Oil & Gas Production	NYSE	2013
ARDC	Ares Dynamic Credit Allocation Fund Inc. Common Shares	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2012
ARDT	Ardent Health Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Hospital/Nursing Management	NYSE	2024
ARE	Alexandria Real Estate Equities Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
ARES	Ares Management Corporation Class A Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2014
ARES^B	Ares Management Corporation 6.75% Series B Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ARI	Apollo Commercial Real Estate Finance Inc	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2009
ARL	American Realty Investors Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Other Consumer Services	NYSE	\N
ARLO	Arlo Technologies Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Staples	Consumer Electronics/Appliances	NYSE	2018
ARMK	Aramark Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Restaurants	NYSE	2013
AROC	Archrock Inc. Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Natural Gas Distribution	NYSE	\N
ARR	ARMOUR Residential REIT Inc.	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
ARR^C	ARMOUR Residential REIT Inc. 7% Series C Cumulative Redeemable Preferred Stock (liquidation preference $25.00 per share)	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ARW	Arrow Electronics Inc. Common Stock	2026-06-08 16:48:03.223058+00	Technology	Electronic Components	NYSE	\N
ASA	ASA  Gold and Precious Metals Limited	2026-06-08 16:48:03.223058+00	Industrials	Precious Metals	NYSE	\N
ASAN	Asana Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Technology	Computer Software: Prepackaged Software	NYSE	2020
ASB	Associated Banc-Corp Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	\N
ASB^E	Associated Banc-Corp Depositary Shares each representing a 1/40th interest in a share of 5.875% Non-Cumulative Perpetual Preferred Stock Series E	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ASB^F	Associated Banc-Corp Depositary Shares each representing a 1/40th interest in a share of Associated Banc-Corp 5.625% Non-Cumulative Perpetual Preferred Stock Series F	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ASBA	Associated Banc-Corp 6.625% Fixed-Rate Reset Subordinated Notes due 2033	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	2023
ASG	Liberty All-Star Growth Fund Inc.	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
ASGI	abrdn Global Infrastructure Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2020
ASH	Ashland Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Specialty Chemicals	NYSE	\N
ASIX	AdvanSix Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Major Chemicals	NYSE	2016
ASPN	Aspen Aerogels Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	2014
ATEN	A10 Networks Inc. Common Stock	2026-06-08 16:48:03.223058+00	Telecommunications	Computer Communications Equipment	NYSE	2014
ATI	ATI Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Steel/Iron Ore	NYSE	\N
ATKR	Atkore Inc. Common Stock	2026-06-08 16:48:03.223058+00	Miscellaneous	Industrial Machinery/Components	NYSE	2016
ATMU	Atmus Filtration Technologies Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	2023
ATR	AptarGroup Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Plastic Products	NYSE	\N
AUB	Atlantic Union Bankshares Corporation Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	\N
AUB^A	Atlantic Union Bankshares Corporation Depositary Shares each representing a 1/400th ownership interest in a share of 6.875% Perpetual Non-Cumulative Preferred Stock Series A	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
AVA	Avista Corporation Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Power Generation	NYSE	\N
ANSCU	Agriculture & Natural Solutions Acquisition Corporation Unit	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2023
AVB	AvalonBay Communities Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
AVBC	Avidia Bancorp Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Banks	NYSE	2025
AVD	American Vanguard Corporation Common Stock ($0.10 Par Value)	2026-06-08 16:48:03.223058+00	Industrials	Agricultural Chemicals	NYSE	1998
AVK	Advent Convertible and Income Fund	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2003
AVNS	Avanos Medical Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Industrial Specialties	NYSE	2014
AVNT	Avient Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Major Chemicals	NYSE	\N
AVTR	Avantor Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Biotechnology: Laboratory Analytical Instruments	NYSE	2019
AVY	Avery Dennison Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Containers/Packaging	NYSE	\N
AWF	Alliancebernstein Global High Income Fund	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1993
AWI	Armstrong World Industries Inc Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Plastic Products	NYSE	\N
AWK	American Water Works Company Inc. Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Water Supply	NYSE	2008
AWP	abrdn Global Premier Properties Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2007
AWR	American States Water Company Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Water Supply	NYSE	\N
AX	Axos Financial Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Savings Institutions	NYSE	2018
AXP	American Express Company Common Stock	2026-06-08 16:48:03.223058+00	Finance	Finance: Consumer Services	NYSE	\N
AXR	AMREP Corporation Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Homebuilding	NYSE	\N
AXTA	Axalta Coating Systems Ltd. Common Shares	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Paints/Coatings	NYSE	2014
AYI	Acuity Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Building Products	NYSE	\N
AZO	AutoZone Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Auto & Home Supply Stores	NYSE	\N
AZZ	AZZ Inc.	2026-06-08 16:48:03.223058+00	Industrials	Industrial Specialties	NYSE	\N
BA	Boeing Company (The) Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Aerospace	NYSE	\N
BA^A	Boeing Company (The) Depositary Shares each representing a 1/20th interest in a share of 6.00% Series A Mandatory Convertible Preferred Stock par value $1.00	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC	Bank of America Corporation Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	\N
BAC^B	Bank of America Corporation Depositary Shares each representing a 1/1000th interest in a share of 6.000% Non-Cumulative Preferred Stock Series GG	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^E	Bank of America Corporation Depositary Sh repstg 1/1000th Perp Pfd Ser E	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^K	Bank of America Corporation Depositary Shares each representing a 1/1000th interest in a share of 5.875% Non- Cumulative Preferred Stock Series HH	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^L	Bank of America Corporation Non Cumulative Perpetual Conv Pfd Ser L	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^M	Bank of America Corporation Depositary Shares each representing a 1/1000th interest in a share of 5.375% Non-Cumulative Preferred Stock Series KK	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^N	Bank of America Corporation Depositary shares each representing 1/1000th interest in a share of 5.000% Non-Cumulative Preferred Stock Series LL	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^O	Bank of America Corporation Depositary shares each representing 1/1000th interest in a share of 4.375% Non-Cumulative Preferred Stock Series NN	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^P	Bank of America Corporation Depositary Shares each representing a 1/1000th interest in a share of 4.125% Non-Cumulative Preferred Stock Series PP	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^Q	Bank of America Corporation Depositary shares each representing 1/1000th interest in a share of 4.250% Non-Cumulative Preferred Stock Series QQ	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAC^S	Bank of America Corporation Depositary shares each representing 1/1000th interest in a share of 4.750% Non-Cumulative Preferred Stock Series SS	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BAH	Booz Allen Hamilton Holding Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Professional Services	NYSE	2010
BALL	Ball Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Containers/Packaging	NYSE	\N
BALY	Bally's Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Hotels/Resorts	NYSE	2024
BANC	Banc of California Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	\N
BANC^F	Banc of California Inc. Depositary Shares each representing a 1/40th interest in a share of 7.75% non-cumulative perpetual preferred stock Series F	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BARK	BARK Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Other Specialty Stores	NYSE	2020
BAX	Baxter International Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Medical/Dental Instruments	NYSE	\N
BBAI	BigBear.ai Inc. Common Stock	2026-06-08 16:48:03.223058+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
BBBY	Bed Bath & Beyond Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Catalog/Specialty Distribution	NYSE	\N
BBDC	Barings BDC Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Diversified Financial Services	NYSE	\N
BBN	BlackRock Taxable Municipal Bond Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Finance Companies	NYSE	2010
BBT	Beacon Financial Corporation Common stock	2026-06-08 16:48:03.223058+00	Finance	Banks	NYSE	\N
BBW	Build-A-Bear Workshop Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Recreational Games/Products/Toys	NYSE	2004
BBWI	Bath & Body Works Inc.	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
BBY	Best Buy Co. Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Consumer Electronics/Video Chains	NYSE	\N
BC	Brunswick Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Industrial Machinery/Components	NYSE	\N
BC^C	Brunswick Corporation 6.375% Notes due 2049	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BCAT	BlackRock Capital Allocation Term Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Finance/Investors Services	NYSE	2020
BCO	Brinks Company (The) Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Integrated Freight & Logistics	NYSE	\N
BCSF	Bain Capital Specialty Finance Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Finance/Investors Services	NYSE	2018
BCX	BlackRock Resources Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Finance/Investors Services	NYSE	2011
ANSCW	Agriculture & Natural Solutions Acquisition Corporation Warrant	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2024
ANTX	AN2 Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
AOUT	American Outdoor Brands Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
APA	APA Corporation Common Stock	2026-06-08 16:48:03.020027+00	Energy	Oil & Gas Production	Nasdaq	\N
APACR	StoneBridge Acquisition II Corporation Rights	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2025
APACU	StoneBridge Acquisition II Corporation Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2025
APC	ARKO Petroleum Corp. Class A Common Stock	2026-06-08 16:48:03.020027+00	Energy	Oil Refining/Marketing	Nasdaq	2026
APEI	American Public Education Inc. Common Stock	2026-06-08 16:48:03.020027+00	Real Estate	Other Consumer Services	Nasdaq	2007
APGE	Apogee Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2023
APLD	Applied Digital Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Finance: Consumer Services	Nasdaq	2022
APLM	Apollomics Inc. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
APLMW	Apollomics Inc. Warrant	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
APOG	Apogee Enterprises Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
APP	Applovin Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
APPF	AppFolio Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2015
APPN	Appian Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2017
APPS	Digital Turbine Inc. Common Stock	2026-06-08 16:48:03.020027+00	Miscellaneous	Multi-Sector Companies	Nasdaq	\N
APRE	Aprea Therapeutics Inc. Common stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
APVO	Aptevo Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
APXT	Apex Treasury Corporation Class A Ordinary Share	2026-06-08 16:48:03.020027+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
APXTU	Apex Treasury Corporation Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2025
APXTW	Apex Treasury Corporation Warrants	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2025
APYX	Apyx Medical Corporation Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
VTRS	Viatris Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
WAFD	WaFd Inc. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
BDC	Belden Inc Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Telecommunications Equipment	NYSE	\N
BDJ	Blackrock Enhanced Equity Dividend Trust	2026-06-08 16:48:03.223058+00	Finance	Finance Companies	NYSE	2005
BDN	Brandywine Realty Trust Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
BDX	Becton Dickinson and Company Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Medical/Dental Instruments	NYSE	\N
BE	Bloom Energy Corporation Class A Common Stock	2026-06-08 16:48:03.223058+00	Energy	Industrial Machinery/Components	NYSE	2018
BEN	Franklin Resources Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
BEPC	Brookfield Renewable Corporation Brookfield Renewable Corporation Class A Subordinate Voting Shares	2026-06-08 16:48:03.223058+00	Utilities	Electric Utilities: Central	NYSE	\N
BETA	Beta Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Aerospace	NYSE	2025
BF/B	Brown Forman Corporation	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BFAM	Bright Horizons Family Solutions Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Other Consumer Services	NYSE	2013
BFH	Bread Financial Holdings Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Business Services	NYSE	\N
VTSI	VirTra Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Miscellaneous manufacturing industries	Nasdaq	\N
VTVT	vTv Therapeutics Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
VUZI	Vuzix Corporation Common Stock	2026-06-08 16:48:03.212596+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	\N
BFH^A	Bread Financial Holdings Inc. Depositary Shares each representing a 1/40th interest in a share of 8.625% Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BFH^B	Bread Financial Holdings Inc. Depositary Shares each representing a 1/40th interest in a share of 8.875% Fixed Rate Reset Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BFLY	Butterfly Network Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Medical Electronics	NYSE	2020
BFS	Saul Centers Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	1993
BFS^D	Saul Centers Inc. Depositary Shares each representing 1/100th of a share of 6.125% Series D Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BFS^E	Saul Centers Inc. Depositary shares each representing a 1/100th fractional interest in a share of 6.000% Series E Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BG	Bunge Limited Common Shares	2026-06-08 16:48:03.223058+00	Consumer Staples	Packaged Foods	NYSE	\N
BGB	Blackstone Strategic Credit 2027 Term Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2012
BGH	Barings Global Short Duration High Yield Fund Common Shares of Beneficial Interests	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2012
BGR	BlackRock Energy and Resources Trust	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2004
BGS	B&G Foods Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Staples	Packaged Foods	NYSE	\N
BGSF	BGSF Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Professional Services	NYSE	\N
BGT	BlackRock Floating Rate Income Trust	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2004
BOE	Blackrock Enhanced Global Dividend Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2005
BOH	Bank of Hawaii Corporation Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
BOH^A	Bank of Hawaii Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of 4.375% Fixed Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BOH^B	Bank of Hawaii Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of 8.000% Fixed Rate Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BOOT	Boot Barn Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	2014
BOW	Bowhead Specialty Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Property-Casualty Insurers	NYSE	2024
BOX	Box Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Technology	Computer Software: Prepackaged Software	NYSE	2015
BR	Broadridge Financial Solutions Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Business Services	NYSE	\N
BRC	Brady Corporation Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Miscellaneous manufacturing industries	NYSE	\N
BRCC	BRC Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Staples	Beverages (Production/Distribution)	NYSE	2022
BRK/A	Berkshire Hathaway Inc.	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BRK/B	Berkshire Hathaway Inc.	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BRO	Brown & Brown Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Specialty Insurers	NYSE	\N
BROS	Dutch Bros Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Restaurants	NYSE	2021
BRSL	Brightstar Lottery PLC Trading under the Legal Name to begin at the market open on July 21 2025. Ordinary Shares	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2015
BRSP	BrightSpire Capital Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2018
BRT	BRT Apartments Corp. (MD) Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
BRW	Saba Capital Income & Opportunities Fund SBI	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
BRX	Brixmor Property Group Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
BSL	Blackstone Senior Floating Rate 2027 Term Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2010
BSM	Black Stone Minerals L.P. Common units representing limited partner interests	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	2015
BST	BlackRock Science and Technology Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Finance	Finance Companies	NYSE	2014
BSTZ	BlackRock Science and Technology Term Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2019
BSX	Boston Scientific Corporation Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Medical/Dental Instruments	NYSE	\N
BTO	John Hancock Financial Opportunities Fund Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Managers	NYSE	1994
BTT	BlackRock Municipal 2030 Target Term Trust	2026-06-08 16:48:03.236618+00	Finance	Investment Managers	NYSE	2012
BTU	Peabody Energy Corporation Common Stock	2026-06-08 16:48:03.236618+00	Energy	Coal Mining	NYSE	2017
BTX	BlackRock Technology and Private Equity Term Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	2021
BTZ	BlackRock Credit Allocation Income Trust	2026-06-08 16:48:03.236618+00	Finance	Finance Companies	NYSE	2006
BUI	BlackRock Utility Infrastructure & Power Opportunities Trust	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2011
BURL	Burlington Stores Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	2013
BV	BrightView Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Business Services	NYSE	2018
BW	Babcock & Wilcox Enterprises Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Building Products	NYSE	2015
BW^A	Babcock & Wilcox Enterprises Inc. 7.75% Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
AQB	AquaBounty Technologies Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Staples	Meat/Poultry/Fish	Nasdaq	\N
AQMS	Aqua Metals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Metal Fabrications	Nasdaq	2015
AQST	Aquestive Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
ARAI	Arrive AI Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	\N
ARAY	Accuray Incorporated Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Medical/Dental Instruments	Nasdaq	2007
ARCB	ArcBest Corporation Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Trucking Freight/Courier Services	Nasdaq	\N
ARCC	Ares Capital Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Finance: Consumer Services	Nasdaq	2004
ARCI	Archimedes Tech SPAC Partners III Co. Ordinary Share	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ARCIW	Archimedes Tech SPAC Partners III Co. Warrant	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ARCL	ARC Group Acquisition I Corp Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ARCLR	ARC Group Acquisition I Corp Right	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ARCLU	ARC Group Acquisition I Corp Unit	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ARCLW	ARC Group Acquisition I Corp Warrants	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ARDX	Ardelyx Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
AREC	American Resources Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Energy	Coal Mining	Nasdaq	\N
ARHS	Arhaus Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2021
ARKO	ARKO Corp. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Staples	Food Chains	Nasdaq	\N
ARKR	Ark Restaurants Corp. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Restaurants	Nasdaq	\N
ARLP	Alliance Resource Partners L.P. Common Units representing Limited Partners Interests	2026-06-08 16:48:03.020027+00	Energy	Coal Mining	Nasdaq	1999
AROW	Arrow Financial Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Major Banks	Nasdaq	\N
ARQ	Arq Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Major Chemicals	Nasdaq	\N
ARQT	Arcutis Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
BWA	BorgWarner Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
BWG	BrandywineGLOBAL Global Income Opportunities Fund Inc.	2026-06-08 16:48:03.236618+00	Finance	Finance/Investors Services	NYSE	2012
BWNB	Babcock & Wilcox Enterprises Inc. 6.50% Senior Notes due 2026	2026-06-08 16:48:03.236618+00	Industrials	Building Products	NYSE	2021
BWXT	BWX Technologies Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Industrial Machinery/Components	NYSE	\N
BX	Blackstone Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Managers	NYSE	2007
BXC	Bluelinx Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Wholesale Distributors	NYSE	2004
BXMT	Blackstone Mortgage Trust Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
BXP	BXP Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	1997
BY	Byline Bancorp Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	2017
BYD	Boyd Gaming Corporation Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Hotels/Resorts	NYSE	1993
BZH	Beazer Homes USA Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Homebuilding	NYSE	1994
C	Citigroup Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
C^N	Citigroup Capital XIII 7.875% Fixed rate Floating Rate trust Preferred Securities (TruPS)	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
C^R	Citigroup Inc. Depositary Shares Each Representing a 1/1000th Interest in a Share of 6.250% Noncumulative Preferred Stock Series II	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CABO	Cable One Inc. Common Stock	2026-06-08 16:48:03.236618+00	Telecommunications	Cable & Other Pay Television Services	NYSE	2015
CACI	CACI International Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Technology	EDP Services	NYSE	\N
CAF	Morgan Stanley China A Share Fund Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Managers	NYSE	2006
CAG	ConAgra Brands Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Staples	Packaged Foods	NYSE	\N
CAH	Cardinal Health Inc. Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Other Pharmaceuticals	NYSE	\N
CAL	Caleres Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Shoe Manufacturing	NYSE	\N
A	Agilent Technologies Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Biotechnology: Laboratory Analytical Instruments	NYSE	1999
AA	Alcoa Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Aluminum	NYSE	2016
AAP	Advance Auto Parts Inc.	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Auto & Home Supply Stores	NYSE	\N
AAT	American Assets Trust Inc. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2011
AB	AllianceBernstein Holding L.P.  Units	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
ABBV	AbbVie Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2012
ABCB	Ameris Bancorp Common Stock	2026-06-08 16:48:03.223058+00	Finance	Major Banks	NYSE	1994
ABG	Asbury Automotive Group Inc Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	2002
ABM	ABM Industries Incorporated Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Diversified Commercial Services	NYSE	\N
ABR	Arbor Realty Trust Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2004
ABR^D	Arbor Realty Trust 6.375% Series D Cumulative Redeemable Preferred Stock Liquidation Preference $25.00 per Share	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ABR^E	Arbor Realty Trust 6.25% Series E Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ABR^F	Arbor Realty Trust 6.25% Series F Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock Liquidation Preference $25.00 per share	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ABT	Abbott Laboratories Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
ABX	Abacus Global Management Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
ABXL	Abacus Global Management Inc. 9.875% Fixed Rate Senior Notes due 2028	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ACA	Arcosa Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Metal Fabrications	NYSE	2018
ACCO	Acco Brands Corporation Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Publishing	NYSE	\N
ACEL	Accel Entertainment Inc.	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2017
ACH	Accendra Health Inc. Common Stock	2026-06-08 16:48:03.223058+00	Health Care	Medical Specialities	NYSE	\N
AEFC	Aegon Funding Company LLC 5.10% Subordinated Notes due 2049	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	2019
AEO	American Eagle Outfitters Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
AES	The AES Corporation Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Electric Utilities: Central	NYSE	\N
AESI	Atlas Energy Solutions Inc. Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	2023
CALX	Calix Inc Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Telecommunications Equipment	NYSE	2010
CALY	Callaway Golf Company Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Recreational Games/Products/Toys	NYSE	\N
CAPL	CrossAmerica Partners LP Common Units representing limited partner interests	2026-06-08 16:48:03.236618+00	Energy	Oil Refining/Marketing	NYSE	2012
CARR	Carrier Global Corporation Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Industrial Machinery/Components	NYSE	2020
CARS	Cars.com Inc. Common Stock	2026-06-08 16:48:03.236618+00	Technology	EDP Services	NYSE	2017
CAT	Caterpillar Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Construction/Ag Equipment/Trucks	NYSE	\N
CATO	Cato Corporation (The) Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
CAVA	CAVA Group Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Restaurants	NYSE	2023
CBAN	Colony Bankcorp Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
CBL	CBL & Associates Properties Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2021
CBRE	CBRE Group Inc Common Stock Class A	2026-06-08 16:48:03.236618+00	Finance	Real Estate	NYSE	\N
CBT	Cabot Corporation Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Major Chemicals	NYSE	\N
CBU	Community Financial System Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
CBZ	CBIZ Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Business Services	NYSE	\N
CC	Chemours Company (The) Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Major Chemicals	NYSE	2015
CCI	Crown Castle Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CCK	Crown Holdings Inc.	2026-06-08 16:48:03.236618+00	Industrials	Containers/Packaging	NYSE	\N
CCL	Carnival Corporation Ltd. Common Shares	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Marine Transportation	NYSE	1987
CCO	Clear Channel Outdoor Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Advertising	NYSE	2005
CCS	Century Communities Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Homebuilding	NYSE	2014
CCZ	Comcast Holdings ZONES	2026-06-08 16:48:03.236618+00	Telecommunications	Cable & Other Pay Television Services	NYSE	\N
CDE	Coeur Mining Inc. Common Stock	2026-06-08 16:48:03.236618+00	Basic Materials	Precious Metals	NYSE	\N
CDP	COPT Defense Properties Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CDR^B	Cedar Realty Trust Inc. 7.25% Series B Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CDR^C	Cedar Realty Trust Inc. 6.50% Series C Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CDRE	Cadre Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Industrial Specialties	NYSE	2021
CE	Celanese Corporation Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Major Chemicals	NYSE	2005
CEE	The Central and Eastern Europe Fund Inc. (The) Common Stock	2026-06-08 16:48:03.236618+00	Finance	Finance Companies	NYSE	\N
CF	CF Industries Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Agricultural Chemicals	NYSE	2005
CFG	Citizens Financial Group Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	2014
CFG^E	Citizens Financial Group Inc. Depositary Shares Each Representing 1/40th Interest in a Share of 5.000% Fixed-Rate Non-Cumulative Perpetual Preferred Stock Series E	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CFG^H	Citizens Financial Group Inc. Depositary Shares Each Representing a 1/40th Interest in a Share of 7.375% Fixed-Rate Non-Cumulative Perpetual Preferred Stock Series H	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CFG^I	Citizens Financial Group Inc. Depositary Shares Each Representing a 1/40th Interest in a Share of 6.500% Fixed-Rate Reset Non-Cumulative Perpetual Preferred Stock Series I	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CFR	Cullen/Frost Bankers Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
CFR^B	Cullen/Frost Bankers Inc. Depositary Shares each representing a 1/40th ownership interest in a share of 4.450% non-cumulative perpetual preferred stock Series B	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CHCT	Community Healthcare Trust Incorporated Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
CHD	Church & Dwight Company Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	\N
CHE	Chemed Corp	2026-06-08 16:48:03.236618+00	Health Care	Medical/Nursing Services	NYSE	\N
CHGG	Chegg Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Other Consumer Services	NYSE	2013
CHH	Choice Hotels International Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Hotels/Resorts	NYSE	\N
CHPT	ChargePoint Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Industrial Specialties	NYSE	2019
CHWY	Chewy Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Catalog/Specialty Distribution	NYSE	2019
CI	The Cigna Group Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Medical Specialities	NYSE	\N
CIA	Citizens Inc. Class A Common Stock ($1.00 Par)	2026-06-08 16:48:03.236618+00	Finance	Life Insurance	NYSE	1994
CICB	CION Investment Corporation 7.50% Notes due 2029	2026-06-08 16:48:03.236618+00	Finance	Finance/Investors Services	NYSE	2024
CICC	CION Investment Corporation 7.50% Notes due 2031	2026-06-08 16:48:03.236618+00	Finance	Finance/Investors Services	NYSE	2026
CIEN	Ciena Corporation Common Stock	2026-06-08 16:48:03.236618+00	Utilities	Telecommunications Equipment	NYSE	1997
CIF	MFS Intermediate High Income Fund Common Stock	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
CII	BlackRock Enhanced Large Cap Core Fund Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Bankers/Brokers/Service	NYSE	2004
CIM	Chimera Investment Corporation Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2007
CIM^A	Chimera Investment Corporation 8.00% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CIM^B	Chimera Investment Corporation 8.00% Series B Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CIM^C	Chimera Investment Corporation 7.75% Series C Fixed-to-Floating Rate  Cumulative Redeemable  Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CIM^D	Chimera Investment Corporation 8.00% Series D Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CIMN	Chimera Investment Corporation 9.000% Senior Notes due 2029	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
CIMO	Chimera Investment Corporation 9.250% Senior Notes due 2029	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
CIMP	Chimera Investment Corporation 8.875% Senior Notes due 2030	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
CION	CION Investment Corporation Common Stock	2026-06-08 16:48:03.236618+00	Finance	Finance/Investors Services	NYSE	2021
CL	Colgate-Palmolive Company Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	\N
CLDT	Chatham Lodging Trust (REIT) Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2010
CLDT^A	Chatham Lodging Trust (REIT) 6.625% Series A Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CLF	Cleveland-Cliffs Inc. Common Stock	2026-06-08 16:48:03.236618+00	Basic Materials	Metal Mining	NYSE	\N
CLH	Clean Harbors Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Environmental Services	NYSE	\N
CLPR	Clipper Realty Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2017
CLW	Clearwater Paper Corporation Common Stock	2026-06-08 16:48:03.236618+00	Basic Materials	Paper	NYSE	\N
CLX	Clorox Company (The) Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Specialty Chemicals	NYSE	\N
CMC	Commercial Metals Company Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Steel/Iron Ore	NYSE	\N
CMG	Chipotle Mexican Grill Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Restaurants	NYSE	2006
CMI	Cummins Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Industrial Machinery/Components	NYSE	\N
AMT	American Tower Corporation (REIT) Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CMP	Compass Minerals Intl Inc Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	2003
CMS	CMS Energy Corporation Common Stock	2026-06-08 16:48:03.236618+00	Utilities	Power Generation	NYSE	\N
CMS^C	CMS Energy Corporation Depositary Shares each representing a 1/1000th interest in a share of 4.200% Cumulative Redeemable Perpetual Preferred Stock Series C	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CMSA	CMS Energy Corporation 5.625% Junior Subordinated Notes due 2078	2026-06-08 16:48:03.236618+00	Utilities	Power Generation	NYSE	2018
CMSC	CMS Energy Corporation 5.875% Junior Subordinated Notes due 2078	2026-06-08 16:48:03.236618+00	Utilities	Power Generation	NYSE	2018
CMSD	CMS Energy Corporation 5.875% Junior Subordinated Notes due 2079	2026-06-08 16:48:03.236618+00	Utilities	Power Generation	NYSE	2019
CMTG	Claros Mortgage Trust Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Real Estate	NYSE	2021
CMU	MFS Municipal Income Trust Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Managers	NYSE	1987
CNA	CNA Financial Corporation Common Stock	2026-06-08 16:48:03.236618+00	Finance	Property-Casualty Insurers	NYSE	\N
CNC	Centene Corporation Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Medical Specialities	NYSE	\N
CNK	Cinemark Holdings Inc Cinemark Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Movies/Entertainment	NYSE	2007
CNM	Core & Main Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Durable Goods	NYSE	2021
CNMD	CONMED Corporation Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	NYSE	1987
CNNE	Cannae Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Restaurants	NYSE	2017
CNO	CNO Financial Group Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Accident &Health Insurance	NYSE	\N
CNO^A	CNO Financial Group Inc. 5.125% Subordinated Debentures due 2060	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CNP	CenterPoint Energy Inc (Holding Co) Common Stock	2026-06-08 16:48:03.236618+00	Utilities	Electric Utilities: Central	NYSE	\N
CNR	Core Natural Resources Inc. Common Stock	2026-06-08 16:48:03.236618+00	Energy	Coal Mining	NYSE	2017
CNS	Cohen & Steers Inc Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Managers	NYSE	2004
CNX	CNX Resources Corporation Common Stock	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	1999
CODI	D/B/A Compass Diversified Holdings Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Home Furnishings	NYSE	2006
CODI^A	Compass Diversified Holdings 7.250% Series A Preferred Shares representing beneficial interest in Compass Diversified Holdings	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CODI^B	Compass Diversified Holdings 7.875% Series B Fixed-to-Floating Rate Cumulative Preferred Shares representing beneficial interests in Compass Diversified Holdings	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CODI^C	Compass Diversified Holdings 7.875% Series C Cumulative Preferred Shares	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
COF	Capital One Financial Corporation Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	1994
COF^I	Capital One Financial Corporation Depositary shares each representing a 1/40th interest in a share of Fixed Rate Non-Cumulative Perpetual Preferred Stock Series I of the Issuer	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
COF^J	Capital One Financial Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of Fixed Rate Non- Cumulative Perpetual Preferred Stock Series J	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
COF^K	Capital One Financial Corporation Depositary Shares Each Representing a 1/40th Ownership Interest in a Share of Fixed Rate Non-Cumulative Perpetual Preferred Stock Series K	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
COF^L	Capital One Financial Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of Fixed Rate Non-Cumulative Perpetual Preferred Stock Series L	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
COF^N	Capital One Financial Corporation Depositary Shares Each Representing a 1/40th Ownership Interest in a Share of Fixed Rate Non-Cumulative Perpetual Preferred Stock Series N	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
COHR	Coherent Corp. Common Stock	2026-06-08 16:48:03.236618+00	Technology	Electronic Components	NYSE	\N
COLD	Americold Realty Trust Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2018
COMP	Compass Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Technology	EDP Services	NYSE	2021
CON	Concentra Group Holdings Parent Inc. Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Medical Specialities	NYSE	2024
COOK	Traeger Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Consumer Electronics/Appliances	NYSE	2021
COP	ConocoPhillips Common Stock	2026-06-08 16:48:03.236618+00	Energy	Integrated oil Companies	NYSE	\N
COR	Cencora Inc. Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Other Pharmaceuticals	NYSE	\N
COSO	CoastalSouth Bancshares Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	2025
COTY	Coty Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	2013
COUR	Coursera Inc. Common Stock	2026-06-08 16:48:03.236618+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
CPAY	Corpay Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Business Services	NYSE	\N
CPF	Central Pacific Financial Corp New	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
CPK	Chesapeake Utilities Corporation Common Stock	2026-06-08 16:48:03.236618+00	Utilities	Oil & Gas Production	NYSE	\N
CPNG	Coupang Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Catalog/Specialty Distribution	NYSE	2021
CPS	Cooper-Standard Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
CPT	Camden Property Trust Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	1993
CQP	Cheniere Energy Partners LP Common Units	2026-06-08 16:48:03.236618+00	Utilities	Oil/Gas Transmission	NYSE	2007
CR	Crane Company Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Metal Fabrications	NYSE	2023
CRBD	Corebridge Financial Inc. 6.375% Junior Subordinated Notes due 2064	2026-06-08 16:48:03.236618+00	Finance	Life Insurance	NYSE	2024
CRBG	Corebridge Financial Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Life Insurance	NYSE	2022
CRC	California Resources Corporation Common Stock	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	2020
CRCL	Circle Internet Group Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Finance	Finance: Consumer Services	NYSE	2025
CRD/A	Crawford & Company	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CRD/B	Crawford & Company	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CRGY	Crescent Energy Company Class A Common Stock	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	2021
CRI	Carter's Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Apparel	NYSE	2003
ATO	Atmos Energy Corporation Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Oil/Gas Transmission	NYSE	\N
BRBR	BellRing Brands Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Staples	Packaged Foods	NYSE	2022
CRK	Comstock Resources Inc. Common Stock	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	\N
CRL	Charles River Laboratories International Inc. Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	NYSE	2000
CRM	Salesforce Inc. Common Stock	2026-06-08 16:48:03.236618+00	Technology	Computer Software: Prepackaged Software	NYSE	2004
CRS	Carpenter Technology Corporation Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Steel/Iron Ore	NYSE	\N
CRT	Cross Timbers Royalty Trust Common Stock	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	1992
CSL	Carlisle Companies Incorporated Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Specialty Chemicals	NYSE	\N
CSR	D/B/A Centerspace Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CSW	CSW Industrials Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Home Furnishings	NYSE	\N
CTA^A	EIDP Inc. Preferred Stock $3.50 Series	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CTA^B	EIDP Inc. Preferred Stock $4.50 Series	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CTEV	Claritev Corporation Class A Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Business Services	NYSE	2020
CTO	CTO Realty Growth Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	1992
CTO^A	CTO Realty Growth Inc. 6.375% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
CTRE	CareTrust REIT Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2022
CTRI	Centuri Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Utilities	Oil & Gas Production	NYSE	2024
CTS	CTS Corporation Common Stock	2026-06-08 16:48:03.236618+00	Technology	Electrical Products	NYSE	\N
CTVA	Corteva Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Staples	Farming/Seeds/Milling	NYSE	2019
CUBB	Customers Bancorp Inc 5.375% Subordinated Notes Due 2034	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	2019
CUBE	CubeSmart Common Shares	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CUBI	Customers Bancorp Inc Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
CURB	Curbline Properties Corp. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Real Estate	NYSE	2024
CURV	Torrid Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	2021
DCBG	Dime Community Bancshares Inc. 9.000% Fixed-to-Floating Rate Subordinated Notes due 2034	2026-06-08 16:48:03.250515+00	Finance	Major Banks	NYSE	\N
DCH	Dauch Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
DCI	Donaldson Company Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Pollution Control Equipment	NYSE	\N
DCO	Ducommun Incorporated Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Military/Government/Technical	NYSE	\N
DCOM	Dime Community Bancshares Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Major Banks	NYSE	\N
DCOM^	Dime Community Bancshares Inc. Fixed-Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DD	DuPont de Nemours Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Major Chemicals	NYSE	2017
DDD	3D Systems Corporation Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Prepackaged Software	NYSE	\N
DDS	Dillard's Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	\N
DDT	Dillard's Capital Trust I	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	\N
DE	Deere & Company Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Industrial Machinery/Components	NYSE	\N
DEA	Easterly Government Properties Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
DEC	Diversified Energy Company Common Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	2025
DECK	Deckers Outdoor Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Shoe Manufacturing	NYSE	1993
DEI	Douglas Emmett Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2006
DELL	Dell Technologies Inc. Class C Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Manufacturing	NYSE	2018
DFH	Dream Finders Homes Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Homebuilding	NYSE	2022
DFIN	Donnelley Financial Solutions Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Other Consumer Services	NYSE	2016
DHF	BNY Mellon High Yield Strategies Fund Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	1998
DHI	D.R. Horton Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Homebuilding	NYSE	\N
DHR	Danaher Corporation Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Industrial Machinery/Components	NYSE	\N
DHX	DHI Group Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Business Services	NYSE	2007
DIN	Dine Brands Global Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Restaurants	NYSE	\N
DINO	HF Sinclair Corporation Common Stock	2026-06-08 16:48:03.250515+00	Energy	Natural Gas Distribution	NYSE	1960
DIS	Walt Disney Company (The) Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	\N
DK	Delek US Holdings Inc. Common Stock	2026-06-08 16:48:03.250515+00	Energy	Integrated oil Companies	NYSE	2017
DKL	Delek Logistics Partners L.P. Common Units representing Limited Partner Interests	2026-06-08 16:48:03.250515+00	Energy	Natural Gas Distribution	NYSE	2012
DKS	Dick's Sporting Goods Inc Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Other Specialty Stores	NYSE	2002
DLB	Dolby Laboratories Common Stock	2026-06-08 16:48:03.250515+00	Miscellaneous	Multi-Sector Companies	NYSE	2005
DLR	Digital Realty Trust Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2004
DLR^J	Digital Realty Trust Inc. 5.250% Series J Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DLR^K	Digital Realty Trust Inc. 5.850% Series K Cumulative Redeemable Preferred Stock par value $0.01 per share	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DLR^L	Digital Realty Trust Inc. 5.200% Series L Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DLX	Deluxe Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Publishing	NYSE	\N
DLY	DoubleLine Yield Opportunities Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2020
DMO	Western Asset Mortgage Opportunity Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2010
ARRY	Array Technologies Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Miscellaneous manufacturing industries	Nasdaq	2020
ARTC	Art Technology Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ARTCU	Art Technology Acquisition Corp. Units	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ARTCW	Art Technology Acquisition Corp. Warrants	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
ARTL	Artelo Biosciences Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ARTNA	Artesian Resources Corporation Class A Common Stock	2026-06-08 16:48:03.020027+00	Utilities	Water Supply	Nasdaq	\N
BCC	Boise Cascade L.L.C. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	2013
BGY	Blackrock Enhanced International Dividend Trust	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2007
BH	Biglari Holdings Inc. Class B Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Restaurants	NYSE	2018
BHE	Benchmark Electronics Inc. Common Stock	2026-06-08 16:48:03.236618+00	Technology	Electrical Products	NYSE	\N
BHK	Blackrock Core Bond Trust	2026-06-08 16:48:03.236618+00	Finance	Finance Companies	NYSE	2001
BHR	Braemar Hotels & Resorts Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
BHR^B	Braemar Hotels & Resorts Inc. 5.50% Series B Cumulative Convertible Preferred Stock par value $0.01 per share	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BKU	BankUnited Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Savings Institutions	NYSE	2011
BKV	BKV Corporation Common Stock	2026-06-08 16:48:03.236618+00	Energy	Oil & Gas Production	NYSE	2024
BLD	TopBuild Corp. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Engineering & Construction	NYSE	2015
BLDR	Builders FirstSource Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	2005
BLK	BlackRock Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Investment Bankers/Brokers/Service	NYSE	1999
BLND	Blend Labs Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Technology	Computer Software: Programming Data Processing	NYSE	2021
BLW	Blackrock Limited Duration Income Trust	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Other Consumer Services	NYSE	2003
BME	Blackrock Health Sciences Trust	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2005
BMEZ	BlackRock Health Sciences Term Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2020
BMI	Badger Meter Inc. Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Industrial Machinery/Components	NYSE	1971
BML^G	Bank of America Corporation Depositary Shares (Each representing a 1/1200th interest in a share of Floating Rate Non-Cumulative Preferred Stock  Series 1)	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BML^H	Bank of America Corporation Depositary Shares (Each representing a 1/1200th interest in a Share of Floating Rate Non-Cumulative Preferred Stock Series 2)	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BML^J	Bank of America Corporation Depositary Shares (Each representing a 1/1200th interest in a Share of Floating Rate Non-Cumulative Preferred Stock Series 4)	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
DNA	Ginkgo Bioworks Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	NYSE	2021
DNOW	DNOW Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	2014
DNP	DNP Select Income Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	1987
DOC	Healthpeak Properties Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
DOCN	DigitalOcean Holdings Inc. Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Programming Data Processing	NYSE	2021
DOCS	Doximity Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Technology	EDP Services	NYSE	2021
WYY	WidePoint Corporation Common Stock	2026-06-08 16:48:03.345943+00	Technology	EDP Services	AMEX	\N
XPL	Solitario Resources Corp. Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Precious Metals	AMEX	\N
XTNT	Xtant Medical Holdings Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	AMEX	\N
YCBD	cbdMD Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Package Goods/Cosmetics	AMEX	2017
DOUG	Douglas Elliman Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Real Estate	NYSE	2021
DOV	Dover Corporation Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Industrial Machinery/Components	NYSE	\N
DOW	Dow Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Major Chemicals	NYSE	2019
DPG	Duff & Phelps Utility and Infrastructure Fund Inc.	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2011
DRI	Darden Restaurants Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Restaurants	NYSE	\N
DSL	DoubleLine Income Solutions Fund Common Shares of Beneficial Interests	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2013
DSM	BNY Mellon Strategic Municipal Bond Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	1989
DT	Dynatrace Inc. Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Prepackaged Software	NYSE	2019
DTB	DTE Energy Company 2020 Series G 4.375% Junior Subordinated Debentures due 2080	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2020
DTE	DTE Energy Company Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	\N
DTF	DTF Tax-Free Income 2028 Term Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	1991
DTG	DTE Energy Company 2021 Series E 4.375% Junior Subordinated Debentures	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2021
DTK	DTE Energy Company 2025 Series H 6.25% Junior Subordinated Debentures due 2085	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2025
DTM	DT Midstream Inc. Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Natural Gas Distribution	NYSE	2021
DTW	DTE Energy Company 2017 Series E 5.25% Junior Subordinated Debentures due 2077	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2017
DUK	Duke Energy Corporation (Holding Company) Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Power Generation	NYSE	\N
DUK^A	Duke Energy Corporation Depositary Shares each representing a 1/1000th interest in a share of 5.75% Series A Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DUKB	Duke Energy Corporation 5.625% Junior Subordinated Debentures due 2078	2026-06-08 16:48:03.250515+00	Utilities	Power Generation	NYSE	2018
DV	DoubleVerify Holdings Inc. Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Programming Data Processing	NYSE	2021
DVA	DaVita Inc. Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Misc Health and Biotechnology Services	NYSE	\N
DVN	Devon Energy Corporation Common Stock	2026-06-08 16:48:03.250515+00	Energy	Oil & Gas Production	NYSE	1985
DX	Dynex Capital Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
DX^C	Dynex Capital Inc. 6.900% Series C Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DXC	DXC Technology Company Common Stock	2026-06-08 16:48:03.250515+00	Technology	EDP Services	NYSE	\N
DY	Dycom Industries Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Water Sewer Pipeline Comm & Power Line Construction	NYSE	\N
EAF	GrafTech International Ltd. Common Stock	2026-06-08 16:48:03.250515+00	Energy	Industrial Machinery/Components	NYSE	2018
EAI	Entergy Arkansas LLC First Mortgage Bonds 4.875% Series Due September 1 2066	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2016
EARN	Ellington Credit Company Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
EAT	Brinker International Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Restaurants	NYSE	\N
EBF	Ennis Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Office Equipment/Supplies/Services	NYSE	\N
EBS	Emergent BioSolutions Inc. Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2006
ECAT	BlackRock ESG Capital Allocation Term Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2021
ECC	Eagle Point Credit Company Common Share of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2014
ECC^D	Eagle Point Credit Company 6.75% Series D Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
ECCC	Eagle Point Credit Company 6.50% Series C Term Preferred Stock due 2031	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
ECCV	Eagle Point Credit Company 5.375% Notes due 2029	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2022
ECG	Everus Construction Group Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Homebuilding	NYSE	2024
ECL	Ecolab Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	\N
ECVT	Ecovyst Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Major Chemicals	NYSE	2017
ED	Consolidated Edison Inc. Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Power Generation	NYSE	\N
EDD	Morgan Stanley Emerging Markets Domestic Debt Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2007
EDF	Virtus Stone Harbor Emerging Markets Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2010
EE	Excelerate Energy Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Oil/Gas Transmission	NYSE	2022
EEA	The European Equity Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
EEX	Emerald Holding Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Business Services	NYSE	2017
EFC	Ellington Financial Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Real Estate	NYSE	2010
EFC^B	Ellington Financial Inc. 6.250% Series B Fixed-Rate Reset Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EFC^C	Ellington Financial Inc. 8.625% Series C Fixed-Rate Reset Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EFC^D	Ellington Financial Inc. 7.00% Series D Cumulative Perpetual Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EFOR	Everforth Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Professional Services	NYSE	\N
EFR	Eaton Vance Senior Floating-Rate Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2003
EFT	Eaton Vance Floating Rate Income Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2004
EGP	EastGroup Properties Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
EGY	VAALCO Energy Inc.  Common Stock	2026-06-08 16:48:03.250515+00	Energy	Oil & Gas Production	NYSE	\N
EHC	Encompass Health Corporation Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Hospital/Nursing Management	NYSE	\N
EHI	Western Asset Global High Income Fund Inc Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2003
EIC	Eagle Point Income Company Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance/Investors Services	NYSE	2019
EICA	Eagle Point Income Company Inc. 5.00% Series A Term Preferred Stock due 2026	2026-06-08 16:48:03.250515+00	Finance	Finance/Investors Services	NYSE	2021
EIG	Employers Holdings Inc Common Stock	2026-06-08 16:48:03.250515+00	Finance	Property-Casualty Insurers	NYSE	2007
EIX	Edison International Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	\N
EL	Estee Lauder Companies Inc. (The) Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	1995
ELAN	Elanco Animal Health Incorporated Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2018
ELC	Entergy Louisiana Inc. Collateral Trust Mortgage Bonds 4.875 % Series due September 1 2066	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2016
ELF	e.l.f. Beauty Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	2016
ELLA	Ellington Credit Company 8.50% Notes due 2031	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2026
ELME	Elme Communities Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2000
ELS	Equity Lifestyle Properties Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
ELV	Elevance Health Inc. Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Medical Specialities	NYSE	\N
EMD	Western Asset Emerging Markets Debt Fund Inc Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance/Investors Services	NYSE	\N
EME	EMCOR Group Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Engineering & Construction	NYSE	\N
EMF	Templeton Emerging Markets Fund Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance/Investors Services	NYSE	1987
EMN	Eastman Chemical Company Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Major Chemicals	NYSE	\N
EMO	ClearBridge Energy Midstream Opportunity Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2011
EMP	Entergy Mississippi LLC First Mortgage Bonds 4.90% Series Due October 1 2066	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2016
EMR	Emerson Electric Company Common Stock	2026-06-08 16:48:03.250515+00	Technology	Consumer Electronics/Appliances	NYSE	\N
ENJ	Entergy New Orleans LLC First Mortgage Bonds 5.0% Series due December 1 2052	2026-06-08 16:48:03.250515+00	Utilities	Power Generation	NYSE	\N
ENO	Entergy New Orleans LLC First Mortgage Bonds 5.50% Series due April 1 2066	2026-06-08 16:48:03.250515+00	Utilities	Power Generation	NYSE	2016
ENOV	Enovis Corporation Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Industrial Specialties	NYSE	\N
ENR	Energizer Holdings Inc. Common Stock	2026-06-08 16:48:03.250515+00	Miscellaneous	Industrial Machinery/Components	NYSE	2015
ENS	EnerSys Common Stock	2026-06-08 16:48:03.250515+00	Technology	Industrial Machinery/Components	NYSE	2004
ENVA	Enova International Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance: Consumer Services	NYSE	2014
EOD	Allspring Global Dividend Opportunity Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2007
EOG	EOG Resources Inc. Common Stock	2026-06-08 16:48:03.250515+00	Energy	Oil & Gas Production	NYSE	\N
EOI	Eaton Vance Enhance Equity Income Fund Eaton Vance Enhanced Equity Income Fund Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance/Investors Services	NYSE	2004
EOT	Eaton Vance Municipal Income Trust EATON VANCE NATIONAL MUNICIPAL OPPORTUNITIES TRUST	2026-06-08 16:48:03.250515+00	Finance	Investment Bankers/Brokers/Service	NYSE	2009
EP^C	El Paso Corporation Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EPAC	Enerpac Tool Group Corp. Common Stock	2026-06-08 16:48:03.250515+00	Technology	Industrial Machinery/Components	NYSE	\N
EPAM	EPAM Systems Inc. Common Stock	2026-06-08 16:48:03.250515+00	Technology	EDP Services	NYSE	2012
EPC	Edgewell Personal Care Company Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	\N
EPD	Enterprise Products Partners L.P. Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Natural Gas Distribution	NYSE	\N
EPR	EPR Properties Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	1997
EPR^C	EPR Properties 5.75% Series C Cumulative Convertible Preferred Shares	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EPR^E	EPR Properties Series E Cumulative Conv Pfd Shs Ser E	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EPR^G	EPR Properties 5.750% Series G Cumulative Redeemable Preferred Shares	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EPRT	Essential Properties Realty Trust Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2018
EQBK	Equity Bancshares Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Finance	Major Banks	NYSE	\N
EQH	Equitable Holdings Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Specialty Insurers	NYSE	2018
EQH^A	Equitable Holdings Inc. Depositary Shares	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EQH^C	Equitable Holdings Inc. Depositary Shares each representing a 1/1000th interest in a share of Fixed Rate Noncumulative Perpetual Preferred Stock Series C	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
EQR	Equity Residential Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
EQT	EQT Corporation Common Stock	2026-06-08 16:48:03.250515+00	Energy	Oil & Gas Production	NYSE	\N
ES	Eversource Energy (D/B/A) Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	\N
ESAB	ESAB Corporation Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Industrial Machinery/Components	NYSE	2022
ESE	ESCO Technologies Inc. Common Stock	2026-06-08 16:48:03.250515+00	Telecommunications	Telecommunications Equipment	NYSE	\N
ESI	Element Solutions Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Major Chemicals	NYSE	2014
ESRT	Empire State Realty Trust Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
ESS	Essex Property Trust Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
ESTC	Elastic N.V. Ordinary Shares	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Prepackaged Software	NYSE	2018
ET	Energy Transfer LP Common Units	2026-06-08 16:48:03.250515+00	Utilities	Natural Gas Distribution	NYSE	\N
ET^I	Energy Transfer L.P. Series I Fixed Rate Perpetual Preferred Units	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
ETB	Eaton Vance Tax-Managed Buy-Write Income Fund Eaton Vance Tax-Managed Buy-Write Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Bankers/Brokers/Service	NYSE	2005
ETD	Ethan Allen Interiors Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Home Furnishings	NYSE	\N
ETG	Eaton Vance Tax-Advantaged Global Dividend Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2004
ETI^	Entergy Texas Inc 5.375% Series A Preferred Stock Cumulative No Par Value	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
CMS^B	CMS Energy Corporation Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
ETJ	Eaton Vance Risk-Managed Diversified Equity Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2007
ETO	Eaton Vance Tax-Advantage Global Dividend Opp Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2004
ETR	Entergy Corporation Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	\N
ETSY	Etsy Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Business Services	NYSE	2025
ETV	Eaton Vance Corporation Eaton Vance Tax-Managed Buy-Write Opportunities Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Bankers/Brokers/Service	NYSE	2005
ETW	Eaton Vance Corporation Eaton Vance Tax-Managed Global Buy-Write Opportunites Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2005
ETY	Eaton Vance Tax-Managed Diversified Equity Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2006
EVC	Entravision Communications Corporation Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Broadcasting	NYSE	2000
EVEX	Eve Holding Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Aerospace	NYSE	2022
EVF	Eaton Vance Senior Income Trust Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Bankers/Brokers/Service	NYSE	1998
EVG	Eaton Vance Short Diversified Income Fund Eaton Vance Short Duration Diversified Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2005
EVH	Evolent Health Inc Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Other Consumer Services	NYSE	2015
EVMN	Evommune Inc. Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2025
EVN	Eaton Vance Municipal Income Trust Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	1999
EVR	Evercore Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2006
EVT	Eaton Vance Tax Advantaged Dividend Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2003
EW	Edwards Lifesciences Corporation Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Industrial Specialties	NYSE	\N
EXG	Eaton Vance Tax-Managed Global Diversified Equity Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2007
EXP	Eagle Materials Inc Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Building Materials	NYSE	\N
EXPD	Expeditors International of Washington Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Integrated Freight & Logistics	NYSE	\N
EXR	Extra Space Storage Inc Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2004
F	Ford Motor Company Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Auto Manufacturing	NYSE	\N
F^B	Ford Motor Company 6.20% Notes due June 1 2059	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
F^C	Ford Motor Company 6% Notes due December 1 2059	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
F^D	Ford Motor Company 6.500% Notes due August 15 2062	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FAF	First American Corporation (New) Common Stock	2026-06-08 16:48:03.250515+00	Finance	Specialty Insurers	NYSE	\N
FBIN	Fortune Brands Innovations Inc. Common Stock	2026-06-08 16:48:03.250515+00	Basic Materials	Forest Products	NYSE	\N
FBK	FB Financial Corporation Common Stock	2026-06-08 16:48:03.250515+00	Finance	Major Banks	NYSE	2016
FBRT	Franklin BSP Realty Trust Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2021
FBRT^E	Franklin BSP Realty Trust Inc. 7.50% Series E Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FC	Franklin Covey Company Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Other Consumer Services	NYSE	\N
FCF	First Commonwealth Financial Corporation Common Stock	2026-06-08 16:48:03.250515+00	Finance	Major Banks	NYSE	\N
FCN	FTI Consulting Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Professional Services	NYSE	1999
FCPT	Four Corners Property Trust Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
FCT	First Trust Senior Floating Rate Income Fund II Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	2004
FCX	Freeport-McMoRan Inc. Common Stock	2026-06-08 16:48:03.250515+00	Basic Materials	Metal Mining	NYSE	\N
FDS	FactSet Research Systems Inc. Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Programming Data Processing	NYSE	2000
FDX	FedEx Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Air Freight/Delivery Services	NYSE	\N
FE	FirstEnergy Corp. Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	\N
FET	Forum Energy Technologies Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	2012
FF	FutureFuel Corp.  Common shares	2026-06-08 16:48:03.250515+00	Industrials	Major Chemicals	NYSE	\N
FFA	First Trust Enhanced Equity Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	2004
FFC	Flaherty & Crumrine Preferred and Income Securities Fund Incorporated	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2003
FG	F&G Annuities & Life Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Life Insurance	NYSE	2022
FGN	F&G Annuities & Life Inc. 7.950% Senior Notes due 2053	2026-06-08 16:48:03.250515+00	Finance	Life Insurance	NYSE	2023
FGSN	F&G Annuities & Life Inc. 7.300% Junior Subordinated Notes due 2065	2026-06-08 16:48:03.250515+00	Finance	Life Insurance	NYSE	2025
FHI	Federated Hermes Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	\N
FHN	First Horizon Corporation Common Stock	2026-06-08 16:48:03.250515+00	Finance	Major Banks	NYSE	\N
FHN^E	First Horizon Corporation Depositary Shares each representing a 1/4000th interest in a share of Non-Cumulative Perpetual Preferred Stock Series E	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FHN^F	First Horizon Corporation Depositary Shares each representing 1/4000th Interest in a Share of Non-Cumulative Perpetual Preferred Stock Series F	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FHN^H	First Horizon Corporation Depositary Shares each representing a 1/4000th interest in a share of Non-Cumulative Perpetual Preferred Stock Series H	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FICO	Fair Isaac Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Business Services	NYSE	\N
FIG	Figma Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Prepackaged Software	NYSE	2025
FIGS	FIGS Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Apparel	NYSE	2021
FINV	FinVolution Group American Depositary Shares	2026-06-08 16:48:03.250515+00	Finance	Finance: Consumer Services	NYSE	2017
ARTV	Artiva Biotherapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2024
ARTW	Art's-Way Manufacturing Co. Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
ARVN	Arvinas Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
ARWR	Arrowhead Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ARXS	Arxis Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Military/Government/Technical	Nasdaq	2026
ASBP	Aspire Biopharma Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
ASBPW	Aspire Biopharma Holdings Inc. Warrant	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
ASLE	AerSale Corporation Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Industrial Specialties	Nasdaq	2019
ASMB	Assembly Biosciences Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2010
ASO	Academy Sports and Outdoors Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2020
ASPI	ASP Isotopes Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Major Chemicals	Nasdaq	2022
ASRT	Assertio Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ASRV	AmeriServ Financial Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
ATYR	aTyr Pharma Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2015
AUBN	Auburn National Bancorporation Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
AUC	ATIF Holdings Limited Ordinary Shares	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Professional Services	Nasdaq	2019
CUZ	Cousins Properties Incorporated Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CVI	CVR Energy Inc. Common Stock	2026-06-08 16:48:03.250515+00	Energy	Integrated oil Companies	NYSE	2007
CVLG	Covenant Logistics Group Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Trucking Freight/Courier Services	NYSE	\N
CVNA	Carvana Co. Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	2017
CVS	CVS Health Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Staples	Retail-Drug Stores and Proprietary Stores	NYSE	\N
CVSA	Covista Inc. Common Shares	2026-06-08 16:48:03.250515+00	Real Estate	Other Consumer Services	NYSE	\N
CXT	Crane NXT Co. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Metal Fabrications	NYSE	\N
FIS	Fidelity National Information Services Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Business Services	NYSE	\N
FIX	Comfort Systems USA Inc. Common Stock	2026-06-08 16:48:03.250515+00	Industrials	Engineering & Construction	NYSE	1997
FLC	Flaherty & Crumrine Total Return Fund Inc Common Stock	2026-06-08 16:48:03.250515+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2003
FLG^A	Flagstar Bank N.A. Depositary shares each representing a 1/40th interest in a share of Fixed-to-Floating Rate Series A Noncumulative Perpetual Preferred Stock	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FLG^U	Flagstar Bank N.A. Bifurcated Option Note Unit SecuritiES	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
FLO	Flowers Foods Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Staples	Packaged Foods	NYSE	\N
FLOC	Flowco Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	2025
GE	GE Aerospace Common Stock	2026-06-08 16:48:03.265527+00	Technology	Consumer Electronics/Appliances	NYSE	\N
GEL	Genesis Energy L.P. Common Units	2026-06-08 16:48:03.265527+00	Energy	Oil Refining/Marketing	NYSE	2001
GEO	Geo Group Inc (The) REIT	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Homebuilding	NYSE	\N
GETY	Getty Images Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Business Services	NYSE	2022
GEV	GE Vernova Inc. Common Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	2024
GF	New Germany Fund Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	1990
GFF	Griffon Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Building Products	NYSE	\N
GGG	Graco Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Fluid Controls	NYSE	\N
GGT	Gabelli Multi-Media Trust Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
GGT^E	Gabelli Multi-Media Trust Inc. (The) 5.125% Series E Cumulative Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GGT^G	Gabelli Multi-Media Trust Inc. (The) 5.125% Series G Cumulative Preferred Shares	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GHC	Graham Holdings Company Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Other Consumer Services	NYSE	\N
GHI	Greystone Housing Impact Investors LP Beneficial Unit Certificates representing assignments of limited partnership interests	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	2022
GHM	Graham Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Industrial Machinery/Components	NYSE	1978
GHY	PGIM Global High Yield Fund Inc.	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2012
GIC	Global Industrial Company Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Industrial Machinery/Components	NYSE	\N
GIS	General Mills Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Staples	Packaged Foods	NYSE	\N
GJH	Synthetic Fixed-Income Securities Inc 6.375% (STRATS) Cl A-1	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	\N
GJO	Synthetic Fixed-Income Securities Inc. on behalf of STRATS(SM) Trust for Wal-Mart Stores Inc. Securities Series 2004-5	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	\N
GJR	Synthetic Fixed-Income Securities Inc. STRATS Trust for Procter&Gamble Securities Series 2006-1	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	\N
GJS	Goldman Sachs Group Securities STRATS Trust for Goldman Sachs Group Securities Series 2006-2	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	\N
GJT	Synthetic Fixed-Income Securities Inc. Floating Rate Structured Repackaged Asset-Backed Trust Securities Certificates Series 2006-3	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	\N
GKOS	Glaukos Corporation Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Medical/Dental Instruments	NYSE	2015
GL^D	Globe Life Inc. 4.25% Junior Subordinated Debentures due 2061	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GLOB	Globant S.A. Common Shares	2026-06-08 16:48:03.265527+00	Technology	EDP Services	NYSE	2014
GLP	Global Partners LP Common Units representing Limited Partner Interests	2026-06-08 16:48:03.265527+00	Energy	Oil Refining/Marketing	NYSE	2005
GLP^B	Global Partners LP 9.50% Series B Fixed Rate Cumulative Redeemable Perpetual Preferred Units representing limited partner interests	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GLW	Corning Incorporated Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Telecommunications Equipment	NYSE	\N
GM	General Motors Company Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Auto Manufacturing	NYSE	2010
GME	GameStop Corporation Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Electronics Distribution	NYSE	2002
GMED	Globus Medical Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Medical/Dental Instruments	NYSE	2012
GNE	Genie Energy Ltd. Class B Common Stock Stock	2026-06-08 16:48:03.265527+00	Utilities	Power Generation	NYSE	2011
GNK	Genco Shipping & Trading Limited Ordinary Shares New (Marshall Islands)	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Marine Transportation	NYSE	\N
GNL	Global Net Lease Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
GNL^A	Global Net Lease Inc. 7.25% Series A Cumulative Redeemable Preferred Stock $0.01 par value per share	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GNL^B	Global Net Lease Inc. 6.875% Series B Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GNL^D	Global Net Lease Inc. 7.50% Series D Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GNL^E	Global Net Lease Inc. 7.375% Series E Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GNRC	Generac Holdlings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Metal Fabrications	NYSE	2010
GNT	GAMCO Natural Resources Gold & Income Trust	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	2011
GNT^A	GAMCO Natural Resources Gold & Income Tust  5.20% Series A Cumulative Preferred Shares (Liquidation Preference $25.00 per share)	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GNW	Genworth Financial Inc Common Stock	2026-06-08 16:48:03.265527+00	Finance	Life Insurance	NYSE	2004
GOF	Guggenheim Strategic Opportunities Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	\N
GOLD	Gold.com Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Other Specialty Stores	NYSE	\N
GOLF	Acushnet Holdings Corp. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Recreational Games/Products/Toys	NYSE	2016
GPC	Genuine Parts Company Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Automotive Aftermarket	NYSE	\N
GPGI	GPGI Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	\N
GPI	Group 1 Automotive Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	1997
GPJA	Georgia Power Company Series 2017A 5.00% Junior Subordinated Notes due October 1 2077	2026-06-08 16:48:03.265527+00	Utilities	Electric Utilities: Central	NYSE	2017
GPK	Graphic Packaging Holding Company	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Containers/Packaging	NYSE	\N
GPMT	Granite Point Mortgage Trust Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	2017
GPMT^A	Granite Point Mortgage Trust Inc. 7.00% Series A Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GPN	Global Payments Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Business Services	NYSE	\N
GPOR	Gulfport Energy Corporation Common Shares	2026-06-08 16:48:03.265527+00	Energy	Oil & Gas Production	NYSE	2021
GRBK	Green Brick Partners Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Homebuilding	NYSE	2021
GRBK^A	Green Brick Partners Inc. Depositary Shares (each representing a 1/1000th fractional interest in a share of 5.75% Series A Cumulative Perpetual Preferred Stock)	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GRC	Gorman-Rupp Company (The) Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Fluid Controls	NYSE	1971
GRDN	Guardian Pharmacy Services Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Staples	Retail-Drug Stores and Proprietary Stores	NYSE	2024
GRNT	Granite Ridge Resources Inc. Common Stock	2026-06-08 16:48:03.265527+00	Energy	Oil & Gas Production	NYSE	2022
GRX	The Gabelli Healthcare & Wellness Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	\N
GS	Goldman Sachs Group Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Bankers/Brokers/Service	NYSE	1999
GS^A	Goldman Sachs Group Inc. (The) Depositary Shares each representing 1/1000th Interest in a Share of Floating Rate Non-Cumulative Preferred Stock Series A	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GS^C	Goldman Sachs Group Inc. (The) Depositary Share repstg 1/1000th Preferred Series C	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GS^D	Goldman Sachs Group Inc. (The) Dep Shs repstg 1/1000 Pfd Ser D Fltg	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GSBD	Goldman Sachs BDC Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2015
GTLS	Chart Industries Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Metal Fabrications	NYSE	2006
GTN	Gray Media Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Broadcasting	NYSE	\N
GTY	Getty Realty Corporation Common Stock	2026-06-08 16:48:03.265527+00	Finance	Real Estate	NYSE	\N
GUG	Guggenheim Active Allocation Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2021
GUT	Gabelli Utility Trust (The) Common Stock	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
GUT^C	Gabelli Utility Trust (The) 5.375% Series C Cumulative Preferred Shares	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GVA	Granite Construction Incorporated Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Military/Government/Technical	NYSE	\N
GWH	ESS Tech Inc. Common Stock	2026-06-08 16:48:03.265527+00	Miscellaneous	Industrial Machinery/Components	NYSE	\N
GWRE	Guidewire Software Inc. Common Stock	2026-06-08 16:48:03.265527+00	Technology	Computer Software: Prepackaged Software	NYSE	2012
GWW	W.W. Grainger Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Office Equipment/Supplies/Services	NYSE	\N
GXO	GXO Logistics Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Transportation Services	NYSE	2021
H	Hyatt Hotels Corporation Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Hotels/Resorts	NYSE	2009
HAE	Haemonetics Corporation Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Medical/Dental Instruments	NYSE	1991
HAL	Halliburton Company Common Stock	2026-06-08 16:48:03.265527+00	Energy	Oilfield Services/Equipment	NYSE	\N
HASI	HA Sustainable Infrastructure Capital Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	2013
HAYW	Hayward Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Industrial Machinery/Components	NYSE	2021
HBB	Hamilton Beach Brands Holding Company Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Home Furnishings	NYSE	2017
HCA	HCA Healthcare Inc. Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Hospital/Nursing Management	NYSE	2011
HCC	Warrior Met Coal Inc. Common Stock	2026-06-08 16:48:03.265527+00	Energy	Coal Mining	NYSE	2017
HCI	HCI Group Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Property-Casualty Insurers	NYSE	\N
HCXY	Hercules Capital Inc. 6.25% Notes due 2033	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2018
HD	Home Depot Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	\N
HE	Hawaiian Electric Industries Inc. Common Stock	2026-06-08 16:48:03.265527+00	Utilities	Electric Utilities: Central	NYSE	\N
HEI	Heico Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Aerospace	NYSE	2000
HEQ	John Hancock Diversified Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2011
HESM	Hess Midstream LP Class A Representing Limited Partner Interests	2026-06-08 16:48:03.265527+00	Energy	Oil & Gas Production	NYSE	2017
HFRO	Highland Opportunities and Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	2017
HFRO^A	Highland Opportunities and Income Fund 5.375% Series A Cumulative Preferred Shares	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HFRO^B	Highland Opportunities and Income Fund 5.375% Series B Cumulative Preferred Shares	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HGTY	Hagerty Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Finance	Specialty Insurers	NYSE	2021
HGV	Hilton Grand Vacations Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Hotels/Resorts	NYSE	2016
HHH	Howard Hughes Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
HIG	The Hartford Insurance Group Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Property-Casualty Insurers	NYSE	\N
HIG^G	The Hartford Insurance Group Inc. Depositary Shares each representing a 1/1000th interest in a share of 6.000% Non-Cumulative Preferred Stock Series G	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HII	Huntington Ingalls Industries Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Marine Transportation	NYSE	\N
HIMS	Hims & Hers Health Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Medical/Nursing Services	NYSE	2019
HIO	Western Asset High Income Opportunity Fund Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	\N
HIPO	Hippo Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Property-Casualty Insurers	NYSE	2021
HIW	Highwoods Properties Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
HIX	Western Asset High Income Fund II Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	1998
HL	Hecla Mining Company Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	\N
HL^B	Hecla Mining Company Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HLI	Houlihan Lokey Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2015
HLIO	Helios Technologies Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Metal Fabrications	NYSE	2021
HLT	Hilton Worldwide Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Hotels/Resorts	NYSE	2016
HLX	Helix Energy Solutions Group Inc. Common Stock	2026-06-08 16:48:03.265527+00	Energy	Oilfield Services/Equipment	NYSE	\N
HMN	Horace Mann Educators Corporation Common Stock	2026-06-08 16:48:03.265527+00	Finance	Property-Casualty Insurers	NYSE	1991
HNGE	Hinge Health Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Technology	EDP Services	NYSE	2025
HNI	HNI Corporation Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Office Equipment/Supplies/Services	NYSE	\N
HOG	Harley-Davidson Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Motor Vehicles	NYSE	\N
HOMB	Home BancShares Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Major Banks	NYSE	2006
HOV	Hovnanian Enterprises Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Homebuilding	NYSE	1983
HP	Helmerich & Payne Inc. Common Stock	2026-06-08 16:48:03.265527+00	Energy	Oil & Gas Production	NYSE	\N
HPE	Hewlett Packard Enterprise Company Common Stock	2026-06-08 16:48:03.265527+00	Technology	Retail: Computer Software & Peripheral Equipment	NYSE	2015
HPE^C	Hewlett Packard Enterprise Company 7.625% Series C Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HPF	John Hancock Pfd Income Fund II Pfd Income Fund II	2026-06-08 16:48:03.265527+00	Finance	Finance Companies	NYSE	2002
AUGO	Aura Minerals Inc. Common Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	\N
HPI	John Hancock Preferred Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2002
HPP	Hudson Pacific Properties Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Real Estate	NYSE	2010
HPP^C	Hudson Pacific Properties Inc. 4.750% Series C Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HPQ	HP Inc. Common Stock	2026-06-08 16:48:03.265527+00	Technology	Computer Manufacturing	NYSE	\N
HPS	John Hancock Preferred Income Fund III Preferred Income Fund III	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2003
HQH	abrdn Healthcare Investors Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance Companies	NYSE	1987
HQL	abrdn Life Sciences Investors Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	1992
HR	Healthcare Realty Trust Incorporated Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
HRB	H&R Block Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Other Consumer Services	NYSE	\N
HRI	Herc Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Misc Corporate Leasing Services	NYSE	2016
HRL	Hormel Foods Corporation Common Stock	2026-06-08 16:48:03.265527+00	Consumer Staples	Meat/Poultry/Fish	NYSE	\N
HRTG	Heritage Insurance Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Property-Casualty Insurers	NYSE	2014
HSY	The Hershey Company Common Stock	2026-06-08 16:48:03.265527+00	Consumer Staples	Specialty Foods	NYSE	\N
HTB	HomeTrust Bancshares Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Savings Institutions	NYSE	\N
HTD	John Hancock Tax Advantaged Dividend Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance Companies	NYSE	2004
HTFC	Horizon Technology Finance Corporation 6.25% Notes due 2027	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	2022
HTGC	Hercules Capital Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2012
HUBB	Hubbell Inc Common Stock	2026-06-08 16:48:03.265527+00	Technology	Electrical Products	NYSE	2015
HUBS	HubSpot Inc. Common Stock	2026-06-08 16:48:03.265527+00	Technology	Computer Software: Prepackaged Software	NYSE	2014
HUM	Humana Inc. Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Medical Specialities	NYSE	\N
HUN	Huntsman Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Major Chemicals	NYSE	2005
HUYA	HUYA Inc. American depositary shares each  representing one Class A ordinary share	2026-06-08 16:48:03.265527+00	Technology	Computer Software: Programming Data Processing	NYSE	2018
HVT	Haverty Furniture Companies Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Other Specialty Stores	NYSE	\N
HVT/A	Haverty Furniture Companies Inc.	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
HWM	Howmet Aerospace Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Metal Fabrications	NYSE	\N
HXL	Hexcel Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Major Chemicals	NYSE	\N
HY	Hyster-Yale Inc. Class A common stock	2026-06-08 16:48:03.265527+00	Industrials	Construction/Ag Equipment/Trucks	NYSE	\N
HYT	Blackrock Corporate High Yield Fund Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance Companies	NYSE	2003
HZO	MarineMax Inc.  (FL) Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Auto & Home Supply Stores	NYSE	1998
IAE	Voya Asia Pacific High Dividend Equity Income Fund ING Asia Pacific High Dividend Equity Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2007
IBM	International Business Machines Corporation Common Stock	2026-06-08 16:48:03.265527+00	Technology	Computer Manufacturing	NYSE	\N
IBP	Installed Building Products Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Homebuilding	NYSE	2014
IBTA	Ibotta Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Advertising	NYSE	2024
ICE	Intercontinental Exchange Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Bankers/Brokers/Service	NYSE	2005
IDA	IDACORP Inc. Common Stock	2026-06-08 16:48:03.265527+00	Utilities	Electric Utilities: Central	NYSE	\N
IDE	Voya Infrastructure Industrials and Materials Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	2010
IDT	IDT Corporation Class B Common Stock	2026-06-08 16:48:03.265527+00	Telecommunications	Telecommunications Equipment	NYSE	\N
IEX	IDEX Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Fluid Controls	NYSE	1989
IFF	International Flavors & Fragrances Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Major Chemicals	NYSE	\N
IFN	Aberdeen India Fund Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	\N
IGA	Voya Global Advantage and Premium Opportunity Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2005
IGD	Voya Global Equity Dividend and Premium Opportunity Fund	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2005
IGI	Western Asset Investment Grade Opportunity Trust Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2009
IGR	CBRE Global Real Estate Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance Companies	NYSE	2004
IH	iHuman Inc. American depositary shares each representing five Class A ordinary shares	2026-06-08 16:48:03.265527+00	Real Estate	Other Consumer Services	NYSE	2020
IHD	Voya Emerging Markets High Income Dividend Equity Fund Common Shares	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2011
IIF	Morgan Stanley India Investment Fund Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1994
IIIN	Insteel Industries Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Steel/Iron Ore	NYSE	\N
IIM	Invesco Value Municipal Income Trust Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	\N
IIPR	Innovative Industrial Properties Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Real Estate	NYSE	2016
IIPR^A	Innovative Industrial Properties Inc. 9.00% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
INGM	Ingram Micro Holding Corporation Common Stock	2026-06-08 16:48:03.265527+00	Technology	Retail: Computer Software & Peripheral Equipment	NYSE	2024
INGR	Ingredion Incorporated Common Stock	2026-06-08 16:48:03.265527+00	Consumer Staples	Packaged Foods	NYSE	\N
INN	Summit Hotel Properties Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	2011
INN^E	Summit Hotel Properties Inc. 6.250% Series E Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
INN^F	Summit Hotel Properties Inc. 5.875% Series F Cumulative Redeemable Preferred Stock $0.01 par value per share	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
AUID	authID Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
AUR	Aurora Innovation Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	2021
AURA	Aura Biosciences Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
AUROW	Aurora Innovation Inc. Warrant	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	2021
AUUD	Auddia Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	2021
AVAH	Aveanna Healthcare Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Nursing Services	Nasdaq	2021
AVAV	AeroVironment Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Aerospace	Nasdaq	2007
AVBH	Avidbank Holdings Inc. Common stock	2026-06-08 16:48:03.035838+00	Finance	Commercial Banks	Nasdaq	\N
AVBP	ArriVent BioPharma Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
AVGO	Broadcom Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Semiconductors	Nasdaq	2009
AVIR	Atea Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
AVLN	Avalyn Pharma Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2026
AVNW	Aviat Networks Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	\N
AVO	Mission Produce Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	2020
AVPT	AvePoint Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2019
AVR	Anteris Technologies Global Corp. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Industrial Specialties	Nasdaq	2024
AVT	Avnet Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Electronic Components	Nasdaq	\N
AVTX	Avalo Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
AVXL	Anavex Life Sciences Corp. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
AWRE	Aware Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1996
AXGN	Axogen Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
AXON	Axon Enterprise Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Ordnance And Accessories	Nasdaq	2001
AXSM	Axsome Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
INR	Infinity Natural Resources Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Energy	Oil & Gas Production	NYSE	2025
INSP	Inspire Medical Systems Inc. Common Stock	2026-06-08 16:48:03.265527+00	Health Care	Medical/Dental Instruments	NYSE	2018
INSW	International Seaways Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Marine Transportation	NYSE	2016
INVH	Invitation Homes Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Real Estate	NYSE	2017
INVX	Innovex International Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	\N
IONQ	IonQ Inc. Common Stock	2026-06-08 16:48:03.265527+00	Technology	EDP Services	NYSE	2021
IOT	Samsara Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Technology	EDP Services	NYSE	2021
IP	International Paper Company Common Stock	2026-06-08 16:48:03.265527+00	Basic Materials	Paper	NYSE	\N
JOF	Japan Smaller Capitalization Fund Inc Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1990
JPC	Nuveen Preferred & Income Opportunities Fund	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2003
JPM	JP Morgan Chase & Co. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Major Banks	NYSE	\N
JPM^C	J P Morgan Chase & Co Depositary Shares each representing a 1/400th interest in a share of 6.00% Non-Cumulative  Preferred Stock Series EE	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
JPM^D	J P Morgan Chase & Co Depositary Shares each representing a 1/400th  interest in a share of 5.75% Non-Cumulative  Preferred Stock Series DD	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
FLG	Flagstar Bank N.A. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Banks	NYSE	\N
FLR	Fluor Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Military/Government/Technical	NYSE	\N
FLS	Flowserve Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Fluid Controls	NYSE	\N
FMC	FMC Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Major Chemicals	NYSE	\N
FMN	Federated Hermes Premier Municipal Income Fund	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2002
FMY	First Trust Mortgage Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	2005
FNB	F.N.B. Corporation Common Stock	2026-06-08 16:48:03.265527+00	Finance	Major Banks	NYSE	\N
FND	Floor & Decor Holdings Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	2017
FNF	Fidelity National Financial Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Specialty Insurers	NYSE	2014
GEF	Greif Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
JPM^J	J P Morgan Chase & Co Depositary Shares each representing a 1/400th interest in a share of JPMorgan Chase & Co. 4.75% Non-Cumulative Preferred Stock Series GG	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
JPM^K	J P Morgan Chase & Co Depositary Shares each representing a 1/400th interest in a share of 4.55% Non-Cumulative Preferred Stock Series JJ	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
JPM^L	J P Morgan Chase & Co Depositary Shares each representing a 1/400th interest in a share of 4.625% Non-Cumulative Preferred Stock Series LL	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
JPM^M	J P Morgan Chase & Co Depositary Shares each representing a 1/400th interest in a share of 4.20% Non-Cumulative Preferred Stock Series MM	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
JQC	Nuveen Credit Strategies Income Fund Shares of Beneficial Interest	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	2003
JRI	Nuveen Real Asset Income and Growth Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	2012
JRS	Nuveen Real Estate Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.279539+00	Finance	Finance/Investors Services	NYSE	2001
JXN	Jackson Financial Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Finance	Life Insurance	NYSE	2021
JXN^A	Jackson Financial Inc. Depositary Shares each representing a 1/1000th interest in a share of Fixed-Rate Reset Noncumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KAI	Kadant Inc Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	1992
KBH	KB Home Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Homebuilding	NYSE	1986
KBR	KBR Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Military/Government/Technical	NYSE	2006
KD	Kyndryl Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Technology	EDP Services	NYSE	2021
KEX	Kirby Corporation Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Marine Transportation	NYSE	\N
KEY	KeyCorp Common Stock	2026-06-08 16:48:03.279539+00	Finance	Major Banks	NYSE	\N
KEY^I	KeyCorp Depositary Shares Each Representing a 1/40th Ownership Interest in a Share of Fixed-to-Floating Rate Perpetual Non-Cumulative Preferred Stock Series E	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KEY^J	KeyCorp Depositary Shares each representing a 1/40th ownership interest in a share of Fixed Rate Perpetual Non-Cumulative Preferred Stock Series F	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KEY^K	KeyCorp Depositary Shares each representing a 1/40th ownership interest in a share of Fixed Rate Perpetual Non-Cumulative Preferred Stock Series G	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KEY^L	KeyCorp Depositary Shares each representing a 1/40th ownership interest in a share of Fixed Rate Perpetual Non-Cumulative Preferred Stock Series H	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KEYS	Keysight Technologies Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	2014
KF	Korea Fund Inc. (The) New Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	\N
KFRC	Kforce Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Professional Services	NYSE	1995
KFY	Korn Ferry Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Diversified Commercial Services	NYSE	1999
KGS	Kodiak Gas Services Inc. Common Stock	2026-06-08 16:48:03.279539+00	Utilities	Natural Gas Distribution	NYSE	2023
KIM	Kimco Realty Corporation (HC) Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
KIM^L	Kimco Realty Corporation Class L Depositary Shares each of which represents a one-one thousandth fractional interest in a share of 5.125% Class L Cumulative Redeemable Preferred Stock liquidation preference $25000.00 per share	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KIM^M	Kimco Realty Corporation Class M Depositary Shares each of which represents a one-one thousandth fractional interest in a share of 5.25% Class M Cumulative Redeemable Preferred Stock liquidation preference $25000.00 per share	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KIM^N	Kimco Realty Corporation Depositary Shares each representing 1/1000th interest in a share of 7.25% Class N Cumulative Convertible Perpetual Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KIO	KKR Income Opportunities Fund Common Shares	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2013
KKR	KKR & Co. Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	\N
KKR^D	KKR & Co. Inc. 6.25% Series D Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KKRS	KKR Group Finance Co. IX LLC 4.625% Subordinated Notes due 2061	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2021
KKRT	KKR & Co. Inc. 6.875% Subordinated Notes due 2065	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2025
KLC	KinderCare Learning Companies Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Other Consumer Services	NYSE	2024
KMI	Kinder Morgan Inc. Common Stock	2026-06-08 16:48:03.279539+00	Utilities	Natural Gas Distribution	NYSE	2011
KMPB	Kemper Corporation 5.875% Fixed-Rate Reset Junior Subordinated Debentures due 2062	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	2022
KMPR	Kemper Corporation	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	\N
KMT	Kennametal Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	\N
KMX	CarMax Inc	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	\N
KN	Knowles Corporation Common Stock	2026-06-08 16:48:03.279539+00	Consumer Staples	Consumer Electronics/Appliances	NYSE	2014
KNF	Knife Riv Holding Co. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	2023
KNSL	Kinsale Capital Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	\N
KNTK	Kinetik Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Utilities	Natural Gas Distribution	NYSE	2022
KNX	Knight-Swift Transportation Holdings Inc.	2026-06-08 16:48:03.279539+00	Industrials	Trucking Freight/Courier Services	NYSE	2017
KO	Coca-Cola Company (The) Common Stock	2026-06-08 16:48:03.279539+00	Consumer Staples	Beverages (Production/Distribution)	NYSE	\N
KODK	Eastman Kodak Company Common New	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Industrial Machinery/Components	NYSE	\N
KOP	Koppers Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Forest Products	NYSE	2006
KORE	KORE Group Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Telecommunications	Telecommunications Equipment	NYSE	\N
KR	Kroger Company (The) Common Stock	2026-06-08 16:48:03.279539+00	Consumer Staples	Food Chains	NYSE	\N
KRC	Kilroy Realty Corporation Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	1997
KREF	KKR Real Estate Finance Trust Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2017
KREF^A	KKR Real Estate Finance Trust Inc. 6.50% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
KRG	Kite Realty Group Trust Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2004
KRMN	Karman Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Military/Government/Technical	NYSE	2025
KRO	Kronos Worldwide Inc Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Major Chemicals	NYSE	\N
KRP	Kimbell Royalty Partners Common Units Representing Limited Partner Interests	2026-06-08 16:48:03.279539+00	Energy	Oil & Gas Production	NYSE	2017
KSS	Kohl's Corporation Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	1992
KTB	Kontoor Brands Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Garments and Clothing	NYSE	2019
KTF	DWS Municipal Income Trust	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	1988
KTH	Structures Products Cp 8% CorTS Issued by Peco Energy Cap Tr II Preferred Stock	2026-06-08 16:48:03.279539+00	Finance	Finance: Consumer Services	NYSE	\N
KTN	Structured Products Corp 8.205% CorTS 8.205% Corporate Backed Trust Securities (CorTS)	2026-06-08 16:48:03.279539+00	Finance	Finance: Consumer Services	NYSE	\N
KVUE	Kenvue Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Specialty Chemicals	NYSE	2023
KVYO	Klaviyo Inc. Series A Common Stock	2026-06-08 16:48:03.279539+00	Technology	Computer Software: Prepackaged Software	NYSE	2023
KW	Kennedy-Wilson Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Real Estate	NYSE	\N
KWR	Quaker Houghton Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Major Chemicals	NYSE	\N
KYN	Kayne Anderson Energy Infrastructure Fund Inc.	2026-06-08 16:48:03.279539+00	Finance	Finance/Investors Services	NYSE	2004
L	Loews Corporation Common Stock	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	\N
LAD	Lithia Motors Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	\N
LADR	Ladder Capital Corp Class A Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2014
LAW	CS Disco Inc. Common Stock	2026-06-08 16:48:03.279539+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
LBRT	Liberty Energy Inc. Class A common stock	2026-06-08 16:48:03.279539+00	Energy	Oilfield Services/Equipment	NYSE	2018
LC	LendingClub Corporation Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance: Consumer Services	NYSE	2014
LCII	LCI Industries	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	1995
LDI	loanDepot Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance: Consumer Services	NYSE	2021
LDOS	Leidos Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Technology	EDP Services	NYSE	\N
LDP	Cohen & Steers Limited Duration Preferred and Income Fund Inc.	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	2012
LEA	Lear Corporation Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
LEG	Leggett & Platt Incorporated Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Home Furnishings	NYSE	\N
LEN	Lennar Corporation Class A Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Homebuilding	NYSE	\N
LEO	BNY Mellon Strategic Municipals Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1987
LEU	Centrus Energy Corp. Class A Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	2014
LEVI	Levi Strauss & Co Class A Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Apparel	NYSE	2019
LFT	Lument Finance Trust Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
LFT^A	Lument Finance Trust Inc. 7.875% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
LGI	Lazard Global Total Return and Income Fund Common Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	2004
LH	Labcorp Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Medical Specialities	NYSE	\N
LHX	L3Harris Technologies Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	\N
LII	Lennox International Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	1999
LLY	Eli Lilly and Company Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
LMND	Lemonade Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	2020
LMT	Lockheed Martin Corporation Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Military/Government/Technical	NYSE	\N
LNC	Lincoln National Corporation Common Stock	2026-06-08 16:48:03.279539+00	Finance	Life Insurance	NYSE	\N
LNC^D	Lincoln National Corporation Depositary Shares Each Representing a 1/1000th Interest in a Share of 9.000% Non-Cumulative Preferred Stock Series D	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
LNG	Cheniere Energy Inc. Common Stock	2026-06-08 16:48:03.279539+00	Utilities	Oil/Gas Transmission	NYSE	2001
LNN	Lindsay Corporation Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	\N
AXTI	AXT Inc Common Stock	2026-06-08 16:48:03.035838+00	Technology	Semiconductors	Nasdaq	1998
HEI/A	Heico Corporation	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
LOAR	Loar Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Military/Government/Technical	NYSE	2024
LOB	Live Oak Bancshares Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Major Banks	NYSE	2022
LOB^A	Live Oak Bancshares Inc. Depositary Shares Each Representing a 1/40th Interest in a Share of 8.375% Fixed Rate Series A Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
LOW	Lowe's Companies Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	\N
LPG	Dorian LPG Ltd. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Marine Transportation	NYSE	2014
LPX	Louisiana-Pacific Corporation Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Forest Products	NYSE	\N
LRN	Stride Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Other Consumer Services	NYSE	\N
LTC	LTC Properties Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
LTH	Life Time Group Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Hotels/Resorts	NYSE	2021
LUCK	Lucky Strike Entertainment Corporation Class A Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2021
LUMN	Lumen Technologies Inc. Common Stock	2026-06-08 16:48:03.279539+00	Telecommunications	Telecommunications Equipment	NYSE	\N
LUV	Southwest Airlines Company Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Air Freight/Delivery Services	NYSE	\N
LVS	Las Vegas Sands Corp. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Hotels/Resorts	NYSE	2004
LVWR	LiveWire Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Motor Vehicles	NYSE	2022
LW	Lamb Weston Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Staples	Packaged Foods	NYSE	2016
LXP	LXP Industrial Trust Common Stock (Maryland REIT)	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
LXP^C	LXP Industrial Trust 6.5% Series C Cumulative Convertible Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
LXU	LSB Industries Inc. Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Major Chemicals	NYSE	2003
LYV	Live Nation Entertainment Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	\N
LZB	La-Z-Boy Incorporated Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Home Furnishings	NYSE	\N
M	Macy's Inc Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	\N
MA	Mastercard Incorporated Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Business Services	NYSE	2006
MAA	Mid-America Apartment Communities Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
MAA^I	Mid-America Apartment Communities Inc. 8.50% Series I Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MAC	Macerich Company (The) Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
MAGN	Magnera Corporation Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Paper	NYSE	2000
MAIN	Main Street Capital Corporation Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance/Investors Services	NYSE	2007
MAN	ManpowerGroup Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Professional Services	NYSE	\N
MAS	Masco Corporation Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Specialties	NYSE	\N
MATV	Mativ Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Paper	NYSE	\N
MATX	Matson Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Marine Transportation	NYSE	\N
MAX	MediaAlpha Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Business Services	NYSE	2020
MBC	MasterBrand Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Home Furnishings	NYSE	2022
MBI	MBIA Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	1987
MC	Moelis & Company Class A Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2014
MCB	Metropolitan Bank Holding Corp. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Major Banks	NYSE	2017
MCD	McDonald's Corporation Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Restaurants	NYSE	\N
MCI	Barings Corporate Investors Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
MCK	McKesson Corporation Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Other Pharmaceuticals	NYSE	\N
MCN	XAI Madison Equity Premium Income Fund Common Shares	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	2004
MCO	Moody's Corporation Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance: Consumer Services	NYSE	\N
MCR	MFS Charter Income Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1989
MCS	Marcus Corporation (The) Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Movies/Entertainment	NYSE	\N
MCY	Mercury General Corporation Common Stock	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	\N
MD	Pediatrix Medical Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Hospital/Nursing Management	NYSE	\N
MDT	Medtronic plc. Ordinary Shares	2026-06-08 16:48:03.279539+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	NYSE	\N
MDU	MDU Resources Group Inc. Common Stock (Holding Company)	2026-06-08 16:48:03.279539+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	\N
MDV	Modiv Industrial Inc. Class C Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2022
MDV^A	Modiv Industrial Inc. 7.375% Series A Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MEC	Mayville Engineering Company Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Specialties	NYSE	2019
MED	MEDIFAST INC Common Stock	2026-06-08 16:48:03.279539+00	Consumer Staples	Packaged Foods	NYSE	\N
MEGI	NYLI CBRE Global Infrastructure Megatrends Term Fund Common Shares	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2021
MEI	Methode Electronics Inc. Common Stock	2026-06-08 16:48:03.279539+00	Technology	Electrical Products	NYSE	\N
MER^K	Bank of America Corporation Income Capital Obligation Notes initially due December 15 2066	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MET	MetLife Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Life Insurance	NYSE	2000
MET^A	MetLife Inc. Preferred Series A Floating Rate	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MET^E	MetLife Inc. Depositary Shares	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MET^F	MetLife Inc. Depositary Shares each representing a 1/1000th interest in a share of 4.75% Non-Cumulative Preferred Stock Series F	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MFA	MFA Financial Inc.	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
AYTU	Aytu BioPharma Inc.  Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
AZTA	Azenta Inc.	2026-06-08 16:48:03.035838+00	Technology	Industrial Machinery/Components	Nasdaq	\N
BACC	Blue Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BACCR	Blue Acquisition Corp. Right	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BACCU	Blue Acquisition Corp. Unit	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BAER	Bridger Aerospace Group Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Aerospace	Nasdaq	\N
BAERW	Bridger Aerospace Group Holdings Inc. Warrant	2026-06-08 16:48:03.035838+00	Industrials	Aerospace	Nasdaq	\N
BAFN	BayFirst Financial Corp. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BAND	Bandwidth Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2017
BANF	BancFirst Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	1993
BANFP	BancFirst Corporation - BFC Capital Trust II Cumulative Trust Preferred Securities	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BANR	Banner Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BANX	ArrowMark Financial Corp. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Trusts Except Educational Religious and Charitable	Nasdaq	\N
BATRA	Atlanta Braves Holdings Inc. Series A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
HTH	Hilltop Holdings Inc.	2026-06-08 16:48:03.265527+00	Finance	Major Banks	NYSE	\N
MFA^B	MFA Financial Inc. Preferred Series B	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MFA^C	MFA Financial Inc. 6.50% Series C Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MFAN	MFA Financial Inc. 8.875% Senior Notes due 2029	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
MFAO	MFA Financial Inc. 9.000% Senior Notes due 2029	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
MFM	MFS Municipal Income Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	1986
MG	Mistras Group Inc Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Military/Government/Technical	NYSE	2009
MGF	MFS Government Markets Income Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1987
MGM	MGM Resorts International Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Hotels/Resorts	NYSE	\N
MGR	Affiliated Managers Group Inc. 5.875% Junior Subordinated Notes due 2059	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2019
MGRB	Affiliated Managers Group Inc. 4.750% Junior Subordinated Notes due 2060	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2020
MGRD	Affiliated Managers Group Inc. 4.200% Junior Subordinated Notes due 2061	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2021
MGRE	Affiliated Managers Group Inc. 6.750% Junior Subordinated Notes due 2064	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2024
MGY	Magnolia Oil & Gas Corporation Class A Common Stock	2026-06-08 16:48:03.279539+00	Energy	Oil & Gas Production	NYSE	2017
MHD	Blackrock MuniHoldings Fund Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Bankers/Brokers/Service	NYSE	1997
MHF	Western Asset Municipal High Income Fund Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance/Investors Services	NYSE	1988
MHK	Mohawk Industries Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Home Furnishings	NYSE	\N
MHO	M/I Homes Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Homebuilding	NYSE	1993
MIAX	Miami International Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Bankers/Brokers/Service	NYSE	2025
MIN	MFS Intermediate Income Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1988
MIR	Mirion Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	2020
MITN	TPG Mortgage Investment Trust Inc. 9.500% Senior Notes due 2029	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
MITP	TPG Mortgage Investment Trust Inc. 9.500% Senior Notes due 2029	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
MITT	TPG Mortgage Investment Trust Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2011
MITT^A	TPG Mortgage Investment Trust Inc. 8.25% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MITT^B	TPG Mortgage Investment Trust Inc. 8.00% Series B Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MITT^C	TPG Mortgage Investment Trust Inc. 8.00% Series C Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock $0.01 par value per share	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MIY	Blackrock MuniYield Michigan Quality Fund Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Bankers/Brokers/Service	NYSE	1992
MKC	McCormick & Company Incorporated Common Stock	2026-06-08 16:48:03.279539+00	Consumer Staples	Packaged Foods	NYSE	\N
MKL	Markel Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Property-Casualty Insurers	NYSE	1986
MLI	Mueller Industries Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Metal Fabrications	NYSE	\N
BATRK	Atlanta Braves Holdings Inc. Series C Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
IPI	Intrepid Potash Inc Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	2008
IQI	Invesco Quality Municipal Income Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	\N
IQV	IQVIA Holdings Inc. Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	NYSE	2013
IR	Ingersoll Rand Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	2017
IRM	Iron Mountain Incorporated (Delaware)Common Stock REIT	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
IRT	Independence Realty Trust Inc. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
MLM	Martin Marietta Materials Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	1994
MLP	Maui Land & Pineapple Company Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Real Estate	NYSE	1998
MLR	Miller Industries Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Construction/Ag Equipment/Trucks	NYSE	\N
MSI	Motorola Solutions Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	Radio And Television Broadcasting And Communications Equipment	NYSE	\N
MSM	MSC Industrial Direct Company Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Industrial Machinery/Components	NYSE	1995
MTB	M&T Bank Corporation Common Stock	2026-06-08 16:48:03.293305+00	Finance	Major Banks	NYSE	\N
MTB^H	M&T Bank Corporation Perpetual Fixed-to-Floating Rate Non-Cumulative Preferred Stock Series H	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MTB^J	M&T Bank Corporation Depositary Shares each representing a 1/400th ownership interest in a share of Perpetual 7.500% Non-Cumulative Preferred Stock Series J	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MTB^K	M&T Bank Corporation Depositary Shares each representing a 1/400th interest in a share of Perpetual 6.350% Non-Cumulative Preferred Stock Series K	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MTDR	Matador Resources Company Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	2012
MTG	MGIC Investment Corporation Common Stock	2026-06-08 16:48:03.293305+00	Finance	Property-Casualty Insurers	NYSE	1991
MTH	Meritage Homes Corporation Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Homebuilding	NYSE	\N
MTN	Vail Resorts Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	1997
MTR	Mesa Royalty Trust Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	\N
MTRN	Materion Corporation	2026-06-08 16:48:03.293305+00	Industrials	Industrial Specialties	NYSE	\N
MTUS	Metallus Inc. Common Shares	2026-06-08 16:48:03.293305+00	Industrials	Steel/Iron Ore	NYSE	2014
MTW	Manitowoc Company Inc. (The) Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Construction/Ag Equipment/Trucks	NYSE	\N
MTX	Minerals Technologies Inc. Common Stock	2026-06-08 16:48:03.293305+00	Basic Materials	Major Chemicals	NYSE	1992
MTZ	MasTec Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Water Sewer Pipeline Comm & Power Line Construction	NYSE	\N
MUA	Blackrock MuniAssets Fund Inc Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Bankers/Brokers/Service	NYSE	1993
MUC	Blackrock MuniHoldings California Quality Fund Inc.  Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Bankers/Brokers/Service	NYSE	1998
MUJ	Blackrock MuniHoldings New Jersey Quality Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Bankers/Brokers/Service	NYSE	1998
MUR	Murphy Oil Corporation Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	\N
MUSA	Murphy USA Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	2013
MVO	MV Oil Trust Units of Beneficial Interests	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	2007
MWA	MUELLER WATER PRODUCTS Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Metal Fabrications	NYSE	2006
MXE	Mexico Equity and Income Fund Inc. (The) Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	\N
MXF	Mexico Fund Inc. (The) Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
MYE	Myers Industries Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Plastic Products	NYSE	1983
MYI	Blackrock MuniYield Quality Fund III Inc Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
MYN	Blackrock MuniYield New York Quality Fund Inc.Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	1992
NABL	N-able Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
NAC	Nuveen California Quality Municipal Income Fund	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	1999
NAD	Nuveen Quality Municipal Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	1999
NAN	Nuveen New York Quality Municipal Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	1999
NATL	NCR Atleos Corporation Common Stock	2026-06-08 16:48:03.293305+00	Miscellaneous	Office Equipment/Supplies/Services	NYSE	2023
NAZ	Nuveen Arizona Quality Municipal Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	1992
NBB	Nuveen Taxable Municipal Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	2010
NBHC	National Bank Holdings Corporation Common Stock	2026-06-08 16:48:03.293305+00	Finance	Major Banks	NYSE	2012
NBXG	Neuberger Next Generation Connectivity Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2021
NC	NACCO Industries Inc. Common Stock	2026-06-08 16:48:03.293305+00	Energy	Coal Mining	NYSE	\N
NCA	Nuveen California Municipal Value Fund	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	\N
NCLH	Norwegian Cruise Line Holdings Ltd. Ordinary Shares	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Marine Transportation	NYSE	\N
NCV	Virtus Convertible & Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	2003
NCV^A	Virtus Convertible & Income Fund 5.625% Series A Cumulative Preferred Shares	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NCZ	Virtus Convertible & Income Fund II Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	2003
NCZ^A	Virtus Convertible & Income Fund II 5.50% Series A Cumulative Preferred Shares	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NE	Noble Corporation plc A Ordinary Shares	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	2022
NEA	Nuveen AMT-Free Quality Municipal Income Fund Common Shares of Beneficial Interest Par Value $.01	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	2002
NEE	NextEra Energy Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	EDP Services	NYSE	\N
NEE^N	NextEra Energy Capital Holdings Inc. Series N Junior Subordinated Debentures due March 1 2079	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NEE^S	NextEra Energy Inc. 7.299% Corporate Units	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NEE^T	NextEra Energy Inc. 7.234% Corporate Units	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NEE^U	NextEra Energy Inc. Series U Junior Subordinated Debentures due June 1 2085	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NEE^V	NextEra Energy Inc. 7.375% Corporate Units	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NEE^W	NextEra Energy Capital Holdings Inc. Series Z Junior Subordinated Debentures due April 15 2086	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NEM	Newmont Corporation	2026-06-08 16:48:03.293305+00	Basic Materials	Precious Metals	NYSE	\N
NET	Cloudflare Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2019
NEU	NewMarket Corp Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Major Chemicals	NYSE	\N
NFG	National Fuel Gas Company Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Oil/Gas Transmission	NYSE	\N
NFJ	Virtus Dividend Interest & Premium Strategy Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	2005
NGL	NGL ENERGY PARTNERS LP Common Units representing Limited Partner Interests	2026-06-08 16:48:03.293305+00	Utilities	Natural Gas Distribution	NYSE	2011
NGL^B	NGL ENERGY PARTNERS LP 9.00% Class B Fixed-to-Floating Rate Cumulative Redeemable Perpetual Preferred Units representing limited partnership interests	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NGL^C	NGL ENERGY PARTNERS LP 9.625% Class C Fixed-to-Floating Rate Cumulative  Redeemable Perpetual Preferred Units representing  limited partner interests	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NGS	Natural Gas Services Group Inc. Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oilfield Services/Equipment	NYSE	2002
NGVC	Natural Grocers by Vitamin Cottage Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Staples	Food Chains	NYSE	2012
NGVT	Ingevity Corporation Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Major Chemicals	NYSE	2016
NHI	National Health Investors Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
NI	NiSource Inc Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Power Generation	NYSE	\N
NIC	Nicolet Bankshares Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Major Banks	NYSE	2022
NIE	Virtus Equity & Convertible Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2007
NIM	Nuveen Select Maturities Municipal Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1992
NIO	NIO Inc. American depositary shares each  representing one Class A ordinary share	2026-06-08 16:48:03.293305+00	Industrials	Auto Manufacturing	NYSE	2018
NIQ	NIQ Global Intelligence plc Ordinary Shares	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Programming Data Processing	NYSE	2025
NJR	NewJersey Resources Corporation Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Oil/Gas Transmission	NYSE	\N
NKE	Nike Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Shoe Manufacturing	NYSE	\N
NKX	Nuveen California AMT-Free Quality Municipal Income Fund	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	2002
NL	NLI Holdings Inc. Common Stock	2026-06-08 16:48:03.293305+00	Basic Materials	Major Chemicals	NYSE	\N
NLOP	Net Lease Office Properties Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2023
NLY	Annaly Capital Management Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
NLY^F	Annaly Capital Management Inc 6.95% Series F	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NLY^G	Annaly Capital Management Inc 6.50% Series G Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NLY^I	Annaly Capital Management Inc 6.750% Series I Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NLY^J	Annaly Capital Management Inc. 8.875% Series J Fixed-Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NMAI	Nuveen Multi-Asset Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2021
NMAX	Newsmax Inc. Class B Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Broadcasting	NYSE	2025
NMI	Nuveen Municipal Income Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1988
NMS	Nuveen Minnesota Quality Municipal Income Fund	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	2014
NMT	Nuveen Massachusetts Quality Municipal Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	\N
NMZ	Nuveen Municipal High Income Opportunity Fund Common Stock $0.01 par value per share	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	2003
NNI	Nelnet Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	2003
NNN	NNN REIT Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
NNY	Nuveen New York Municipal Value Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	1988
NOC	Northrop Grumman Corporation Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Industrial Machinery/Components	NYSE	\N
NOG	Northern Oil and Gas Inc. Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	2022
NOV	NOV Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	\N
NOW	ServiceNow Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2012
NPB	Northpointe Bancshares Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Major Banks	NYSE	2025
NPCT	Nuveen Core Plus Impact Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2021
NPFD	Nuveen Variable Rate Preferred & Income Fund Common Shares	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2021
NPK	National Presto Industries Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Ordnance And Accessories	NYSE	\N
NPKI	NPK International Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	\N
NPO	Enpro Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Metal Fabrications	NYSE	\N
NPV	Nuveen Virginia Quality Municipal Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	1993
NPWR	NET Power Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Energy	Industrial Machinery/Components	NYSE	2021
NRDY	Nerdy Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Other Consumer Services	NYSE	2020
NREF	NexPoint Real Estate Finance Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2020
NREF^A	NexPoint Real Estate Finance Inc. 8.50% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NRG	NRG Energy Inc. Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Electric Utilities: Central	NYSE	\N
NRGV	Energy Vault Holdings Inc. Common Stock	2026-06-08 16:48:03.293305+00	Miscellaneous	Industrial Machinery/Components	NYSE	2021
NRK	Nuveen New York AMT-Free Quality Municipal Income Fund	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2002
NRP	Natural Resource Partners LP Limited Partnership	2026-06-08 16:48:03.293305+00	Energy	Coal Mining	NYSE	2002
NRT	North European Oil Royality Trust Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	\N
NRUC	National Rural Utilities Cooperative Finance Corporation 5.500% Subordinated Notes due 2064 (Subordinated Deferrable Interest Notes)	2026-06-08 16:48:03.293305+00	Finance	Diversified Financial Services	NYSE	2019
NSA	National Storage Affiliates Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
NSA^A	National Storage Affiliates Trust 6.000% Series A Cumulative Redeemable Preferred Shares of Beneficial Interest (Liquidation Preference $25.00 per share)	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NSA^B	National Storage Affiliates Trust 6.000% Series B Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NSC	Norfolk Southern Corporation Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Railroads	NYSE	\N
NTST	NetSTREIT Corp. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2020
NUS	Nu Skin Enterprises Inc. Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Other Pharmaceuticals	NYSE	1996
NUV	Nuveen Municipal Value Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1987
NUVB	Nuvation Bio Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2020
NUW	Nuveen AMT-Free Municipal Value Fund	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2009
NVG	Nuveen AMT-Free Municipal Credit Income Fund	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2002
NVR	NVR Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Homebuilding	NYSE	1998
NVST	Envista Holdings Corporation Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Medical/Dental Instruments	NYSE	2019
NWN	Northwest Natural Holding Company Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Oil/Gas Transmission	NYSE	\N
NX	Quanex Building Products Corporation Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Metal Fabrications	NYSE	\N
NXDR	Nextdoor Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Programming Data Processing	NYSE	\N
NXDT	NexPoint Diversified Real Estate Trust Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
NXDT^A	NexPoint Diversified Real Estate Trust 5.50% Series A Cumulative Preferred Shares ($25.00 liquidation preference per share)	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
NXP	Nuveen Select Tax Free Income Portfolio Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1992
NXRT	NexPoint Residential Trust Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
NYT	New York Times Company (The) Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Newspapers/Magazines	NYSE	\N
NZF	Nuveen Municipal Credit Income Fund	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	2007
O	Realty Income Corporation Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
OAK^A	Brookfield Oaktree Holdings LLC 6.625% Series A Preferred Units	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
OAK^B	Brookfield Oaktree Holdings LLC 6.550% Series B Preferred Units	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
OBDC	Blue Owl Capital Corporation Common Stock	2026-06-08 16:48:03.293305+00	Finance	Diversified Financial Services	NYSE	2019
OBK	Origin Bancorp Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Major Banks	NYSE	\N
OC	Owens Corning Inc Common Stock New	2026-06-08 16:48:03.293305+00	Industrials	Industrial Machinery/Components	NYSE	\N
ODC	Oil-Dri Corporation Of America Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Miscellaneous manufacturing industries	NYSE	\N
OGE	OGE Energy Corp Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Electric Utilities: Central	NYSE	\N
OGN	Organon & Co. Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2021
OGS	ONE Gas Inc. Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Oil/Gas Transmission	NYSE	2014
OHI	Omega Healthcare Investors Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	1992
OI	O-I Glass Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Containers/Packaging	NYSE	\N
OIA	Invesco Municipal Income Opportunities Trust Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	\N
OII	Oceaneering International Inc. Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oilfield Services/Equipment	NYSE	\N
OIS	Oil States International Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	2001
OKE	ONEOK Inc. Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Oil & Gas Production	NYSE	\N
OKLO	Oklo Inc. Class A common stock	2026-06-08 16:48:03.293305+00	Utilities	Electric Utilities: Central	NYSE	2021
OLN	Olin Corporation Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Major Chemicals	NYSE	\N
OLP	One Liberty Properties Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	1986
OMC	Omnicom Group Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Advertising	NYSE	\N
OMF	OneMain Holdings Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	2013
ONIT	Onity Group Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	\N
ONL	Orion Properties Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2021
ONT	Onterris Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Professional Services	NYSE	2020
ONTO	Onto Innovation Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Industrial Machinery/Components	NYSE	\N
OOMA	Ooma Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	EDP Services	NYSE	2015
OPAD	Offerpad Solutions Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Finance	Real Estate	NYSE	2020
OPFI	OppFi Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	2020
OPLN	OPENLANE Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	\N
OPP	RiverNorth/DoubleLine Strategic Opportunity Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	2016
OPP^A	RiverNorth/DoubleLine Strategic Opportunity Fund Inc. 4.375% Series A Cumulative Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
OPP^B	RiverNorth/DoubleLine Strategic Opportunity Fund Inc. 4.75% Series B Cumulative Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
OPTU	Optimum Communications Inc. Class A common stock	2026-06-08 16:48:03.293305+00	Telecommunications	Cable & Other Pay Television Services	NYSE	2017
OPY	Oppenheimer Holdings Inc. Class A Common Stock (DE)	2026-06-08 16:48:03.293305+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
ORA	Ormat Technologies Inc. Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Electric Utilities: Central	NYSE	2004
ORC	Orchid Island Capital Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
ORCL	Oracle Corporation Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	1986
ORCL^D	Oracle Corporation Depositary Shares each representing a 1/2000th interest in a sh of 6.50% Series D Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
ORI	Old Republic International Corporation Common Stock	2026-06-08 16:48:03.293305+00	Finance	Property-Casualty Insurers	NYSE	\N
ORN	Orion Group Holdings Inc. Common	2026-06-08 16:48:03.293305+00	Industrials	Military/Government/Technical	NYSE	\N
OSCR	Oscar Health Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Medical Specialities	NYSE	2021
OSG	Octave Specialty Group Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Property-Casualty Insurers	NYSE	\N
PCOR	Procore Technologies Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
PD	PagerDuty Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2019
PDI	PIMCO Dynamic Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2012
PDM	Piedmont Realty Trust Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Building operators	NYSE	\N
PDO	PIMCO Dynamic Income Opportunities Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2021
PDT	John Hancock Premium Dividend Fund	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	\N
PEB	Pebblebrook Hotel Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2009
PEB^E	Pebblebrook Hotel Trust 6.375% Series E Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
PEB^F	Pebblebrook Hotel Trust 6.3% Series F Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
PEB^G	Pebblebrook Hotel Trust 6.375% Series G Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
PEB^H	Pebblebrook Hotel Trust 5.700% Series H Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
PEG	Public Service Enterprise Group Incorporated Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Power Generation	NYSE	\N
PEN	Penumbra Inc. Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Medical/Dental Instruments	NYSE	2015
PEO	Adams Natural Resources Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	\N
PFD	Flaherty & Crumrine Preferred and Income Fund Incorporated	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	1991
PFE	Pfizer Inc. Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
PFGC	Performance Food Group Company Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Food Distributors	NYSE	2015
PFH	Prudential Financial Inc. 4.125% Junior Subordinated Notes due 2060	2026-06-08 16:48:03.293305+00	Finance	Life Insurance	NYSE	2020
PFL	PIMCO Income Strategy Fund Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	2003
PFLT	PennantPark Floating Rate Capital Ltd. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	2022
PFN	PIMCO Income Strategy Fund II	2026-06-08 16:48:03.293305+00	Finance	Finance/Investors Services	NYSE	2004
PFO	Flaherty & Crumrine Preferred and Income Opportunity Fund Incorporated	2026-06-08 16:48:03.293305+00	Finance	Finance Companies	NYSE	1992
PFS	Provident Financial Services Inc Common Stock	2026-06-08 16:48:03.293305+00	Finance	Savings Institutions	NYSE	2003
PFSI	PennyMac Financial Services Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Finance: Consumer Services	NYSE	2013
PG	Procter & Gamble Company (The) Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	\N
PMT^C	PennyMac Mortgage Investment Trust 6.75% Series C Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PMTU	PennyMac Mortgage Investment Trust 8.50% Senior Notes due 2028	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2023
PMTV	PennyMac Mortgage Investment Trust 9.00% Senior Notes due 2030	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
PMTW	PennyMac Mortgage Investment Trust 9.00% Senior Notes due 2030	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
PNC	PNC Financial Services Group Inc. (The) Common Stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	\N
PNFP	Pinnacle Financial Partners Inc. Common stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	\N
PNFP^A	Pinnacle Financial Partners Inc. Fixed-to-Floating Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PNFP^B	Pinnacle Financial Partners Inc. Fixed-to-Floating Rate Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PNFP^C	Pinnacle Financial Partners Inc. Fixed-to-Floating Rate Non-Cumulative Perpetual Preferred Stock Series C	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PNI	Pimco New York Municipal Income Fund II Common Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2002
PNNT	PennantPark Investment Corporation Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance: Consumer Services	NYSE	2022
PNW	Pinnacle West Capital Corporation Common Stock	2026-06-08 16:48:03.309287+00	Utilities	Electric Utilities: Central	NYSE	\N
POR	Portland General Electric Co Common Stock	2026-06-08 16:48:03.309287+00	Utilities	Electric Utilities: Central	NYSE	\N
POST	Post Holdings Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Staples	Packaged Foods	NYSE	2012
BAYA	Bayview Acquisition Corp Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2023
BAYAR	Bayview Acquisition Corp Right	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2023
BAYAU	Bayview Acquisition Corp Unit	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2023
BBCP	Concrete Pumping Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Engineering & Construction	Nasdaq	2017
BBCQ	Bleichroeder Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BBCQU	Bleichroeder Acquisition Corp. II Units	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BBCQW	Bleichroeder Acquisition Corp. II Warrants	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BBGI	Beasley Broadcast Group Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Broadcasting	Nasdaq	2000
BBIO	BridgeBio Pharma Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2019
BBLG	Bone Biologics Corp Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Industrial Specialties	Nasdaq	\N
MS^K	Morgan Stanley Depositary Shares each representing 1/1000th of a share of Fixed-to-Floating Rate Non-Cumulative Preferred Stock  Series K	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MS^L	Morgan Stanley Depositary Shares each representing 1/1000th of a share of 4.875% Non-Cumulative Preferred Stock Series L	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MS^O	Morgan Stanley Depositary Shares each representing 1/1000th of a share of 4.250% Non-Cumulative Preferred Stock Series O	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MS^P	Morgan Stanley Depositary Shares each representing 1/1000th of a share of 6.500% Non-Cumulative Preferred Stock Series P	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MS^Q	Morgan Stanley Depositary Shares each representing 1/1000th of a share of 6.625% Non-Cumulative Preferred Stock Series Q	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
MSA	MSA Safety Incorporated Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Industrial Specialties	NYSE	2000
MSB	Mesabi Trust Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Precious Metals	NYSE	\N
NCDL	Nuveen Churchill Direct Lending Corp. Common Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	2024
PPG	PPG Industries Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Paints/Coatings	NYSE	\N
PPL	PPL Corporation Common Stock	2026-06-08 16:48:03.309287+00	Utilities	Electric Utilities: Central	NYSE	\N
PPLC	PPL Corporation Corporate Units	2026-06-08 16:48:03.309287+00	Utilities	Electric Utilities: Central	NYSE	\N
PPT	Putnam Premier Income Trust Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance Companies	NYSE	1988
PR	Permian Resources Corporation Class A Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	2022
PRA	ProAssurance Corporation Common Stock	2026-06-08 16:48:03.309287+00	Finance	Property-Casualty Insurers	NYSE	\N
PRG	PROG Holdings Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Diversified Commercial Services	NYSE	\N
PRGO	Perrigo Company plc Ordinary Shares	2026-06-08 16:48:03.309287+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
PRH	Prudential Financial Inc. 5.950% Junior Subordinated Notes due 2062	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	2022
PRI	Primerica Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	2010
PRIM	Primoris Services Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Water Sewer Pipeline Comm & Power Line Construction	NYSE	\N
PRKS	United Parks & Resorts Inc. Common Stock	2026-06-08 16:48:03.309287+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	NYSE	2013
PRLB	Proto Labs Inc. Common stock	2026-06-08 16:48:03.309287+00	Industrials	Metal Fabrications	NYSE	2012
PRMB	Primo Brands Corporation Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Staples	Beverages (Production/Distribution)	NYSE	2024
PRS	Prudential Financial Inc. 5.625% Junior Subordinated Notes due 2058	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	2018
PRSU	Pursuit Attractions and Hospitality Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Business Services	NYSE	\N
PRT	PermRock Royalty Trust Units of Beneficial Interest	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	2018
PRU	Prudential Financial Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	2001
PSA	Public Storage Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
PSA^F	Public Storage Depositary Shares Each Representing 1/1000 of a 5.15% Cumulative Preferred Share of Beneficial Interest Series F par value $0.01 per share	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^G	Public Storage Depositary Shares Each Representing 1/1000 of a 5.05% Cumulative Preferred Share of Beneficial Interest Series G	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^H	Public Storage Depositary Shares Each Representing 1/1000 of a  5.60% Cumulative Preferred  Share of Beneficial Interest Series H	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
ROG	Rogers Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Major Chemicals	NYSE	1960
BBLGW	Bone Biologics Corp Warrants	2026-06-08 16:48:03.035838+00	Health Care	Industrial Specialties	Nasdaq	\N
PSA^I	Public Storage Depositary Shares Each Representing 1/1000 of a 4.875% Cumulative Preferred Share of Beneficial Interest Series I par value $0.01 per share	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^J	Public Storage Depositary Shares Each Representing 1/1000 of a 4.700% Cumulative Preferred Share of Beneficial Interest Series J par value $0.01 per share	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^K	Public Storage Depositary Shares Each Representing 1/1000 of a 4.75% Cumulative Preferred Share of Beneficial Interest Series K	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^L	Public Storage Depositary Shares Each Representing 1/1000 of a 4.625% Cumulative Preferred Share of Beneficial Interest Series L par value $0.01 per share	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^M	Public Storage Depositary Shares Each Representing 1/1000 of a 4.125% Cumulative Preferred Share of Beneficial Interest Series M	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^N	Public Storage Depositary Shares Each Representing 1/1000 of a 3.875% Cumulative Preferred Share of Beneficial Interest Series N	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^O	Public Storage Depositary Shares Each Representing 1/1000 of a 3.900% Cumulative Preferred Share of Beneficial Interest Series O	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^P	Public Storage Depositary Shares Each Representing 1/1000 of a 4.000% Cumulative Preferred Share of Bene cial Interest Series P	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^Q	Public Storage Depositary Shares Each Representing 1/1000 of a 3.950% Cumulative Preferred Share of Beneficial Interest Series Q par value $0.01 per share	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^R	Public Storage Depositary Shares Each Representing 1/1000 of a 4.00% Cumulative Preferred Share of Bene cial Interest Series R	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSA^S	Public Storage Depositary Shares Each Representing 1/1000 of a 4.100% Cumulative Preferred Share of Beneficial Interest Series S	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSEC^A	Prospect Capital Corporation 5.35% Series A Fixed Rate Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PSN	Parsons Corporation Common Stock	2026-06-08 16:48:03.309287+00	Technology	EDP Services	NYSE	2019
PSTL	Postal Realty Trust Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2019
PSX	Phillips 66 Common Stock	2026-06-08 16:48:03.309287+00	Energy	Integrated oil Companies	NYSE	\N
PTA	Cohen & Steers Tax-Advantaged Preferred Securities and Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2020
PTY	Pimco Corporate & Income Opportunity Fund	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2002
PUMP	ProPetro Holding Corp. Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oilfield Services/Equipment	NYSE	2017
PVH	PVH Corp. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Garments and Clothing	NYSE	\N
PVL	Permianville Royalty Trust Units of Beneficial Interest	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	2011
PWR	Quanta Services Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Engineering & Construction	NYSE	\N
PYT	PPlus Tr GSC-2 Tr Ctf Fltg Rate	2026-06-08 16:48:03.309287+00	Finance	Finance: Consumer Services	NYSE	\N
Q	Qnity Electronics Inc. Common Stock	2026-06-08 16:48:03.309287+00	Technology	Semiconductors	NYSE	2025
QBTS	D-Wave Quantum Inc. Common Shares	2026-06-08 16:48:03.309287+00	Technology	EDP Services	NYSE	2022
QTWO	Q2 Holdings Inc. Common Stock	2026-06-08 16:48:03.309287+00	Technology	Computer Software: Prepackaged Software	NYSE	2014
QUAD	Quad Graphics Inc Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Publishing	NYSE	\N
QXO	QXO Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	\N
QXO^B	QXO Inc.  Depositary Shares each representing a 1/20th interest in a share of 5.50% Series B Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RA	Brookfield Real Assets Income Fund Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2016
RAL	Ralliant Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Industrial Machinery/Components	NYSE	2025
RAMP	LiveRamp Holdings Inc. Common Stock	2026-06-08 16:48:03.309287+00	Technology	EDP Services	NYSE	2018
RBC	RBC Bearings Incorporated Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Metal Fabrications	NYSE	2022
RBLX	Roblox Corporation Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
RBRK	Rubrik Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	Computer Software: Prepackaged Software	NYSE	2024
RC	Ready Capital Corporation Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
RC^C	Ready Capital Corporation 6.25% Series C Cumulative Convertible Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RC^E	Ready Capital Corporation 6.50% Series E Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RCD	Ready Capital Corporation 9.00% Senior Notes due 2029	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
RCL	Royal Caribbean Cruises Ltd. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Marine Transportation	NYSE	1993
RCS	PIMCO Strategic Income Fund Inc.	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	1994
RCUS	Arcus Biosciences Inc. Common Stock	2026-06-08 16:48:03.309287+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2018
RDDT	Reddit Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	EDP Services	NYSE	2024
RDN	Radian Group Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Property-Casualty Insurers	NYSE	\N
RDW	Redwire Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Military/Government/Technical	NYSE	2021
RES	RPC Inc. Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oilfield Services/Equipment	NYSE	\N
REX	REX American Resources Corporation	2026-06-08 16:48:03.309287+00	Industrials	Major Chemicals	NYSE	\N
REXR	Rexford Industrial Realty Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2013
REXR^B	Rexford Industrial Realty Inc. 5.875% Series B Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
REXR^C	Rexford Industrial Realty Inc. 5.625% Series C Cumulative Redeemable Preferred Stock par value $0.01 per share	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
REZI	Resideo Technologies Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Wholesale Distributors	NYSE	2018
RF	Regions Financial Corporation Common Stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	\N
RF^C	Regions Financial Corporation Depositary Shares each Representing a 1/40th Interest in a  Share of 5.700% Fixed-to-Floating Rate Non-Cumulative  Perpetual Preferred Stock Series C	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
NUE	Nucor Corporation Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Steel/Iron Ore	NYSE	\N
RF^E	Regions Financial Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of 4.45% Non-Cumulative Perpetual Preferred Stock Series E	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RF^F	Regions Financial Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of Non-Cumulative Perpetual Preferred Stock Series F	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RFI	Cohen & Steers Total Return Realty Fund Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	1993
RFL	Rafael Holdings Inc. Class B Common Stock	2026-06-08 16:48:03.309287+00	Finance	Real Estate	NYSE	2018
RGA	Reinsurance Group of America Incorporated Common Stock	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	\N
RGR	Sturm Ruger & Company Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Ordnance And Accessories	NYSE	\N
RH	RH Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Other Specialty Stores	NYSE	2012
RHI	Robert Half Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Professional Services	NYSE	\N
RHLD	Resolute Holdings Management Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance: Consumer Services	NYSE	\N
RHP	Ryman Hospitality Properties Inc. (REIT)	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
RITM	Rithm Capital Corp. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
RITM^A	Rithm Capital Corp. 7.50% Series A Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RITM^B	Rithm Capital Corp. 7.125% Series B Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RITM^C	Rithm Capital Corp. 6.375% Series C Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RITM^D	Rithm Capital Corp. 7.00% Fixed-Rate Reset Series D Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RITM^E	Rithm Capital Corp. 8.75% Series E Fixed-Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RITM^F	Rithm Capital Corp. 8.750% Series F Fixed-Rate Reset Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RIV	RiverNorth Opportunities Fund Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance Companies	NYSE	2015
RIV^A	RiverNorth Opportunities Fund Inc. 6.00% Series A Perpetual Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RJF	Raymond James Financial Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
RKT	Rocket Companies Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance: Consumer Services	NYSE	2020
RL	Ralph Lauren Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Garments and Clothing	NYSE	1997
RLI	RLI Corp. Common Stock (DE)	2026-06-08 16:48:03.309287+00	Finance	Property-Casualty Insurers	NYSE	\N
RLJ	RLJ Lodging Trust Common Shares of Beneficial Interest $0.01 par value	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2011
RLJ^A	RLJ Lodging Trust $1.95 Series A Cumulative Convertible  Preferred Shares	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RM	Regional Management Corp. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance: Consumer Services	NYSE	2012
RMAX	RE/MAX Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Finance	Real Estate	NYSE	2013
RMD	ResMed Inc. Common Stock	2026-06-08 16:48:03.309287+00	Health Care	Medical/Dental Instruments	NYSE	\N
RMT	Royce Micro-Cap Trust Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	\N
RNG	RingCentral Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	EDP Services	NYSE	2013
RNGR	Ranger Energy Services Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oilfield Services/Equipment	NYSE	2017
RNP	Cohen & Steers REIT and Preferred and Income Fund Inc. Common Shares	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2003
RWTS	Redwood Trust Inc. 9.75% Senior Notes Due 2031	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2026
RYAM	Rayonier Advanced Materials Inc. Common Stock	2026-06-08 16:48:03.309287+00	Basic Materials	Paper	NYSE	2014
RYAN	Ryan Specialty Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Finance	Specialty Insurers	NYSE	2021
RYN	Rayonier Inc. REIT Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
RYZ	Ryerson Holding Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Metal Fabrications	NYSE	2014
RZB	Reinsurance Group of America Incorporated 5.75% Fixed-To-Floating Rate Subordinated Debentures due 2056	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	2016
RZC	Reinsurance Group of America Incorporated 7.125% Fixed-Rate Reset Subordinated Debentures due 2052	2026-06-08 16:48:03.309287+00	Finance	Life Insurance	NYSE	2022
S	SentinelOne Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
SABA	Saba Capital Income & Opportunities Fund II Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SAFE	Safehold Inc. New Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2023
SAH	Sonic Automotive Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	1997
SAJ	Saratoga Investment Corp 8.00% Notes due 2027	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2022
SAM	Boston Beer Company Inc. (The) Common Stock	2026-06-08 16:48:03.309287+00	Consumer Staples	Beverages (Production/Distribution)	NYSE	\N
SAR	Saratoga Investment Corp New	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	\N
SARO	StandardAero Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Aerospace	NYSE	2024
SAT	Saratoga Investment Corp 6.00% Notes due 2027	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2022
SAV	Saratoga Investment Corp 7.50% Notes due 2031	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2026
SAY	Saratoga Investment Corp 8.125% Notes due 2027	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2022
SAZ	Saratoga Investment Corp 8.50% Notes due 2028	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2023
SBH	Sally Beauty Holdings Inc. (Name to be changed from Sally Holdings Inc.) Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Other Specialty Stores	NYSE	\N
SBI	Western Asset Intermediate Muni Fund Inc Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance/Investors Services	NYSE	1992
SBR	Sabine Royalty Trust Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	\N
SBSI	Southside Bancshares Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	\N
SCCO	Southern Copper Corporation Common Stock	2026-06-08 16:48:03.309287+00	Basic Materials	Metal Mining	NYSE	\N
SCD	LMP Capital and Income Fund Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2004
SCE^G	SCE Trust II Trust Preferred Securities	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
OTF	Blue Owl Technology Finance Corp. Common Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	2025
SCE^M	SCE Trust VII 7.50% Trust Preference Securities	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SCE^N	SCE Trust VIII 6.95% Trust Preference Securities	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SCHW	Charles Schwab Corporation (The) Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
SCHW^D	The Charles Schwab Corporation Depositary Shares each representing 1/40th interest in a share of 5.95% Non-Cumulative Perpetual Preferred Stock Series D	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SCHW^J	The Charles Schwab Corporation Depositary Shares Each Representing a 1/40th Interest in a Share of 4.450% Non-Cumulative Perpetual Preferred Stock Series J	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SCI	Service Corporation International Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Other Consumer Services	NYSE	\N
SCL	Stepan Company Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Package Goods/Cosmetics	NYSE	\N
SCM	Stellus Capital Investment Corporation Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance/Investors Services	NYSE	2012
SD	SandRidge Energy Inc. Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	2016
SDHC	Smith Douglas Homes Corp. Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Homebuilding	NYSE	2024
SE	Sea Limited American Depositary Shares each representing one Class A Ordinary Share	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Other Consumer Services	NYSE	2017
SEG	Seaport Entertainment Group Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2024
SEI	Solaris Energy Infrastructure Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	2017
SEM	Select Medical Holdings Corporation Common Stock	2026-06-08 16:48:03.309287+00	Health Care	Hospital/Nursing Management	NYSE	2009
SES	SES AI Corporation Class A Common Stock	2026-06-08 16:48:03.309287+00	Miscellaneous	Industrial Machinery/Components	NYSE	2021
SF	Stifel Financial Corporation Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
SF^B	Stifel Financial Corporation Depositary Shares Each Representing 1/1000th  Interest in a Share of 6.25% Non-Cumulative  Preferred Stock Series B	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SF^C	Stifel Financial Corporation Depositary Shares Each Representing 1/1000th Interest in a Share of 6.125% Non Cumulative Preferred Stock Series C	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SF^D	Stifel Financial Corporation Depositary Shares Each Representing 1/1000th Interest in a Share of 4.50% Non-Cumulative Preferred Stock Series D	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SFB	Stifel Financial Corporation 5.20% Senior Notes due 2047	2026-06-08 16:48:03.309287+00	Finance	Investment Bankers/Brokers/Service	NYSE	2017
SFBS	ServisFirst Bancshares Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	\N
SG	Sweetgreen Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Restaurants	NYSE	2021
SGI	Somnigroup International Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Home Furnishings	NYSE	\N
SGU	Star Group L.P. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Other Specialty Stores	NYSE	\N
SHAK	Shake Shack Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Restaurants	NYSE	2015
SHO	Sunstone Hotel Investors Inc. Sunstone Hotel Investors Inc. Common Shares	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Hotels/Resorts	NYSE	2004
SHO^H	Sunstone Hotel Investors Inc. 6.125% Series H Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SHO^I	Sunstone Hotel Investors Inc. 5.70% Series I Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SHW	Sherwin-Williams Company (The) Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	RETAIL: Building Materials	NYSE	\N
SI	Shoulder Innovations Inc. Common Stock	2026-06-08 16:48:03.309287+00	Health Care	Medical/Dental Instruments	NYSE	2025
SILA	Sila Realty Trust Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
SITC	SITE Centers Corp. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
SITE	SiteOne Landscape Supply Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Professional and commerical equipment	NYSE	2016
SJM	The J.M. Smucker Company Common Stock	2026-06-08 16:48:03.309287+00	Consumer Staples	Packaged Foods	NYSE	\N
SJT	San Juan Basin Royalty Trust Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	\N
SKIL	Skillsoft Corp. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	Computer Software: Prepackaged Software	NYSE	2019
SKLZ	Skillz Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	EDP Services	NYSE	2020
SKT	Tanger Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	1993
SKY	Champion Homes Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Homebuilding	NYSE	\N
SKYH	Sky Harbour Group Corporation Class A Common Stock	2026-06-08 16:48:03.309287+00	Finance	Real Estate	NYSE	2022
SLG	SL Green Realty Corp Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	1997
SLGN	Silgan Holdings Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Containers/Packaging	NYSE	2022
SLQT	SelectQuote Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Specialty Insurers	NYSE	2020
SLVM	Sylvamo Corporation Common Stock	2026-06-08 16:48:03.309287+00	Basic Materials	Paper	NYSE	2021
SM	SM Energy Company Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	\N
SMA	SmartStop Self Storage REIT Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
SMBK	SmartFinancial Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	\N
SMC	Summit Midstream Corporation Common Stock	2026-06-08 16:48:03.309287+00	Utilities	Natural Gas Distribution	NYSE	2012
SMG	Scotts Miracle-Gro Company (The) Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Agricultural Chemicals	NYSE	1992
SMHI	SEACOR Marine Holdings Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Marine Transportation	NYSE	2017
SMP	Standard Motor Products Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
SMR	NuScale Power Corporation Class A Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Metal Fabrications	NYSE	2022
SPGI	S&P Global Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance: Consumer Services	NYSE	\N
SPH	Suburban Propane Partners L.P. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Other Specialty Stores	NYSE	1996
SPHR	Sphere Entertainment Co. Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2020
SPIR	Spire Global Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Telecommunications Equipment	NYSE	2020
BBNX	Beta Bionics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2025
BBOT	BridgeBio Oncology Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
BBSI	Barrett Business Services Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Professional Services	Nasdaq	1993
BCAB	BioAtla Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
BCAL	California BanCorp Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BCAR	D. Boral ARC Acquisition I Corp. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BCARU	D. Boral ARC Acquisition I Corp. Units	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BCARW	D. Boral ARC Acquisition I Corp. Warrant	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BCAX	Bicara Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
BCBP	BCB Bancorp Inc. (NJ) Common Stock	2026-06-08 16:48:03.035838+00	Finance	Savings Institutions	Nasdaq	2005
BCDA	BioCardia Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
BCG	Binah Capital Group Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
BCGWW	Binah Capital Group Inc. Warrants	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
BCIC	BCP Investment Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	2006
BCML	BayCom Corp Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	2018
BCPC	Balchem Corporation Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Major Chemicals	Nasdaq	\N
BCRX	BioCryst Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	1994
BDCI	BTC Development Corp. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
BDSX	Biodesix Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical Specialities	Nasdaq	2020
BDTX	Black Diamond Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
PGP	Pimco Global StocksPlus & Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	Finance	Finance Companies	NYSE	2005
PGR	Progressive Corporation (The) Common Stock	2026-06-08 16:48:03.309287+00	Finance	Property-Casualty Insurers	NYSE	\N
PH	Parker-Hannifin Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Metal Fabrications	NYSE	\N
PHIN	PHINIA Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	2023
PHK	Pimco High Income Fund	2026-06-08 16:48:03.309287+00	Finance	Finance/Investors Services	NYSE	2003
SPRU	Spruce Power Holding Corporation Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	2019
SPXC	SPX Technologies Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Industrial Machinery/Components	NYSE	\N
SPXX	Nuveen S&P 500 Dynamic Overwrite Fund	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
SR	Spire Inc. Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Oil/Gas Transmission	NYSE	\N
SRE	DBA Sempra Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Natural Gas Distribution	NYSE	\N
SREA	DBA Sempra 5.750% Junior Subordinated Notes due 2079	2026-06-08 16:48:03.323955+00	Utilities	Natural Gas Distribution	NYSE	2019
SRFM	Surf Air Mobility Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Transportation Services	NYSE	2023
SRG	Seritage Growth Properties Class A Common Stock	2026-06-08 16:48:03.323955+00	Finance	Real Estate	NYSE	2015
SRG^A	Seritage Growth Properties 7.00% Series A Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
SRI	Stoneridge Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	1997
SSTK	Shutterstock Inc. Common Stock	2026-06-08 16:48:03.323955+00	Technology	EDP Services	NYSE	2012
STAG	Stag Industrial Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	2011
STC	Stewart Information Services Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Specialty Insurers	NYSE	\N
STE	STERIS plc (Ireland) Ordinary Shares	2026-06-08 16:48:03.323955+00	Health Care	Industrial Specialties	NYSE	\N
STEL	Stellar Bancorp Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	\N
STEM	Stem Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Miscellaneous	Industrial Machinery/Components	NYSE	2020
STEW	SRH Total Return Fund Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Investment Managers	NYSE	\N
STK	Columbia Seligman Premium Technology Growth Fund Inc	2026-06-08 16:48:03.323955+00	Finance	Investment Managers	NYSE	2009
STT	State Street Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	\N
STT^G	State Street Corporation Depositary shares each representing a 1/4000th ownership interest in a share of Fixed-to-Floating Rate Non-Cumulative	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
STUB	StubHub Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2025
STWD	STARWOOD PROPERTY TRUST INC. Starwood Property Trust Inc.	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	2009
STZ	Constellation Brands Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Staples	Beverages (Production/Distribution)	NYSE	\N
SUI	Sun Communities Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	1993
SUN	Sunoco LP Common Units representing limited partner interests	2026-06-08 16:48:03.323955+00	Energy	Integrated oil Companies	NYSE	2012
SVV	Savers Value Village Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Other Specialty Stores	NYSE	2023
SWK	Stanley Black & Decker Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Industrial Machinery/Components	NYSE	\N
SWX	Southwest Gas Holdings Inc. Common Stock (DE)	2026-06-08 16:48:03.323955+00	Utilities	Oil & Gas Production	NYSE	\N
SWZ	Total Return Securities Fund Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	\N
SXC	SunCoke Energy Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Steel/Iron Ore	NYSE	2011
SXI	Standex International Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Industrial Machinery/Components	NYSE	\N
SXT	Sensient Technologies Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Major Chemicals	NYSE	\N
SYF	Synchrony Financial Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance: Consumer Services	NYSE	2014
SYF^A	Synchrony Financial Depositary Shares each Representing a 1/40th Interest in a Share of 5.625% Fixed Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
SYF^B	Synchrony Financial Depositary Shares Each Representing a 1/40th Interest in a Share of 8.250% Fixed Rate Reset Non-Cumulative Perpetual Preferred Stock Series B	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
SYK	Stryker Corporation Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Medical/Dental Instruments	NYSE	\N
SYY	Sysco Corporation Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Food Distributors	NYSE	\N
T	AT&T Inc.	2026-06-08 16:48:03.323955+00	Telecommunications	Telecommunications Equipment	NYSE	\N
T^A	AT&T Inc. Depositary Shares each representing a 1/1000th interest in a share of 5.000% Perpetual Preferred Stock Series A	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
T^C	AT&T Inc. Depositary Shares each representing a 1/1000th interest in a share of 4.750% Perpetual Preferred Stock Series C	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TALO	Talos Energy Inc. Common Stock	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	2018
TBB	AT&T Inc. 5.350% Global Notes due 2066	2026-06-08 16:48:03.323955+00	Telecommunications	Telecommunications Equipment	NYSE	2017
TBI	TrueBlue Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Professional Services	NYSE	\N
TCBX	Third Coast Bancshares Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Banks	NYSE	\N
TCI	Transcontinental Realty Investors Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
TDAY	USA TODAY Co. Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Newspapers/Magazines	NYSE	2014
TDC	Teradata Corporation Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	\N
TDF	Templeton Dragon Fund Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance/Investors Services	NYSE	\N
TDG	Transdigm Group Incorporated Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Military/Government/Technical	NYSE	2006
TDOC	Teladoc Health Inc. Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Medical/Nursing Services	NYSE	2015
TDS	Telephone and Data Systems Inc. Common Shares	2026-06-08 16:48:03.323955+00	Telecommunications	Telecommunications Equipment	NYSE	\N
TDS^U	Telephone and Data Systems Inc. Depositary Shares Each Representing a 1/1000th Interest in a 6.625% Series UU Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TDS^V	Telephone and Data Systems Inc. Depositary Shares Each Representing a 1/1000th Interest in a 6.000% Series VV Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TDW	Tidewater Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Marine Transportation	NYSE	2017
TDY	Teledyne Technologies Incorporated Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Industrial Machinery/Components	NYSE	\N
TEI	Templeton Emerging Markets Income Fund Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	1993
TEX	Terex Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Construction/Ag Equipment/Trucks	NYSE	\N
TFC	Truist Financial Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	\N
TFC^I	Truist Financial Corporation Depositary Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TFC^O	Truist Financial Corporation Depositary Shares Each Representing a 1/1000th Interest in a Share of Series O Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TFC^R	Truist Financial Corporation Depositary Shares each representing 1/1000th interest in a share of Series R Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TFIN	Triumph Financial Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	\N
TFIN^	Triumph Financial Inc. Depositary Shares Each Representing a 1/40th Interest in a Share of 7.125% Series C Fixed-Rate Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TFX	Teleflex Incorporated Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Medical/Dental Instruments	NYSE	\N
TG	Tredegar Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Metal Fabrications	NYSE	\N
TGT	Target Corporation Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	\N
THC	Tenet Healthcare Corporation Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Hospital/Nursing Management	NYSE	\N
THG	Hanover Insurance Group Inc	2026-06-08 16:48:03.323955+00	Finance	Property-Casualty Insurers	NYSE	\N
THO	Thor Industries Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Homebuilding	NYSE	\N
THQ	abrdn Healthcare Opportunities Fund Shares of Beneficial Interest	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	2014
THW	abrdn World Healthcare Fund Shares of Beneficial Interest	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	2015
TIC	TIC Solutions Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Business Services	NYSE	2025
TISI	Team Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Other Consumer Services	NYSE	\N
TJX	TJX Companies Inc. (The) Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
TKO	TKO Group Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2023
TKR	Timken Company (The) Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Metal Fabrications	NYSE	\N
TLYS	Tilly's Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	2012
TME	Tencent Music Entertainment Group American Depositary Shares each representing two Class A Ordinary Shares	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Broadcasting	NYSE	2018
TMHC	Taylor Morrison Home Corporation Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Homebuilding	NYSE	2013
TMO	Thermo Fisher Scientific Inc Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Industrial Machinery/Components	NYSE	\N
TNC	Tennant Company Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Industrial Machinery/Components	NYSE	\N
TNET	TriNet Group Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Business Services	NYSE	2014
TNL	Travel   Leisure Co. Common  Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Hotels/Resorts	NYSE	\N
TOL	Toll Brothers Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Homebuilding	NYSE	\N
TOST	Toast Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	EDP Services	NYSE	2021
TPB	Turning Point Brands Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Tobacco	NYSE	2016
TPC	Tutor Perini Corporation Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	General Bldg Contractors - Nonresidential Bldgs	NYSE	1970
TPL	Texas Pacific Land Corporation Common Stock	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	\N
TPR	Tapestry Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Apparel	NYSE	\N
TPVG	TriplePoint Venture Growth BDC Corp. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Other Consumer Services	NYSE	2014
TR	Tootsie Roll Industries Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Staples	Specialty Foods	NYSE	\N
TRAK	ReposiTrak Inc. Common Stock	2026-06-08 16:48:03.323955+00	Technology	EDP Services	NYSE	\N
TWO^A	Two Harbors Investments Corp 8.125% Series A Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock ($25.00 liquidation preference per share)	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TWO^B	Two Harbors Investments Corp 7.625% Series B Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TWO^C	Two Harbors Investments Corp 7.25% Series C Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TWOD	Two Harbors Investments Corp 9.375% Senior Notes due 2030	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
TXNM	TXNM Energy Inc. Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Electric Utilities: Central	NYSE	\N
TXO	TXO Partners L.P. Common Units Representing Limited Partner Interests	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	2023
TXT	Textron Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Aerospace	NYSE	\N
TY	Tri Continental Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	\N
TY^	Tri Continental Corporation Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TYG	Tortoise Energy Infrastructure Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Investment Managers	NYSE	2004
TYL	Tyler Technologies Inc. Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	\N
U	Unity Software Inc. Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	2020
UA	Under Armour Inc. Class C Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Apparel	NYSE	2016
UAA	Under Armour Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Apparel	NYSE	\N
UAMY	United States Antimony Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Metal Fabrications	NYSE	\N
UAN	CVR Partners LP Common Units representing Limited Partner Interests	2026-06-08 16:48:03.323955+00	Industrials	Agricultural Chemicals	NYSE	2011
UBER	Uber Technologies Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Business Services	NYSE	2019
UCB	United Community Banks Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	2024
UDR	UDR Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
UE	Urban Edge Properties Common Shares of Beneficial Interest	2026-06-08 16:48:03.323955+00	Finance	Real Estate	NYSE	2015
UFI	Unifi Inc. New Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Textiles	NYSE	\N
UGI	UGI Corporation Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Natural Gas Distribution	NYSE	\N
UHAL	U-Haul Holding Company Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Rental/Leasing Companies	NYSE	2022
UHS	Universal Health Services Inc. Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Hospital/Nursing Management	NYSE	\N
UHT	Universal Health Realty Income Trust Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
UI	Ubiquiti Inc. Common Stock	2026-06-08 16:48:03.323955+00	Technology	Radio And Television Broadcasting And Communications Equipment	NYSE	\N
UIS	Unisys Corporation New Common Stock	2026-06-08 16:48:03.323955+00	Technology	EDP Services	NYSE	\N
ULS	UL Solutions Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Precision Instruments	NYSE	2024
UMH	UMH Properties Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
UMH^D	UMH Properties Inc. 6.375% Series D Cumulative Redeemable Preferred Stock Liquidation Preference $25 per share	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
UNF	Unifirst Corporation Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Other Consumer Services	NYSE	\N
UNFI	United Natural Foods Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Food Distributors	NYSE	2019
UNH	UnitedHealth Group Incorporated Common Stock (DE)	2026-06-08 16:48:03.323955+00	Health Care	Medical Specialities	NYSE	\N
UNM	Unum Group Common Stock	2026-06-08 16:48:03.323955+00	Finance	Accident &Health Insurance	NYSE	\N
UNMA	Unum Group 6.250% Junior Subordinated Notes due 2058	2026-06-08 16:48:03.323955+00	Finance	Accident &Health Insurance	NYSE	2018
UNP	Union Pacific Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Railroads	NYSE	\N
RXO	RXO Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Transportation Services	NYSE	2022
UPS	United Parcel Service Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Trucking Freight/Courier Services	NYSE	1999
URI	United Rentals Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Diversified Commercial Services	NYSE	1997
USA	Liberty All-Star Equity Fund Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	1986
USAC	USA Compression Partners LP Common Units Representing Limited Partner Interests	2026-06-08 16:48:03.323955+00	Utilities	Natural Gas Distribution	NYSE	2013
USB	U.S. Bancorp Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	\N
USB^A	U.S. Bancorp Depositary Shares Each representing a 1/100th interest in a share of Series A Non-CumulativePerpetual Pfd Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
USB^H	U.S. Bancorp Depositary Shares repstg 1/1000th Pfd Ser B	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
USB^P	U.S. Bancorp Depositary Shares each representing a 1/1000th interest in a share of Series K Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
USB^Q	U.S. Bancorp Depositary Shares Each Representing a 1/1000th Interest in a Share of Series L Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
USB^R	U.S. Bancorp Depositary Shares Each Representing a 1/1000th Interest in a Share of Series M Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
USB^S	U.S. Bancorp Depositary Shares each representing a 1/1000th interest in a share of Series O Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
USFD	US Foods Holding Corp. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Food Distributors	NYSE	2016
USNA	USANA Health Sciences Inc. Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Medicinal Chemicals and Botanical Products	NYSE	\N
USPH	U.S. Physical Therapy Inc. Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Medical/Nursing Services	NYSE	1992
UTF	Cohen & Steers Infrastructure Fund Inc Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	2004
UTI	Universal Technical Institute Inc Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Other Consumer Services	NYSE	2003
UTL	UNITIL Corporation Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Power Generation	NYSE	1985
UTZ	Utz Brands Inc Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Staples	Packaged Foods	NYSE	2018
UVE	UNIVERSAL INSURANCE HOLDINGS INC Common Stock	2026-06-08 16:48:03.323955+00	Finance	Property-Casualty Insurers	NYSE	\N
UVV	Universal Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Farming/Seeds/Milling	NYSE	\N
UWMC	UWM Holdings Corporation Class A Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance: Consumer Services	NYSE	\N
UZD	Array Digital Infrastructure Inc. 6.250% Senior Notes due 2069	2026-06-08 16:48:03.323955+00	Telecommunications	Telecommunications Equipment	NYSE	2020
UZE	Array Digital Infrastructure Inc. 5.500% Senior Notes due 2070	2026-06-08 16:48:03.323955+00	Telecommunications	Telecommunications Equipment	NYSE	2020
UZF	Array Digital Infrastructure Inc. 5.500% Senior Notes due 2070	2026-06-08 16:48:03.323955+00	Telecommunications	Telecommunications Equipment	NYSE	2021
V	Visa Inc.	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Business Services	NYSE	\N
VAC	Marriott Vacations Worldwide Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Real Estate	NYSE	\N
VAL	Valaris Limited Common Shares	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	2021
VMO	Invesco Municipal Opportunity Trust Common Stock	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
VNO	Vornado Realty Trust Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
VNO^L	Vornado Realty Trust Pfd Ser L %	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
VNO^M	Vornado Realty Trust 5.25% Series M Cumulative Redeemable Preferred Shares of Beneficial Interest liquidation preference $25.00 per share no par value per share	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
VNO^N	Vornado Realty Trust 5.25% Series N Cumulative Redeemable Preferred Shares of Beneficial Interest liquidation preference $25.00 per share	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
VNO^O	Vornado Realty Trust 4.45% Series O Cumulative Redeemable Preferred Shares Liquidation Preference $25.00 Per Share	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
VNT	Vontier Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Industrial Machinery/Components	NYSE	2020
VOC	VOC Energy Trust Units of Beneficial Interest	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	2011
VOYA	Voya Financial Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Life Insurance	NYSE	2013
VVV	Valvoline Inc. Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Major Chemicals	NYSE	2016
VVX	V2X Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Diversified Commercial Services	NYSE	2014
VYX	NCR Voyix Corporation Common Stock	2026-06-08 16:48:03.338671+00	Miscellaneous	Office Equipment/Supplies/Services	NYSE	\N
VZ	Verizon Communications Inc. Common Stock	2026-06-08 16:48:03.338671+00	Telecommunications	Telecommunications Equipment	NYSE	\N
W	Wayfair Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Catalog/Specialty Distribution	NYSE	2014
WAB	Westinghouse Air Brake Technologies Corporation Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Railroads	NYSE	\N
WAL	Western Alliance Bancorporation Common Stock (DE)	2026-06-08 16:48:03.338671+00	Finance	Major Banks	NYSE	2005
WAL^A	Western Alliance Bancorporation Depositary Shares Each Representing a 1/400th Interest in a Share of 4.250% Fixed-Rate Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WAT	Waters Corporation Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Biotechnology: Laboratory Analytical Instruments	NYSE	1995
WBS	Webster Financial Corporation Common Stock	2026-06-08 16:48:03.338671+00	Finance	Major Banks	NYSE	\N
WBS^F	Webster Financial Corporation Depositary Shares Each Representing 1/1000th Interest in a Share of 5.25% Series F Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WBS^G	Webster Financial Corporation Depositary Shares each representing a 1/40th interest in a share of 6.50% Series G non-cumulative perpetual preferred stock	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WCC	WESCO International Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Telecommunications Equipment	NYSE	1999
WD	Walker & Dunlop Inc Common Stock	2026-06-08 16:48:03.338671+00	Finance	Finance: Consumer Services	NYSE	2010
WHG	Westwood Holdings Group Inc Common Stock	2026-06-08 16:48:03.338671+00	Finance	Investment Managers	NYSE	\N
WHR	Whirlpool Corporation Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Consumer Electronics/Appliances	NYSE	\N
WHR^A	Whirlpool Corporation Depositary Shares each representing a 1/20th interest in a share of 8.50% Series A Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WIA	Western Asset Inflation-Linked Income Fund	2026-06-08 16:48:03.338671+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2003
BEAG	Bold Eagle Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2024
BEAGR	Bold Eagle Acquisition Corp. Right	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2024
BEAGU	Bold Eagle Acquisition Corp. Units	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2024
BEAM	Beam Therapeutics Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
BEAT	Heartbeam Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
BEATW	Heartbeam Inc. Warrant	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
BEEM	Beam Global Common Stock	2026-06-08 16:48:03.035838+00	Technology	Semiconductors	Nasdaq	\N
BEEP	Mobile Infrastructure Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	\N
BELFA	Bel Fuse Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	\N
BELFB	Bel Fuse Inc. Class B Common Stock	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	\N
BENF	Beneficient Class A Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
BENFW	Beneficient Warrant	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
BFC	Bank First Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BFRG	Bullfrog AI Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
BFRGW	Bullfrog AI Holdings Inc. Warrants	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
BFRI	Biofrontera Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
BFRIW	Biofrontera Inc. Warrants	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
SMRT	SmartRent Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	EDP Services	NYSE	\N
SN	SharkNinja Inc. Ordinary Shares	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Consumer Electronics/Appliances	NYSE	2023
SNA	Snap-On Incorporated Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Industrial Machinery/Components	NYSE	\N
SNAP	Snap Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Programming Data Processing	NYSE	2017
SNDA	Sonida Senior Living Inc. Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Hospital/Nursing Management	NYSE	\N
SNDR	Schneider National Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Trucking Freight/Courier Services	NYSE	2017
SNOW	Snowflake Inc. Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	2020
SNX	TD SYNNEX Corporation Common Stock	2026-06-08 16:48:03.323955+00	Technology	Retail: Computer Software & Peripheral Equipment	NYSE	2003
SO	Southern Company (The) Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Electric Utilities: Central	NYSE	\N
SOC	Sable Offshore Corp. Common Stock	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	2021
SOJC	Southern Company (The) Series 2017B 5.25% Junior Subordinated Notes due December 1 2077	2026-06-08 16:48:03.323955+00	Utilities	Electric Utilities: Central	NYSE	2017
SOJD	Southern Company (The) Series 2020A 4.95% Junior Subordinated Notes due January 30 2080	2026-06-08 16:48:03.323955+00	Utilities	Electric Utilities: Central	NYSE	2020
SOJE	Southern Company (The) Series 2020C 4.20% Junior Subordinated Notes due October 15 2060	2026-06-08 16:48:03.323955+00	Basic Materials	Metal Mining	NYSE	2020
SOJF	Southern Company (The) Series 2025A 6.50% Junior Subordinated Notes due March 15 2085	2026-06-08 16:48:03.323955+00	Basic Materials	Metal Mining	NYSE	2025
SRJN	Spire Inc. 6.375% Junior Subordinated Notes due 2086	2026-06-08 16:48:03.323955+00	Utilities	Oil/Gas Transmission	NYSE	\N
SRV	NXG Cushing Midstream Energy Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.323955+00	Finance	Finance Companies	NYSE	\N
SSB	SouthState Bank Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Major Banks	NYSE	\N
SSD	Simpson Manufacturing Company Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Industrial Machinery/Components	NYSE	\N
SST	System1 Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Programming Data Processing	NYSE	2020
WIW	Western Asset Inflation-Linked Opportunities & Income Fund	2026-06-08 16:48:03.338671+00	Finance	Finance Companies	NYSE	2004
WK	Workiva Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Prepackaged Software	NYSE	2014
WKC	World Kinect Corporation Common Stock	2026-06-08 16:48:03.338671+00	Energy	Oil Refining/Marketing	NYSE	\N
WLK	Westlake Corporation Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Major Chemicals	NYSE	2004
WLKP	Westlake Chemical Partners LP Common Units representing limited partner interests	2026-06-08 16:48:03.338671+00	Industrials	Major Chemicals	NYSE	2014
WLY	John Wiley & Sons Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Books	NYSE	\N
WLYB	John Wiley & Sons Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Books	NYSE	\N
WM	Waste Management Inc. Common Stock	2026-06-08 16:48:03.338671+00	Utilities	Environmental Services	NYSE	\N
WMB	Williams Companies Inc. (The) Common Stock	2026-06-08 16:48:03.338671+00	Utilities	Natural Gas Distribution	NYSE	\N
WMK	Weis Markets Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Staples	Food Chains	NYSE	\N
WMS	Advanced Drainage Systems Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Containers/Packaging	NYSE	2014
WNC	Wabash National Corporation Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Construction/Ag Equipment/Trucks	NYSE	1991
WOLF	Wolfspeed Inc. Common Stock New	2026-06-08 16:48:03.338671+00	Technology	Semiconductors	NYSE	2025
WOR	Worthington Enterprises Inc. Common Shares	2026-06-08 16:48:03.338671+00	Industrials	Steel/Iron Ore	NYSE	\N
WPC	W. P. Carey Inc. REIT	2026-06-08 16:48:03.338671+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
WRB	W.R. Berkley Corporation Common Stock	2026-06-08 16:48:03.338671+00	Finance	Property-Casualty Insurers	NYSE	\N
WRB^E	W.R. Berkley Corporation 5.70% Subordinated Debentures due 2058	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WRB^F	W.R. Berkley Corporation 5.10% Subordinated Debentures due 2059	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WRB^G	W.R. Berkley Corporation 4.25% Subordinated Debentures due 2060	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WRB^H	W.R. Berkley Corporation 4.125% Subordinated Debentures due 2061	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WRBY	Warby Parker Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Health Care	Ophthalmic Goods	NYSE	2021
WS	Worthington Steel Inc. Common Shares	2026-06-08 16:48:03.338671+00	Industrials	Steel/Iron Ore	NYSE	2023
WSM	Williams-Sonoma Inc. Common Stock (DE)	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Home Furnishings	NYSE	\N
WSO	Watsco Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Industrial Machinery/Components	NYSE	\N
WSR	Whitestone REIT Common Shares	2026-06-08 16:48:03.338671+00	Real Estate	Real Estate Investment Trusts	NYSE	2010
WST	West Pharmaceutical Services Inc. Common Stock	2026-06-08 16:48:03.338671+00	Health Care	Medical/Dental Instruments	NYSE	\N
WT	WisdomTree Inc. Common Stock	2026-06-08 16:48:03.338671+00	Finance	Investment Bankers/Brokers/Service	NYSE	2022
WTI	W&T Offshore Inc. Common Stock	2026-06-08 16:48:03.338671+00	Energy	Oil & Gas Production	NYSE	2005
WTM	White Mountains Insurance Group Ltd. Common Stock	2026-06-08 16:48:03.338671+00	Finance	Property-Casualty Insurers	NYSE	\N
WTRG	Essential Utilities Inc. Common Stock	2026-06-08 16:48:03.338671+00	Utilities	Water Supply	NYSE	\N
WTS	Watts Water Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Metal Fabrications	NYSE	1986
WTTR	Select Water Solutions Inc. Class A common stock	2026-06-08 16:48:03.338671+00	Energy	Oilfield Services/Equipment	NYSE	2017
WU	Western Union Company (The) Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Business Services	NYSE	\N
WWW	Wolverine World Wide Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Shoe Manufacturing	NYSE	\N
WY	Weyerhaeuser Company Common Stock	2026-06-08 16:48:03.338671+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
XFLT	XAI Octagon Floating Rate & Alternative Income Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.338671+00	Finance	Investment Managers	NYSE	2017
XHR	Xenia Hotels & Resorts Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Hotels/Resorts	NYSE	2015
XIFR	XPLR Infrastructure LP Common Units representing limited partner interests	2026-06-08 16:48:03.338671+00	Utilities	Electric Utilities: Central	NYSE	2014
XOM	Exxon Mobil Corporation Common Stock	2026-06-08 16:48:03.338671+00	Energy	Integrated oil Companies	NYSE	\N
XPER	Xperi Inc. Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Prepackaged Software	NYSE	2022
XPO	XPO Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Transportation Services	NYSE	\N
ZWS	Zurn Elkay Water Solutions Corporation Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Industrial Machinery/Components	NYSE	2012
CCEL	Cryo-Cell International Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Misc Health and Biotechnology Services	AMEX	2022
CET	Central Securities Corporation Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1951
CIK	Credit Suisse Asset Management Income Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	\N
CIX	CompX International Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Industrial Machinery/Components	AMEX	1998
CKX	CKX Lands Inc. Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	2003
CLM	Cornerstone Strategic Investment Fund Inc. Common Shares	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
CTGO	Contango Silver & Gold Inc. Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Precious Metals	AMEX	2021
CVM	Cel-Sci Corporation Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	AMEX	1997
CVR	Chicago Rivet & Machine Co. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Industrial Machinery/Components	AMEX	1930
CVU	CPI Aerostructures Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Military/Government/Technical	AMEX	2022
DC	Dakota Gold Corp. Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Metal Mining	AMEX	2022
DHY	Credit Suisse High Yield Credit Fund Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1998
DIT	AMCON Distributing Company Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Food Distributors	AMEX	1999
DSS	DSS Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Containers/Packaging	AMEX	\N
EAD	Allspring Income Opportunities Fund Common Shares	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
ECF	Ellsworth Growth and Income Fund Ltd.	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1986
ECF^A	Ellsworth Growth and Income Fund Ltd. 5.25% Series A Cumulative Preferred Shares (Liquidation Preference $25.00 per share)	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
EIM	Eaton Vance Municipal Bond Fund Common Shares of Beneficial Interest $.01 par value	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2002
ELA	Envela Corporation Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Consumer Specialties	AMEX	\N
ELMD	Electromed Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	AMEX	2011
EP	Empire Petroleum Corporation Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	2022
EPM	Evolution Petroleum Corporation Inc. Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	\N
BFST	Business First Bancshares Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
ERC	Allspring Multi-Sector Income Fund Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
ESP	Espey Mfg. & Electronics Corp. Common Stock	2026-06-08 16:48:03.345943+00	Technology	Industrial Machinery/Components	AMEX	1960
EVI	EVI Industries Inc.  Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Other Consumer Services	AMEX	1999
EVV	Eaton Vance Limited Duration Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
EXOD	Exodus Movement Inc. Class A Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance: Consumer Services	AMEX	\N
FAX	abrdn Asia-Pacific Income Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Investment Managers	AMEX	1986
FJET	Starfighters Space Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Air Freight/Delivery Services	AMEX	2025
FSP	Franklin Street Properties Corp. Common Stock	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	\N
FTF	Franklin Limited Duration Income Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
GBR	New Concept Energy Inc Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	1993
GENC	Gencor Industries Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Construction/Ag Equipment/Trucks	AMEX	\N
GGN	GAMCO Global Gold Natural Resources & Income Trust	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2005
GGN^B	GAMCO Global Gold Natural Reources & Income Trust 5.00% Series B Cumulative 25.00 Liquidation Preference	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
GLO	Clough Global Opportunities Fund Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2006
GLQ	Clough Global Equity Fund Clough Global Equity Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2005
GLU	Gabelli Global Utility Common Shares of Beneficial Ownership	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2004
GLU^B	The Gabelli Global Utility and Income Trust Series B Cumulative Puttable and Callable Preferred Shares	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
GLV	Clough Global Dividend and Income Fund Common Shares of beneficial interest	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2004
GORO	Gold Resource Corporation Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Precious Metals	AMEX	\N
GPUS	Hyperscale Data Inc. Common Stock	2026-06-08 16:48:03.345943+00	Technology	Industrial Machinery/Components	AMEX	1997
GPUS^D	Hyperscale Data Inc. 13.00% Series D Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
GRF	Eagle Capital Growth Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	\N
HYLN	Hyliion Holdings Corp. Class A Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Construction/Ag Equipment/Trucks	AMEX	2019
IAF	abrdn Australia Equity Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1985
IDR	Idaho Strategic Resources Inc. Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Precious Metals	AMEX	2022
IGC	IGC Pharma Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
IHT	InnSuites Hospitality Trust Shares of Beneficial Interest	2026-06-08 16:48:03.345943+00	Finance	Investment Bankers/Brokers/Service	AMEX	1999
INFU	InfuSystems Holdings Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Medical/Dental Instruments	AMEX	\N
INUV	Inuvo Inc.	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Advertising	AMEX	\N
IOR	Income Opportunity Realty Investors Inc. Common Stock	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	1987
JOB	GEE Group Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Diversified Commercial Services	AMEX	1968
KULR	KULR Technology Group Inc. Common Stock	2026-06-08 16:48:03.345943+00	Technology	Electrical Products	AMEX	\N
LCTX	Lineage Cell Therapeutics Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	AMEX	\N
LGL	LGL Group Inc. (The) Common Stock	2026-06-08 16:48:03.345943+00	Technology	Industrial Machinery/Components	AMEX	1946
LODE	Comstock Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Major Chemicals	AMEX	\N
MHH	Mastech Digital Inc Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Professional Services	AMEX	\N
MITQ	Moving iMage Technologies Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Industrial Machinery/Components	AMEX	2021
MLSS	Milestone Scientific Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Industrial Specialties	AMEX	2015
MPTI	M-tron Industries Inc. Common Stock	2026-06-08 16:48:03.345943+00	Technology	Industrial Machinery/Components	AMEX	2022
MPU	Mega Matrix Inc. Class A Ordinary Shares	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Diversified Commercial Services	AMEX	1998
MSN	Emerson Radio Corporation Common Stock	2026-06-08 16:48:03.345943+00	Consumer Staples	Consumer Electronics/Appliances	AMEX	1994
MTNB	Matinas Biopharma Holdings Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	2017
MXC	Mexco Energy Corporation Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	2003
MYO	Myomo Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Industrial Specialties	AMEX	2017
NBH	Neuberger Municipal Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2002
NEN	New England Realty Associates Limited Partnership Class A Depositary Receipts Evidencing Units of Limited Partnership	2026-06-08 16:48:03.345943+00	Real Estate	Building operators	AMEX	\N
NHC	National HealthCare Corporation Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Hospital/Nursing Management	AMEX	1986
NHS	Neuberger High Yield Strategies Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Trusts Except Educational Religious and Charitable	AMEX	\N
NML	Neuberger Energy Infrastructure and Income Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2013
NNVC	NanoViricides Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
NRO	Neuberger Real Estate Securities Income Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
NTIP	Network-1 Technologies Inc. Common Stock	2026-06-08 16:48:03.345943+00	Miscellaneous	Multi-Sector Companies	AMEX	\N
OGEN	Oragenics Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
OPHC	OptimumBank Holdings Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Major Banks	AMEX	\N
OPP^C	RiverNorth/DoubleLine Strategic Opportunity Fund Inc. 6.00% Series C Term Preferred Stock (Liquidation Preference $10.00 per share)	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
BGC	BGC Group Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
BGMS	Bio Green Med Solution Inc. Common Stock	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	\N
OPTT	Ocean Power Technologies Inc. Common Stock	2026-06-08 16:48:03.345943+00	Utilities	Electric Utilities: Central	AMEX	2007
PCG^A	Pacific Gas & Electric Co. 6% Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^B	Pacific Gas & Electric Co. 5 1/2% Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^C	Pacific Gas & Electric Co. 5% 1st Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^D	Pacific Gas & Electric Co. 5% 1st  Red. Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^E	Pacific Gas & Electric Co. 5% 1st A Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^G	Pacific Gas & Electric Co. 4.80% 1st Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^H	Pacific Gas & Electric Co. 4.50% 1st Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PCG^I	Pacific Gas & Electric Co. 4.36% 1st Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PED	Pedevco Corp. Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	\N
PRK	Park National Corporation Common Stock	2026-06-08 16:48:03.345943+00	Finance	Major Banks	AMEX	1994
PW	Power REIT (MD) Common Stock	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	1998
PW^A	Power REIT 7.75% Series A Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
PZG	Paramount Gold Nevada Corp. Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Metal Mining	AMEX	2015
RCG	RENN Fund Inc Common Stock	2026-06-08 16:48:03.345943+00	Finance	Investment Managers	AMEX	\N
REI	Ring Energy Inc. Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	\N
REPX	Riley Exploration Permian Inc. Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	1999
RLGT	Radiant Logistics Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Integrated Freight & Logistics	AMEX	\N
RVP	Retractable Technologies Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Medical/Dental Instruments	AMEX	2001
SACH	Sachem Capital Corp. Common Shares	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	2017
SACH^A	Sachem Capital Corp. 7.75% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
SCCD	Sachem Capital Corp. 6.00% Notes due 2026	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	\N
SCCE	Sachem Capital Corp. 6.00% Notes due 2027	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	2022
SCCF	Sachem Capital Corp. 7.125% Notes due 2027	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	2022
SCCG	Sachem Capital Corp. 8.00% Notes due 2027	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	2022
SDEV	Stablecoin Development Corporation Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
SEB	Seaboard Corporation Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Farming/Seeds/Milling	AMEX	1996
SLND	Southland Holdings Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Military/Government/Technical	AMEX	\N
STRW	Strawberry Fields REIT Inc. Common Stock	2026-06-08 16:48:03.345943+00	Real Estate	Real Estate Investment Trusts	AMEX	2023
STXS	Stereotaxis Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	AMEX	\N
TGEN	Tecogen Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Industrial Machinery/Components	AMEX	2025
TMP	Tompkins Financial Corporation Common Stock	2026-06-08 16:48:03.345943+00	Finance	Major Banks	AMEX	1997
TOON	Kartoon Studios Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Movies/Entertainment	AMEX	\N
TOVX	Theriva Biologics Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
TRT	Trio-Tech International Common Stock	2026-06-08 16:48:03.345943+00	Technology	Industrial Machinery/Components	AMEX	1998
UAVS	AgEagle Aerial Systems Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Aerospace	AMEX	\N
UMAC	Unusual Machines Inc. Common Stock	2026-06-08 16:48:03.345943+00	Technology	Radio And Television Broadcasting And Communications Equipment	AMEX	2024
UTG	Reaves Utility Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.345943+00	Finance	Investment Managers	AMEX	2004
UUU	Universal Safety Products Inc. Common Stock	2026-06-08 16:48:03.345943+00	Technology	Electronic Components	AMEX	2003
VENU	Venu Holding Corporation Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	AMEX	2024
VFL	abrdn National Municipal Income Fund Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1993
VGZ	Vista Gold Corp Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Precious Metals	AMEX	1986
VKI	Invesco Advantage Municipal Income Trust II Common Shares of Beneficial Interest (DE)	2026-06-08 16:48:03.345943+00	Finance	Finance Companies	AMEX	1993
WWR	Westwater Resources Inc. Common Stock	2026-06-08 16:48:03.345943+00	Basic Materials	Metal Mining	AMEX	\N
BHAV	BHAV Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BHAVR	BHAV Acquisition Corp Rights	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2026
BHAVU	BHAV Acquisition Corp Units	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
BHF	Brighthouse Financial Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Life Insurance	Nasdaq	\N
BHFAL	Brighthouse Financial Inc. 6.25% Junior Subordinated Debentures due 2058	2026-06-08 16:48:03.035838+00	Finance	Life Insurance	Nasdaq	\N
VFC	V.F. Corporation Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Garments and Clothing	NYSE	\N
VOYA^B	Voya Financial Inc. Depositary Shares each representing a 1/40th interest in a share of 5.35% Fixed-Rate Reset Non-Cumulative Preferred Stock Series B	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
VOYG	Voyager Technologies Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Military/Government/Technical	NYSE	2025
VPG	Vishay Precision Group Inc. Common Stock	2026-06-08 16:48:03.338671+00	Technology	Electrical Products	NYSE	\N
WDI	Western Asset Diversified Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.338671+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2021
WEA	Western Asset Bond Fund Share of Beneficial Interest	2026-06-08 16:48:03.338671+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2002
WEAV	Weave Communications Inc. Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
WEC	WEC Energy Group Inc. Common Stock	2026-06-08 16:48:03.338671+00	Utilities	Power Generation	NYSE	\N
WELL	Welltower Inc. Common Stock	2026-06-08 16:48:03.338671+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
WES	Western Midstream Partners LP Common Units Representing Limited Partner Interests	2026-06-08 16:48:03.338671+00	Utilities	Natural Gas Distribution	NYSE	2012
WEX	WEX Inc. common stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Business Services	NYSE	\N
WFC	Wells Fargo & Company Common Stock	2026-06-08 16:48:03.338671+00	Finance	Major Banks	NYSE	\N
WFC^A	Wells Fargo & Company Depositary Shares each representing a 1/1000th interest in a share of Non-Cumulative Perpetual Class A Preferred Stock Series AA	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WFC^C	Wells Fargo & Company Depositary Shares each representing a 1/1000th interest in a share of Non-Cumulative Perpetual Class A Preferred Stock Series CC	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WFC^D	Wells Fargo & Company Depositary Shares each representing a 1/1000th interest in  a share of Non-Cumulative Perpetual Class A Preferred Stock Series DD	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WFC^L	Wells Fargo & Company 7.50% Non-Cumulative Perpetual Convertible Class A Preferred Stock Series L	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WFC^Y	Wells Fargo & Company Depositary Shares each representing a 1/1000th interest in a share of Non-Cumulative Perpetual Class A Preferred Stock Series Y	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WFC^Z	Wells Fargo & Company Depositary Shares each representing a 1/1000th interest in a share of Non-Cumulative Perpetual Class A Preferred Stock Series Z	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
WGO	Winnebago Industries Inc. Common Stock	2026-06-08 16:48:03.338671+00	Industrials	Homebuilding	NYSE	\N
WH	Wyndham Hotels & Resorts Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Hotels/Resorts	NYSE	2018
WHD	Cactus Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Oil and Gas Field Machinery	NYSE	2018
YEXT	Yext Inc. Common Stock	2026-06-08 16:48:03.338671+00	Technology	EDP Services	NYSE	2017
CMT	Core Molding Technologies Inc Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Plastic Products	AMEX	1996
COHN	Cohen & Company Inc.	2026-06-08 16:48:03.345943+00	Finance	Investment Bankers/Brokers/Service	AMEX	\N
CRF	Cornerstone Total Return Fund Inc. (The) Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	2003
BHFAM	Brighthouse Financial Inc. Depositary shares each representing a 1/1000th Interest in a Share of 4.625% Non-Cumulative Preferred Stock Series D	2026-06-08 16:48:03.035838+00	Finance	Life Insurance	Nasdaq	\N
BHFAN	Brighthouse Financial Inc. Depositary shares each representing a 1/1000th interest in a share of 5.375% Non-Cumulative Preferred Stock Series C	2026-06-08 16:48:03.035838+00	Finance	Life Insurance	Nasdaq	\N
BHFAO	Brighthouse Financial Inc. Depositary Shares 6.75% Non-Cumulative Preferred Stock Series B	2026-06-08 16:48:03.035838+00	Finance	Life Insurance	Nasdaq	\N
BHFAP	Brighthouse Financial Inc. Depositary Shares 6.6% Non-Cumulative Preferred Stock Series A	2026-06-08 16:48:03.035838+00	Finance	Life Insurance	Nasdaq	\N
BHRB	Burke & Herbert Financial Services Corp. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BIAF	bioAffinity Technologies Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2022
BIAFW	bioAffinity Technologies Inc. Warrant	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2022
BIDWU	Tribeca Strategic Acquisition Corp. Unit	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2026
ACCS	ACCESS Newswire Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Publishing	AMEX	\N
BIIB	Biogen Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
BLRKW	Bluerock Acquisition Corp. Warrants	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2026
INTT	inTest Corporation Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Electrical Products	AMEX	1997
AACB	Artius II Acquisition Inc. Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2025
AACBR	Artius II Acquisition Inc. Rights	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2025
AACBU	Artius II Acquisition Inc. Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2025
AACI	Armada Acquisition Corp. III Class A Ordinary Share	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AACIU	Armada Acquisition Corp. III Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AACIW	Armada Acquisition Corp. III Warrant	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AACO	Abony Acquisition Corp. I Class A Ordinary Share	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
AACOU	Abony Acquisition Corp. I Units	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
AACOW	Abony Acquisition Corp. I Warrants	2026-06-08 16:48:03.020027+00	\N	\N	Nasdaq	2026
AACP	Apogee Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AACPR	Apogee Acquisition Corp Rights	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AACPU	Apogee Acquisition Corp Units	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AACPW	Apogee Acquisition Corp Warrant	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
AAL	American Airlines Group Inc. Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	\N
AAME	Atlantic American Corporation Common Stock	2026-06-08 16:48:03.020027+00	Finance	Life Insurance	Nasdaq	\N
AAOI	Applied Optoelectronics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Semiconductors	Nasdaq	2013
AAON	AAON Inc. Common Stock	2026-06-08 16:48:03.020027+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
AAPL	Apple Inc. Common Stock	2026-06-08 16:48:03.020027+00	Technology	Computer Manufacturing	Nasdaq	1980
AARD	Aardvark Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2025
ABAT	American Battery Technology Company Common Stock	2026-06-08 16:48:03.020027+00	Basic Materials	Metal Mining	Nasdaq	\N
ABEO	Abeona Therapeutics Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
ABNB	Airbnb Inc. Class A Common Stock	2026-06-08 16:48:03.020027+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	2020
BPOPM	Popular Inc. Popular Capital Trust II - 6.125% Cumulative Monthly Income Trust Preferred Securities	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BPRN	Princeton Bancorp Inc. Common Stock (PA)	2026-06-08 16:48:03.035838+00	Finance	Major Banks	Nasdaq	\N
BRCB	Black Rock Coffee Bar Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Restaurants	Nasdaq	2025
BREZU	Breeze Acquisition Corp. II Units	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2026
BRFH	Barfresh Food Group Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Staples	Packaged Foods	Nasdaq	\N
BRID	Bridgford Foods Corporation Common Stock	2026-06-08 16:48:03.035838+00	Consumer Staples	Specialty Foods	Nasdaq	\N
BRKHU	Burtech Acquisition Corp II Unit	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2026
BRKR	Bruker Corporation Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	\N
BRKRP	Bruker Corporation 6.375% Mandatory Convertible Preferred Stock Series A	2026-06-08 16:48:03.035838+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	\N
BRLT	Brilliant Earth Group Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Consumer Specialties	Nasdaq	2021
BRR	ProCap Financial Inc. Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	2025
SIF	SIFCO Industries Inc. Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Aerospace	AMEX	1969
ABOS	Acumen Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
ABSI	Absci Corporation Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Commercial Physical & Biological Resarch	Nasdaq	2021
ABTC	American Bitcoin Corp. Class A Common Stock	2026-06-08 16:48:03.020027+00	Technology	EDP Services	Nasdaq	2018
ABVC	ABVC BioPharma Inc. Common Stock	2026-06-08 16:48:03.020027+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
BRRWW	ProCap Financial Inc. Warrant	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	2025
BWBBP	Bridgewater Bancshares Inc. Depositary Shares Each Representing a 1/100th Interest in a Share of 5.875% Non-Cumulative Perpetual Preferred Stock Series A	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
BWEN	Broadwind Inc. Common Stock	2026-06-08 16:48:03.05225+00	Telecommunications	Metal Fabrications	Nasdaq	\N
BWFG	Bankwell Financial Group Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	2014
BWIN	The Baldwin Insurance Group Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Finance	Specialty Insurers	Nasdaq	2019
BWMN	Bowman Consulting Group Ltd. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Professional Services	Nasdaq	2021
BYFC	Broadway Financial Corporation Class A Common Stock	2026-06-08 16:48:03.05225+00	Finance	Savings Institutions	Nasdaq	\N
BYND	Beyond Meat Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Staples	Packaged Foods	Nasdaq	2019
BYRN	Byrna Technologies Inc. Common Stock	2026-06-08 16:48:03.05225+00	Miscellaneous	Industrial Machinery/Components	Nasdaq	\N
BYSI	BeyondSpring Inc. Ordinary Shares	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
BZAI	Blaize Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
BZAIW	Blaize Holdings Inc. Warrants	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2025
BZFD	BuzzFeed Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	2021
BZFDW	BuzzFeed Inc. Warrant	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	2021
CABA	Cabaletta Bio Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2019
CABR	Caring Brands Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	\N
CAC	Camden National Corporation Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CCC	CCC Intelligent Solutions Holdings Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
CCCC	C4 Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
CCD	Calamos Dynamic Convertible & Income Fund Common Stock	2026-06-08 16:48:03.05225+00	Finance	Trusts Except Educational Religious and Charitable	Nasdaq	\N
CCII	Cohen Circle Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CCIIU	Cohen Circle Acquisition Corp. II Unit	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CCIIW	Cohen Circle Acquisition Corp. II Warrant	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2025
CCIX	Churchill Capital Corp IX Ordinary Shares	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	2024
CCIXW	Churchill Capital Corp IX Warrant	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	2024
CCLD	CareCloud Inc. Common Stock	2026-06-08 16:48:03.05225+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2014
CCXIW	Churchill Capital Corp XI Warrants	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2026
ATLCL	Atlanticus Holdings Corporation 6.125% Senior Notes due 2026	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
COCP	Cocrystal Pharma Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CODA	Coda Octopus Group Inc. Common stock	2026-06-08 16:48:03.05225+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
CODX	Co-Diagnostics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical/Dental Instruments	Nasdaq	2026
COFS	ChoiceOne Financial Services Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
COGT	Cogent Biosciences Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
COHU	Cohu Inc. Common Stock	2026-06-08 16:48:03.05225+00	Industrials	Electrical Products	Nasdaq	\N
COIN	Coinbase Global Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
COKE	Coca-Cola Consolidated Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	1972
COLB	Columbia Banking System Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	1992
COLL	Collegium Pharmaceutical Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
COLM	Columbia Sportswear Company Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Apparel	Nasdaq	1998
COO	The Cooper Companies Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Ophthalmic Goods	Nasdaq	\N
CORT	Corcept Therapeutics Incorporated Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2004
CORZ	Core Scientific Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
CORZW	Core Scientific Inc. Tranche 1 Warrants	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
CORZZ	Core Scientific Inc. Tranche 2 Warrants	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	\N
COSM	Cosmos Health Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Other Pharmaceuticals	Nasdaq	\N
APURU	Aperture AC Unit	2026-06-08 16:48:03.020027+00	Finance	Blank Checks	Nasdaq	2026
ASST	Strive Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2023
ASTC	Astrotech Corporation (DE) Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	\N
ASTE	Astec Industries Inc. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Construction/Ag Equipment/Trucks	Nasdaq	1986
ASTH	Astrana Health Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Professional Services	Nasdaq	\N
ASTI	Ascent Solar Technologies Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Semiconductors	Nasdaq	\N
ASTS	AST SpaceMobile Inc. Class A Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	2019
ASUR	Asure Software Inc Common Stock	2026-06-08 16:48:03.035838+00	Technology	EDP Services	Nasdaq	\N
ASYS	Amtech Systems Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Industrial Machinery/Components	Nasdaq	\N
ATEC	Alphatec Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Health Care	Medical/Dental Instruments	Nasdaq	2006
ATER	Aterian Inc. Common Stock	2026-06-08 16:48:03.035838+00	Consumer Discretionary	Home Furnishings	Nasdaq	2019
ATEX	Anterix Inc. Common Stock	2026-06-08 16:48:03.035838+00	Telecommunications	Telecommunications Equipment	Nasdaq	2015
ATHR	Aether Holdings Inc. Common Stock	2026-06-08 16:48:03.035838+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
ATII	Archimedes Tech SPAC Partners II Co. Ordinary Shares	2026-06-08 16:48:03.035838+00	\N	\N	Nasdaq	2025
ATIIU	Archimedes Tech SPAC Partners II Co. Unit	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
ATIIW	Archimedes Tech SPAC Partners II Co. Warrant	2026-06-08 16:48:03.035838+00	Finance	Blank Checks	Nasdaq	2025
ATLC	Atlanticus Holdings Corporation Common Stock	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	1995
ATLCP	Atlanticus Holdings Corporation 7.625% Series B Cumulative Perpetual Preferred Stock no par value per share	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
ATLCZ	Atlanticus Holdings Corporation 9.25% Senior Notes due 2029	2026-06-08 16:48:03.035838+00	Finance	Finance: Consumer Services	Nasdaq	\N
ATLN	Atlantic International Corp. Common Stock	2026-06-08 16:48:03.035838+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2024
CSX	CSX Corporation Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Railroads	Nasdaq	\N
CTAA	ClearThink 1 Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2026
CTAS	Cintas Corporation Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Garments and Clothing	Nasdaq	1983
CTBI	Community Trust Bancorp Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
CTKB	Cytek Biosciences Inc. Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2021
CTMX	CytomX Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
CTNM	Contineum Therapeutics Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
CTNT	Cheetah Net Supply Chain Service Inc Class A Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Motor Vehicles	Nasdaq	2023
CTOR	Citius Oncology Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
CTRN	Citi Trends Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	Nasdaq	2005
CTSH	Cognizant Technology Solutions Corporation Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	1998
CTSO	Cytosorbents Corporation Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
CTXR	Citius Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CUB	Lionheart Holdings Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2024
DYNCW	Dynamix Corporation Warrant	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2024
ELTX	Elicio Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
ELUT	Elutia Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
ELVN	Enliven Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
ELWT	Elauwit Connection Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Telecommunications Equipment	Nasdaq	2025
EMAT	Evolution Metals & Technologies Corp. Common Stock	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	\N
EMBC	Embecta Corp. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
CACC	Credit Acceptance Corporation Common Stock	2026-06-08 16:48:03.05225+00	Finance	Finance: Consumer Services	Nasdaq	1992
CADL	Candel Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
CAI	Caris Life Sciences Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical Specialities	Nasdaq	2025
CAIIU	Collective Acquisition Corp. II Units	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2026
CAKE	Cheesecake Factory Incorporated (The) Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Restaurants	Nasdaq	1992
CALC	CalciMedica Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
CALM	Cal-Maine Foods Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Staples	Farming/Seeds/Milling	Nasdaq	1996
CAMP	CAMP4 Therapeutics Corporation Common Stock	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2024
CAPN	Cayson Acquisition Corp Ordinary shares	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2024
CAPNR	Cayson Acquisition Corp Right	2026-06-08 16:48:03.05225+00	Finance	Blank Checks	Nasdaq	2024
CAPNU	Cayson Acquisition Corp Unit	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2024
CAPR	Capricor Therapeutics Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CAPS	Capstone Holding Corp. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	\N
CAQ	Cambridge Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2026
CAQUU	Cambridge Acquisition Corp. Unit	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2026
CAQUW	Cambridge Acquisition Corp. Warrants	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	2026
CAR	Avis Budget Group Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Rental/Leasing Companies	Nasdaq	\N
CARE	Carter Bankshares Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CARG	CarGurus Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	2017
CARL	Carlsmed Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Medical/Dental Instruments	Nasdaq	2025
CART	Maplebear Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Business Services	Nasdaq	2023
CASH	Pathward Financial Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	1993
CASS	Cass Information Systems Inc Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Business Services	Nasdaq	\N
CAST	FreeCast Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	Technology	EDP Services	Nasdaq	\N
CASY	Casey's General Stores Inc. Common Stock	2026-06-08 16:48:03.05225+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	Nasdaq	1983
CATY	Cathay General Bancorp Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CBC	Central Bancompany Inc. Class A Common Stock	2026-06-08 16:48:03.05225+00	\N	\N	Nasdaq	\N
CBFV	CB Financial Services Inc. Common Stock	2026-06-08 16:48:03.05225+00	Finance	Major Banks	Nasdaq	\N
CBIO	Crescent Biopharma Inc. Common Stock	2026-06-08 16:48:03.05225+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
EMISR	Emmis Acquisition Corp. Rights	2026-06-08 16:48:03.071768+00	\N	\N	Nasdaq	2025
FATE	Fate Therapeutics Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2013
EQ	Equillium Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
FATN	FatPipe Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2025
FBIO	Fortress Biotech Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
FBIOP	Fortress Biotech Inc. 9.375% Series A Cumulative Redeemable Perpetual Preferred Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
FBIZ	First Business Financial Services Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FTAI	FTAI Aviation Ltd. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Misc Corporate Leasing Services	Nasdaq	\N
FTAIM	FTAI Aviation Ltd. 9.500% Fixed-Rate Reset Series D Cumulative Perpetual Redeemable Preferred Shares	2026-06-08 16:48:03.090451+00	Industrials	Misc Corporate Leasing Services	Nasdaq	\N
FTAIN	FTAI Aviation Ltd. 8.25% Fixed - Rate Reset Series C Cumulative Perpetual Redeemable Preferred Shares	2026-06-08 16:48:03.090451+00	Industrials	Misc Corporate Leasing Services	Nasdaq	\N
FTCI	FTC Solar Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Semiconductors	Nasdaq	2021
FTDR	Frontdoor Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Diversified Commercial Services	Nasdaq	\N
FTEK	Fuel Tech Inc. Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Pollution Control Equipment	Nasdaq	\N
FTHM	Fathom Holdings Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Real Estate	Nasdaq	2020
FTLF	FitLife Brands Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	\N
FTNT	Fortinet Inc. Common Stock	2026-06-08 16:48:03.090451+00	Technology	Computer peripheral equipment	Nasdaq	2009
CWST	Casella Waste Systems Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Utilities	Environmental Services	Nasdaq	1997
CXAIW	CXApp Inc. Warrant	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	2021
CXDO	Crexendo Inc. Common Stock	2026-06-08 16:48:03.071768+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
CXIIU	Churchill Capital Corp XII Units	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2026
CYCN	Cyclerion Therapeutics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CYCU	Cycurion Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	2025
CYCUW	Cycurion Inc. Warrant	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	2025
CYN	Cyngn Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	2021
CYPH	Cypherpunk Technologies Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CYRX	CryoPort Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
CYTK	Cytokinetics Incorporated Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2004
CZFS	Citizens Financial Services Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
CZNC	Citizens & Northern Corp Common Stock	2026-06-08 16:48:03.071768+00	Finance	Major Banks	Nasdaq	\N
CZR	Caesars Entertainment Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	\N
CZWI	Citizens Community Bancorp Inc. Common Stock	2026-06-08 16:48:03.071768+00	Finance	Savings Institutions	Nasdaq	2006
DAAQ	Digital Asset Acquisition Corp. Class A Ordinary shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DAAQU	Digital Asset Acquisition Corp. Units	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DAAQW	Digital Asset Acquisition Corp. Warrant	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2025
DAIC	CID HoldCo Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
DAICW	CID HoldCo Inc. Warrants	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
DAIO	Data I/O Corporation Common Stock	2026-06-08 16:48:03.071768+00	Industrials	Electrical Products	Nasdaq	1981
DAKT	Daktronics Inc. Common Stock	2026-06-08 16:48:03.071768+00	Consumer Discretionary	Miscellaneous manufacturing industries	Nasdaq	1994
DARE	Dare Bioscience Inc. Common Stock	2026-06-08 16:48:03.071768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
DASH	DoorDash Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Technology	EDP Services	Nasdaq	\N
DAVE	Dave Inc. Class A Common Stock	2026-06-08 16:48:03.071768+00	Finance	Finance: Consumer Services	Nasdaq	\N
DAVEW	Dave Inc. Warrants	2026-06-08 16:48:03.071768+00	Finance	Finance: Consumer Services	Nasdaq	\N
DBCA	D. Boral Acquisition I Corp. Class A Ordinary Shares	2026-06-08 16:48:03.071768+00	Finance	Blank Checks	Nasdaq	2026
GIPRW	Generation Income Properties Inc Warrant	2026-06-08 16:48:03.090451+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
DVLT	Datavault AI Inc. Common Stock	2026-06-08 16:48:03.071768+00	Technology	Semiconductors	Nasdaq	2018
GYRE	Gyre Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2006
HACQ	HCM IV Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
HACQU	HCM IV Acquisition Corp. Unit	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
HACQW	HCM IV Acquisition Corp. Warrants	2026-06-08 16:48:03.10371+00	Finance	Blank Checks	Nasdaq	2026
HAFC	Hanmi Financial Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HAIN	Hain Celestial Group Inc. (The) Common Stock	2026-06-08 16:48:03.10371+00	Consumer Staples	Packaged Foods	Nasdaq	\N
HALO	Halozyme Therapeutics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
HAS	Hasbro Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
FELE	Franklin Electric Co. Inc. Common Stock	2026-06-08 16:48:03.090451+00	Consumer Discretionary	Metal Fabrications	Nasdaq	\N
FEMY	Femasys Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
FENC	Fennec Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.090451+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
FFAI	Faraday Future Intelligent Electric Inc. Class A Common Stock	2026-06-08 16:48:03.090451+00	Industrials	Auto Manufacturing	Nasdaq	2020
FFAIW	Faraday Future Intelligent Electric Inc. Warrant	2026-06-08 16:48:03.090451+00	Industrials	Auto Manufacturing	Nasdaq	2020
FFBC	First Financial Bancorp. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FFIC	Flushing Financial Corporation Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
FFIN	First Financial Bankshares Inc. Common Stock	2026-06-08 16:48:03.090451+00	Finance	Major Banks	Nasdaq	\N
IHRT	iHeartMedia Inc. Class A Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Broadcasting	Nasdaq	\N
FSHPR	Flag Ship Acquisition Corp. Right	2026-06-08 16:48:03.090451+00	\N	\N	Nasdaq	2024
IVVD	Invivyd Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
HGBL	Heritage Global Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Business Services	Nasdaq	\N
JACK	Jack In The Box Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Restaurants	Nasdaq	\N
JAGX	Jaguar Health Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2015
JAKK	JAKKS Pacific Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	1996
JANX	Janux Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
JATT	JATT II Acquisition Corp Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2026
JBHT	J.B. Hunt Transport Services Inc. Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Trucking Freight/Courier Services	Nasdaq	\N
JBIO	Jade Biosciences Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
JBLU	JetBlue Airways Corporation Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Air Freight/Delivery Services	Nasdaq	2002
JBSS	John B. Sanfilippo & Son Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Specialty Foods	Nasdaq	1991
JCAP	Jefferson Capital Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Finance Companies	Nasdaq	2025
JCTC	Jewett-Cameron Trading Company Common Shares	2026-06-08 16:48:03.119395+00	Consumer Discretionary	RETAIL: Building Materials	Nasdaq	\N
JFB	JFB Construction Holdings Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	General Bldg Contractors - Nonresidential Bldgs	Nasdaq	2025
JJSF	J & J Snack Foods Corp. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Specialty Foods	Nasdaq	1986
JKHY	Jack Henry & Associates Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	EDP Services	Nasdaq	1985
JMSB	John Marshall Bancorp Inc. Common Stock	2026-06-08 16:48:03.119395+00	Finance	Major Banks	Nasdaq	\N
KBON	Karbon Capital Partners Corp. Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2026
KBONW	Karbon Capital Partners Corp. Warrant	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2026
KCHV	Kochav Defense Acquisition Corp. Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
KCHVR	Kochav Defense Acquisition Corp. Right	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
KDK	Kodiak AI Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	EDP Services	Nasdaq	\N
KDKRW	Kodiak AI Inc. Warrants	2026-06-08 16:48:03.119395+00	Technology	EDP Services	Nasdaq	\N
KDP	Keurig Dr Pepper Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
KE	Kimball Electronics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Technology	Electrical Products	Nasdaq	\N
KELYA	Kelly Services Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Professional Services	Nasdaq	\N
KELYB	Kelly Services Inc. Class B Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Professional Services	Nasdaq	\N
HBANL	Huntington Bancshares Incorporated Depositary Shares Each Representing a 1/40th Interest in a Share of 6.875% Series J Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HBANM	Huntington Bancshares Incorporated Depositary Shares each representing a 1/1000th interest in a share of Huntington Series I Preferred Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HBANP	Huntington Bancshares Incorporated Depositary Shares 4.500% Series H Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HBANZ	Huntington Bancshares Incorporated Depositary Shares Each Representing a 1/1000th Interest in a Share of 5.50% Series L Non-Cumulative Perpetual Preferred Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HBCP	Home Bancorp Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Banks	Nasdaq	2008
HBIO	Harvard Bioscience Inc. Common Stock	2026-06-08 16:48:03.10371+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2000
HBNC	Horizon Bancorp Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	\N
HBT	HBT Financial Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Major Banks	Nasdaq	2019
HCAT	Health Catalyst Inc Common Stock	2026-06-08 16:48:03.10371+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2019
HCIC	Hennessy Capital Investment Corp. VIII Class A Ordinary Shares	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
HCICR	Hennessy Capital Investment Corp. VIII Share Rights	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
HCICU	Hennessy Capital Investment Corp. VIII Units	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2026
HCKT	Hackett Group Inc (The). Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Professional Services	Nasdaq	\N
HCMA	HCM III Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2025
HCMAU	HCM III Acquisition Corp. Units	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
HCMAW	HCM III Acquisition Corp. Warrants	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2025
HCSG	Healthcare Services Group Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Hospital/Nursing Management	Nasdaq	1983
HCTI	Healthcare Triangle Inc. Common Stock	2026-06-08 16:48:03.10371+00	Technology	EDP Services	Nasdaq	2021
HCWB	HCW Biologics Inc. Common Stock	2026-06-08 16:48:03.10371+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
HDRN	Hadron Energy Inc. Common Stock	2026-06-08 16:48:03.10371+00	Utilities	Electric Utilities: Central	Nasdaq	2024
HDRNW	Hadron Energy Inc. Warrant	2026-06-08 16:48:03.10371+00	Utilities	Electric Utilities: Central	Nasdaq	2024
HDSN	Hudson Technologies Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Industrial Specialties	Nasdaq	\N
HERZ	Herzfeld Credit Income Fund Inc. Common Stock	2026-06-08 16:48:03.10371+00	Finance	Investment Managers	Nasdaq	\N
HFBL	Home Federal Bancorp Inc. of Louisiana Common Stock	2026-06-08 16:48:03.10371+00	Finance	Savings Institutions	Nasdaq	2010
HFFG	HF Foods Group Inc. Common Stock	2026-06-08 16:48:03.10371+00	Consumer Discretionary	Food Distributors	Nasdaq	2017
HFWA	Heritage Financial Corporation Common Stock	2026-06-08 16:48:03.10371+00	Finance	Banks	Nasdaq	\N
KRAQU	KRAKacquisition Corp Unit	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2026
LOKVW	Live Oak Acquisition Corp. V Warrants	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
INAC	Indigo Acquisition Corp. Ordinary Shares	2026-06-08 16:48:03.10371+00	\N	\N	Nasdaq	2025
MDAI	Spectral AI Inc. Class A Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
JOUT	Johnson Outdoors Inc. Class A Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Recreational Games/Products/Toys	Nasdaq	\N
JRSH	Jerash Holdings (US) Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Apparel	Nasdaq	2018
JSM	Navient Corporation 6% Senior Notes due December 15 2043	2026-06-08 16:48:03.119395+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	\N
JSPR	Jasper Therapeutics Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
JSPRW	Japer Therapeutics Inc. Warrants	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2020
JTAI	Jet.AI Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Discretionary	Transportation Services	Nasdaq	2021
JUNS	Jupiter Neurosciences Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
JVA	Coffee Holding Co. Inc. Common Stock	2026-06-08 16:48:03.119395+00	Consumer Staples	Packaged Foods	Nasdaq	2005
JYNT	The Joint Corp. Common Stock	2026-06-08 16:48:03.119395+00	Miscellaneous	Multi-Sector Companies	Nasdaq	2014
KALA	KALA BIO Inc. Common Stock	2026-06-08 16:48:03.119395+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2017
KALU	Kaiser Aluminum Corporation Common Stock	2026-06-08 16:48:03.119395+00	Industrials	Metal Fabrications	Nasdaq	\N
KBONU	Karbon Capital Partners Corp. Units	2026-06-08 16:48:03.119395+00	Finance	Blank Checks	Nasdaq	2025
MDAIW	Spectral AI Inc. Warrants	2026-06-08 16:48:03.132957+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
KRAQ	KRAKacquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2026
MNKD	MannKind Corporation Common Stock	2026-06-08 16:48:03.132957+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2004
MCGAU	Yorkville Acquisition Corp. Unit	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2025
MBVI	M3-Brigade Acquisition VI Corp. Class A Ordinary Shares	2026-06-08 16:48:03.119395+00	\N	\N	Nasdaq	2025
MCGA	Yorkville Acquisition Corp. Class A Ordinary Share	2026-06-08 16:48:03.132957+00	Utilities	Electric Utilities: Central	Nasdaq	2025
MCGAW	Yorkville Acquisition Corp. Warrant	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	2025
MCHB	Mechanics Bancorp Class A Common Stock	2026-06-08 16:48:03.132957+00	Finance	Major Banks	Nasdaq	2012
MCHP	Microchip Technology Incorporated Common Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	1993
MCHPP	Microchip Technology Incorporated Depositary Shares Each Representing a 1/20th Interest in a Share of 7.50% Series A Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.132957+00	Technology	Semiconductors	Nasdaq	\N
NMFCZ	New Mountain Finance Corporation 8.250% Notes due 2028	2026-06-08 16:48:03.132957+00	\N	\N	Nasdaq	\N
NUCL	Eagle Nuclear Energy Corp. Common stock	2026-06-08 16:48:03.14768+00	Basic Materials	Other Metals and Minerals	Nasdaq	\N
MLAAU	Mountain Lake Acquisition Corp. II Units	2026-06-08 16:48:03.132957+00	Finance	Blank Checks	Nasdaq	2026
NUCLW	Eagle Nuclear Energy Corp. Warrants	2026-06-08 16:48:03.14768+00	Basic Materials	Other Metals and Minerals	Nasdaq	\N
ONB	Old National Bancorp Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
OVLY	Oak Valley Bancorp (CA) Common Stock	2026-06-08 16:48:03.14768+00	Finance	Major Banks	Nasdaq	\N
NUTX	Nutex Health Inc. Common Stock	2026-06-08 16:48:03.14768+00	Consumer Discretionary	Business Services	Nasdaq	\N
NUVL	Nuvalent Inc. Class A Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2021
NUWE	Nuwellis Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	\N
NVAX	Novavax Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
NVCT	Nuvectis Pharma Inc. Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2022
PODD	Insulet Corporation Common Stock	2026-06-08 16:48:03.14768+00	Health Care	Medical/Dental Instruments	Nasdaq	2007
PROV	Provident Financial Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Savings Institutions	Nasdaq	\N
PRPL	Purple Innovation Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Home Furnishings	Nasdaq	2015
PRPO	Precipio Inc.  Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	\N
PRTA	Prothena Corporation plc Ordinary Shares	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
PRTH	Priority Technology Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Business Services	Nasdaq	2016
PRTS	CarParts.com Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Auto & Home Supply Stores	Nasdaq	2007
PRVA	Privia Health Group Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical/Nursing Services	Nasdaq	2021
PSEC	Prospect Capital Corporation Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	2004
PSIX	Power Solutions International Inc. Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Industrial Machinery/Components	Nasdaq	\N
PSKY	Paramount Skydance Corporation Class B Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Broadcasting	Nasdaq	\N
PSMT	PriceSmart Inc. Common Stock	2026-06-08 16:48:03.166278+00	Consumer Discretionary	Department/Specialty Retail Stores	Nasdaq	\N
PSNL	Personalis Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Medical Specialities	Nasdaq	2019
PRDO	Perdoceo Education Corporation Common Stock	2026-06-08 16:48:03.166278+00	Real Estate	Other Consumer Services	Nasdaq	\N
PRGS	Progress Software Corporation Common Stock (DE)	2026-06-08 16:48:03.166278+00	Technology	Computer Software: Prepackaged Software	Nasdaq	1991
PRHI	Presurance Holdings Inc. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Property-Casualty Insurers	Nasdaq	2015
PRHIZ	Presurance Holdings Inc. 9.75% Senior Unsecured Notes due 2028	2026-06-08 16:48:03.166278+00	Finance	Property-Casualty Insurers	Nasdaq	\N
PRLD	Prelude Therapeutics Incorporated Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
PRME	Prime Medicine Inc. Common Stock	2026-06-08 16:48:03.166278+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2022
PROP	Prairie Operating Co. Common Stock	2026-06-08 16:48:03.166278+00	Finance	Finance: Consumer Services	Nasdaq	\N
ROCK	Gibraltar Industries Inc. Common Stock	2026-06-08 16:48:03.166278+00	Industrials	Steel/Iron Ore	Nasdaq	1993
SCWO	374Water Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Metal Fabrications	Nasdaq	\N
SCYX	SCYNEXIS Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2014
SELF	Global Self Storage Inc. Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SENEA	Seneca Foods Corp. Class A Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Packaged Foods	Nasdaq	\N
SENEB	Seneca Foods Corp. Class B Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Packaged Foods	Nasdaq	\N
SENS	Senseonics Holdings Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	\N
SEPN	Septerna Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
SERA	Sera Prognostics Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical Specialities	Nasdaq	2021
SERV	Serve Robotics Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Industrial Specialties	Nasdaq	\N
SEV	Aptera Motors Corp. Class B Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Auto Manufacturing	Nasdaq	\N
SEVN	Seven Hills Realty Trust Common Stock	2026-06-08 16:48:03.181061+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
SEZL	Sezzle Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Finance: Consumer Services	Nasdaq	\N
SFBC	Sound Financial Bancorp Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Savings Institutions	Nasdaq	\N
SFD	Smithfield Foods Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Meat/Poultry/Fish	Nasdaq	2025
SFIX	Stitch Fix Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Catalog/Specialty Distribution	Nasdaq	2017
SFM	Sprouts Farmers Market Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Staples	Food Chains	Nasdaq	2013
SFNC	Simmons First National Corporation Class A Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	\N
SFST	Southern First Bancshares Inc. Common Stock	2026-06-08 16:48:03.181061+00	Finance	Major Banks	Nasdaq	\N
SGA	Saga Communications Inc. Class A Common Stock (FL)	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Broadcasting	Nasdaq	\N
SGC	Superior Group of Companies Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Apparel	Nasdaq	\N
SGHT	Sight Sciences Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
SGLY	Singularity Future Technology Ltd. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Integrated Freight & Logistics	Nasdaq	2008
SGMT	Sagimet Biosciences Inc. Series A Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2023
SOBR	SOBR Safe Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Newspapers/Magazines	Nasdaq	\N
RREVU	RRE Ventures Acquisition Corp. Units	2026-06-08 16:48:03.166278+00	Finance	Blank Checks	Nasdaq	2026
SOCAW	Solarius Capital Acquisition Corp. Warrant	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SDGR	Schrodinger Inc. Common Stock	2026-06-08 16:48:03.181061+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2020
SDHI	Siddhi Acquisition Corp Class A Common stock	2026-06-08 16:48:03.181061+00	Finance	Blank Checks	Nasdaq	2025
SDHIR	Siddhi Acquisition Corp Right	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
SDOT	Sadot Group Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Restaurants	Nasdaq	2020
SDST	Stardust Power Inc. Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Major Chemicals	Nasdaq	2021
SDSTW	Stardust Power Inc. Warrant	2026-06-08 16:48:03.181061+00	Industrials	Major Chemicals	Nasdaq	2021
SEAT	Vivid Seats Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
SEATW	Vivid Seats Inc. Warrant	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
SEER	Seer Inc. Class A Common Stock	2026-06-08 16:48:03.181061+00	Industrials	Biotechnology: Laboratory Analytical Instruments	Nasdaq	2020
SEGG	Sports Entertainment Gaming Global Corporation Common Stock	2026-06-08 16:48:03.181061+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2023
SEIC	SEI Investments Company Common Stock	2026-06-08 16:48:03.181061+00	Finance	Investment Bankers/Brokers/Service	Nasdaq	1981
SWAG	Stran & Company Inc. Common Stock	2026-06-08 16:48:03.181061+00	Consumer Discretionary	Advertising	Nasdaq	2021
TEAD	Teads Holding Co. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2021
TECH	Bio-Techne Corp Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	\N
TGL	Treasure Global Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Business Services	Nasdaq	2022
TGTX	TG Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TH	Target Hospitality Corp. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Hotels/Resorts	Nasdaq	2018
THFF	First Financial Corporation Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
THRM	Gentherm Inc Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Auto Parts:O.E.M.	Nasdaq	\N
THRY	Thryv Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Advertising	Nasdaq	\N
TIL	Instil Bio Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2021
TILE	Interface Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Home Furnishings	Nasdaq	\N
TIPT	Tiptree Inc. Common Stock	2026-06-08 16:48:03.196479+00	Finance	Property-Casualty Insurers	Nasdaq	\N
TITN	Titan Machinery Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	2007
TKNO	Alpha Teknova Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: In Vitro & In Vivo Diagnostic Substances	Nasdaq	2021
TLF	Tandy Leather Factory Inc. Common Stock	2026-06-08 16:48:03.196479+00	Consumer Discretionary	Apparel	Nasdaq	\N
TLN	Talen Energy Corporation Common Stock	2026-06-08 16:48:03.196479+00	Utilities	Electric Utilities: Central	Nasdaq	\N
TLNC	Talon Capital Corp. Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TLNCU	Talon Capital Corp. Units	2026-06-08 16:48:03.196479+00	Finance	Blank Checks	Nasdaq	2025
TLNCW	Talon Capital Corp. Warrants	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2025
TLPH	Talphera Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2011
TLRY	Tilray Brands Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medicinal Chemicals and Botanical Products	Nasdaq	2018
TLS	Telos Corporation Common Stock	2026-06-08 16:48:03.196479+00	Technology	EDP Services	Nasdaq	2020
TLSI	TriSalus Life Sciences Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical Specialities	Nasdaq	2021
TLSIW	TriSalus Life Sciences Inc. Warrant	2026-06-08 16:48:03.196479+00	Health Care	Medical Specialities	Nasdaq	2021
TMCI	Treace Medical Concepts Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	2021
TMDX	TransMedics Group Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	Nasdaq	2019
TMTS	Spartacus Acquisition Corp. II Class A Ordinary Shares	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2026
TMTSW	Spartacus Acquisition Corp. II Warrants	2026-06-08 16:48:03.196479+00	\N	\N	Nasdaq	2026
TMUS	T-Mobile US Inc. Common Stock	2026-06-08 16:48:03.196479+00	Telecommunications	Telecommunications Equipment	Nasdaq	\N
TOWN	TowneBank Common Stock	2026-06-08 16:48:03.196479+00	Finance	Major Banks	Nasdaq	\N
SPEGR	Silver Pegasus Acquisition Corp Rights.	2026-06-08 16:48:03.181061+00	\N	\N	Nasdaq	2025
TECX	Tectonic Therapeutic Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2018
TELA	TELA Bio Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Medical/Dental Instruments	Nasdaq	2019
TELO	Telomir Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2024
TEM	Tempus AI Inc. Class A Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Programming Data Processing	Nasdaq	2024
TENB	Tenable Holdings Inc. Common Stock	2026-06-08 16:48:03.196479+00	Technology	Computer Software: Prepackaged Software	Nasdaq	2018
TENX	Tenax Therapeutics Inc. Common Stock	2026-06-08 16:48:03.196479+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
TFSL	TFS Financial Corporation Common Stock	2026-06-08 16:48:03.196479+00	Finance	Savings Institutions	Nasdaq	2007
VVOS	Vivos Therapeutics Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Medical/Dental Instruments	Nasdaq	2020
VWAV	VisionWave Holdings Inc. Common Stock	2026-06-08 16:48:03.212596+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
VWAVW	VisionWave Holdings Inc. Warrant	2026-06-08 16:48:03.212596+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
VYGR	Voyager Therapeutics Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	Nasdaq	2015
VYNE	VYNE Therapeutics Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	2018
WABC	Westamerica Bancorporation Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WAFDP	WaFd Inc. Depositary Shares	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WALD	Waldencast plc Class A Ordinary Share	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	2021
WALDW	Waldencast plc Warrant	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Package Goods/Cosmetics	Nasdaq	2021
WASH	Washington Trust Bancorp Inc. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
WATT	Energous Corporation Common Stock	2026-06-08 16:48:03.212596+00	Technology	Radio And Television Broadcasting And Communications Equipment	Nasdaq	2014
WAY	Waystar Holding Corp. Common Stock	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	2024
WBD	Warner Bros. Discovery Inc. Series A Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	Nasdaq	\N
WBTN	WEBTOON Entertainment Inc. Common stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Publishing	Nasdaq	2024
WDAY	Workday Inc. Class A Common Stock	2026-06-08 16:48:03.212596+00	Technology	EDP Services	Nasdaq	\N
WDC	Western Digital Corporation Common Stock	2026-06-08 16:48:03.212596+00	Technology	Electronic Components	Nasdaq	\N
WDFC	WD-40 Company Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Major Chemicals	Nasdaq	1973
WENN	Wen Acquisition Corp Class A Ordinary Shares	2026-06-08 16:48:03.212596+00	\N	\N	Nasdaq	2025
WHLRD	Wheeler Real Estate Investment Trust Inc. Series D Cumulative Preferred Stock	2026-06-08 16:48:03.212596+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
WHLRL	Wheeler Real Estate Investment Trust Inc. 7.00% Senior Subordinated Convertible Notes Due 2031	2026-06-08 16:48:03.212596+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
WHLRP	Wheeler Real Estate Investment Trust Inc. Class B Preferred Stock	2026-06-08 16:48:03.212596+00	Real Estate	Real Estate Investment Trusts	Nasdaq	\N
WHWK	Whitehawk Therapeutics Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Biotechnology: Pharmaceutical Preparations	Nasdaq	\N
WINA	Winmark Corporation Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Other Specialty Stores	Nasdaq	\N
WSBC	WesBanco Inc. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Major Banks	Nasdaq	\N
AFB	AllianceBernstein National Municipal Income Fund Inc	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2002
AFG	American Financial Group Inc. Common Stock	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	\N
AFGB	American Financial Group Inc. 5.875% Subordinated Debentures due 2059	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2019
AFGC	American Financial Group Inc. 5.125% Subordinated Debentures due 2059	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2019
AFGD	American Financial Group Inc. 5.625% Subordinated Debentures due 2060	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2020
AFGE	American Financial Group Inc. 4.500% Subordinated Debentures due 2060	2026-06-08 16:48:03.223058+00	Finance	Property-Casualty Insurers	NYSE	2020
AFL	AFLAC Incorporated Common Stock	2026-06-08 16:48:03.223058+00	Finance	Accident &Health Insurance	NYSE	\N
AGCO	AGCO Corporation Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Industrial Machinery/Components	NYSE	\N
AGD	abrdn Global Dynamic Dividend Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2006
WEN	Wendy's Company (The) Common Stock	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Restaurants	Nasdaq	\N
WENNU	Wen Acquisition Corp Unit	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2025
WENNW	Wen Acquisition Corp Warrant	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2025
WERN	Werner Enterprises Inc. Common Stock	2026-06-08 16:48:03.212596+00	Industrials	Trucking Freight/Courier Services	Nasdaq	1986
WEST	Westrock Coffee Company Common Stock	2026-06-08 16:48:03.212596+00	Consumer Staples	Beverages (Production/Distribution)	Nasdaq	\N
WEYS	Weyco Group Inc. Common Stock	2026-06-08 16:48:03.212596+00	Consumer Staples	Apparel	Nasdaq	\N
WFCF	Where Food Comes From Inc. Common Stock	2026-06-08 16:48:03.212596+00	Technology	Computer Software: Prepackaged Software	Nasdaq	\N
WFRD	Weatherford International plc Ordinary Shares	2026-06-08 16:48:03.212596+00	Consumer Discretionary	Oil and Gas Field Machinery	Nasdaq	\N
WGRX	Wellgistics Health Inc. Common Stock	2026-06-08 16:48:03.212596+00	Health Care	Other Pharmaceuticals	Nasdaq	2025
WGS	GeneDx Holdings Corp. Class A Common Stock	2026-06-08 16:48:03.212596+00	Technology	Retail: Computer Software & Peripheral Equipment	Nasdaq	2020
WGSWW	GeneDx Holdings Corp. Warrant	2026-06-08 16:48:03.212596+00	Technology	Retail: Computer Software & Peripheral Equipment	Nasdaq	2020
WHF	WhiteHorse Finance Inc. Common Stock	2026-06-08 16:48:03.212596+00	Finance	Finance Companies	Nasdaq	\N
WHFCL	WhiteHorse Finance Inc. 7.875% Notes due 2028	2026-06-08 16:48:03.212596+00	\N	\N	Nasdaq	\N
WHLR	Wheeler Real Estate Investment Trust Inc. Common Stock	2026-06-08 16:48:03.212596+00	Real Estate	Real Estate Investment Trusts	Nasdaq	2012
ADM	Archer-Daniels-Midland Company Common Stock	2026-06-08 16:48:03.223058+00	Consumer Staples	Packaged Foods	NYSE	\N
XRPNU	Armada Acquisition Corp. II Units	2026-06-08 16:48:03.212596+00	Finance	Blank Checks	Nasdaq	2025
ACHR	Archer Aviation Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Industrials	Aerospace	NYSE	2020
ACI	Albertsons Companies Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Staples	Food Chains	NYSE	2020
ACM	AECOM Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Military/Government/Technical	NYSE	2007
ACP	abrdn Income Credit Strategies Fund Common Shares	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	2011
ACP^A	abrdn Income Credit Strategies Fund 5.250% Series A Perpetual Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ACR	ACRES Commercial Realty Corp. Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
ACR^C	ACRES Commercial Realty Corp. 8.625% Fixed-to-Floating Series C Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ACR^D	ACRES Commercial Realty Corp. 7.875% Series D Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ACRE	Ares Commercial Real Estate Corporation Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	2012
ACV	Virtus Diversified Income & Convertible Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.223058+00	Finance	Finance/Investors Services	NYSE	2015
ACVA	ACV Auctions Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Business Services	NYSE	2025
AD	Array Digital Infrastructure Inc. Common Shares	2026-06-08 16:48:03.223058+00	Telecommunications	Telecommunications Equipment	NYSE	1988
ADC	Agree Realty Corporation Common Stock	2026-06-08 16:48:03.223058+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
ADC^A	Agree Realty Corporation Depositary Shares each representing 1/1000th of a 4.250% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
ADNT	Adient plc Ordinary Shares	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	2016
ADT	ADT Inc. Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Diversified Commercial Services	NYSE	2018
ADX	Adams Diversified Equity Fund Inc.	2026-06-08 16:48:03.223058+00	Finance	Investment Managers	NYSE	\N
AEE	Ameren Corporation Common Stock	2026-06-08 16:48:03.223058+00	Utilities	Power Generation	NYSE	\N
AMRC	Ameresco Inc. Class A Common Stock	2026-06-08 16:48:03.223058+00	Consumer Discretionary	Engineering & Construction	NYSE	2010
BF/A	Brown Forman Corporation	2026-06-08 16:48:03.223058+00	\N	\N	NYSE	\N
BML^L	Bank of America Corporation Depositary Shares (Each representing a 1/1200th Interest in a Share of Floating Rate Non-Cumulative Preferred Stock Series 5)	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BMNR	BitMine Immersion Technologies Inc. Common Stock	2026-06-08 16:48:03.236618+00	Finance	Finance: Consumer Services	NYSE	2025
BMY	Bristol-Myers Squibb Company Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
BNED	Barnes & Noble Education Inc Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Other Specialty Stores	NYSE	2015
BNL	Broadstone Net Lease Inc. Common Stock	2026-06-08 16:48:03.236618+00	Real Estate	Real Estate Investment Trusts	NYSE	2020
BNY	The Bank of New York Mellon Corporation Common Stock	2026-06-08 16:48:03.236618+00	Finance	Major Banks	NYSE	\N
BNY^K	The Bank Of New York Mellon Corporation  Depositary Shares each representing a 1/4000th interest in a share of Series K Noncumulative Perpetual Preferred Stock	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BOC	Boston Omaha Corporation Class A Common Stock	2026-06-08 16:48:03.236618+00	Finance	Real Estate	NYSE	2022
BHR^D	Braemar Hotels & Resorts Inc. 8.25% Series D Cumulative Preferred Stock  par value $0.01 per share	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BHV	BlackRock Virginia Municipal Bond Trust	2026-06-08 16:48:03.236618+00	Finance	Finance/Investors Services	NYSE	2002
BHVN	Biohaven Ltd. Common Shares	2026-06-08 16:48:03.236618+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2022
BILL	BILL Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Technology	EDP Services	NYSE	2019
BIO	Bio-Rad Laboratories Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Industrials	Biotechnology: Laboratory Analytical Instruments	NYSE	1980
BIO/B	Bio-Rad Laboratories Inc.	2026-06-08 16:48:03.236618+00	\N	\N	NYSE	\N
BIT	BlackRock Multi-Sector Income Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.236618+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2013
BJ	BJ's Wholesale Club Holdings Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	2018
BKD	Brookdale Senior Living Inc. Common Stock	2026-06-08 16:48:03.236618+00	Health Care	Hospital/Nursing Management	NYSE	2005
BKE	Buckle Inc. (The) Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
BKH	Black Hills Corporation Common Stock	2026-06-08 16:48:03.236618+00	Utilities	Electric Utilities: Central	NYSE	\N
BKKT	Bakkt Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Finance	Finance: Consumer Services	NYSE	\N
BKSY	BlackSky Technology Inc. Class A Common Stock	2026-06-08 16:48:03.236618+00	Technology	Radio And Television Broadcasting And Communications Equipment	NYSE	2019
BKT	BlackRock Income Trust Inc. (The)	2026-06-08 16:48:03.236618+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
CSV	Carriage Services Inc. Common Stock	2026-06-08 16:48:03.236618+00	Consumer Discretionary	Other Consumer Services	NYSE	\N
CVX	Chevron Corporation Common Stock	2026-06-08 16:48:03.250515+00	Energy	Integrated oil Companies	NYSE	\N
CW	Curtiss-Wright Corporation Common Stock	2026-06-08 16:48:03.250515+00	Technology	Industrial Machinery/Components	NYSE	\N
CWAN	Clearwater Analytics Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
CWEN	Clearway Energy Inc. Class C Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	2015
CWH	Camping World Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	2016
CWK	Cushman & Wakefield Ltd. Common Shares	2026-06-08 16:48:03.250515+00	Finance	Real Estate	NYSE	2018
CWT	California Water Service Group Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Water Supply	NYSE	\N
CXE	MFS High Income Municipal Trust Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	1989
CXH	MFS Investment Grade Municipal Trust Common Stock	2026-06-08 16:48:03.250515+00	Finance	Investment Managers	NYSE	1989
CXM	Sprinklr Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
DBRG^H	DigitalBridge Group Inc. 7.125% Series H	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DBRG^I	DigitalBridge Group Inc. 7.15% Series I	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	\N
DG	Dollar General Corporation Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Department/Specialty Retail Stores	NYSE	2009
DGX	Quest Diagnostics Incorporated Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Medical Specialities	NYSE	\N
CXW	CoreCivic Inc. Common Stock	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
CYH	Community Health Systems Inc. Common Stock	2026-06-08 16:48:03.250515+00	Health Care	Hospital/Nursing Management	NYSE	2000
D	Dominion Energy Inc. Common Stock	2026-06-08 16:48:03.250515+00	Utilities	Electric Utilities: Central	NYSE	\N
DAL	Delta Air Lines Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Air Freight/Delivery Services	NYSE	\N
DAN	Dana Incorporated Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
DAR	Darling Ingredients Inc. Common Stock	2026-06-08 16:48:03.250515+00	Consumer Staples	Packaged Foods	NYSE	1997
DBD	Diebold Nixdorf Incorporated Common stock	2026-06-08 16:48:03.250515+00	Miscellaneous	Office Equipment/Supplies/Services	NYSE	2023
DBI	Designer Brands Inc. Class A Common Stock	2026-06-08 16:48:03.250515+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
DBL	DoubleLine Opportunistic Credit Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	2012
DBRG	DigitalBridge Group Inc.	2026-06-08 16:48:03.250515+00	Real Estate	Real Estate Investment Trusts	NYSE	2014
DSU	Blackrock Debt Strategies Fund Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance Companies	NYSE	1998
EFX	Equifax Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance: Consumer Services	NYSE	\N
ECCU	Eagle Point Credit Company 7.75% Notes due 2030	2026-06-08 16:48:03.250515+00	\N	\N	NYSE	2024
EQS	Equus Total Return Inc. Common Stock	2026-06-08 16:48:03.250515+00	Finance	Finance/Investors Services	NYSE	\N
FOA	Finance of America Companies Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	2021
FOF	Cohen & Steers Closed-End Opportunity Fund Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2006
FOR	Forestar Group Inc Common Stock	2026-06-08 16:48:03.265527+00	Finance	Real Estate	NYSE	2017
FOUR	Shift4 Payments Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Business Services	NYSE	2020
FOUR^A	Shift4 Payments Inc. 6.00% Series A Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
FPF	First Trust Intermediate Duration Preferred & Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2013
FPH	Five Point Holdings LLC Class A Common Shares	2026-06-08 16:48:03.265527+00	Finance	Real Estate	NYSE	2017
FPI	Farmland Partners Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	2014
FR	First Industrial Realty Trust Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	1994
FRA	Blackrock Floating Rate Income Strategies Fund Inc  Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Bankers/Brokers/Service	NYSE	2003
FRT	Federal Realty Investment Trust Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
FRT^C	Federal Realty Investment Trust Depositary Shares each representing a 1/1000th interest in a 5.000% Series C Cumulative Redeemable Preferred Share	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
FSCO	FS Credit Opportunities Corp. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2022
GD	General Dynamics Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Marine Transportation	NYSE	\N
GDDY	GoDaddy Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Technology	EDP Services	NYSE	2015
GDL	GDL Fund The Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2007
GDO	Western Asset Global Corporate Opportunity Fund Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance Companies	NYSE	2009
GDOT	Green Dot Corporation Class A Common Stock $0.001 par value	2026-06-08 16:48:03.265527+00	Finance	Finance: Consumer Services	NYSE	2010
GDV	Gabelli Dividend & Income Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2003
GDV^H	The Gabelli Dividend & Income Trust 5.375% Series H Cumulative Preferred Shares	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GDV^K	The Gabelli Dividend & Income Trust 4.250% Series K Cumulative Preferred Shares	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
CEV	Eaton Vance California Municipal Income Trust Shares of Beneficial Interest	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1999
FSK	FS KKR Capital Corp. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2014
FSS	Federal Signal Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Auto Manufacturing	NYSE	\N
FT	Franklin Universal Trust Common Stock	2026-06-08 16:48:03.265527+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
FTHY	First Trust High Yield Opportunities 2027 Term Fund Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2020
FTK	Flotek Industries Inc. Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Major Chemicals	NYSE	\N
FTS	Fortis Inc. Common Shares	2026-06-08 16:48:03.265527+00	Utilities	Electric Utilities: Central	NYSE	2016
FTV	Fortive Corporation Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Industrial Machinery/Components	NYSE	2016
FUBO	FuboTV Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Movies/Entertainment	NYSE	2020
FUL	H. B. Fuller Company Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Home Furnishings	NYSE	\N
FUN	Six Flags Entertainment Corporation Common Stock New	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	\N
FVR	FrontView REIT Inc. Common Stock	2026-06-08 16:48:03.265527+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
GAB	Gabelli Equity Trust Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	1986
GAB^G	Gabelli Equity Trust Inc. (The) Series G Cumulative Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GAB^H	Gabelli Equity Trust Inc. (The) Pfd Ser H	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GAB^K	Gabelli Equity Trust Inc. (The) 5.00% Series K Cumulative Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GAM	General American Investors Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	\N
GAM^B	General American Investors Company Inc. Cumulative Preferred Stock	2026-06-08 16:48:03.265527+00	\N	\N	NYSE	\N
GAP	Gap Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
GATX	GATX Corporation Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Transportation Services	NYSE	\N
GBAB	Guggenheim Taxable Municipal Bond & Investment Grade Debt Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.265527+00	Finance	Investment Managers	NYSE	2010
GBCI	Glacier Bancorp Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Major Banks	NYSE	\N
GBTG	Global Business Travel Group Inc. Class A Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Transportation Services	NYSE	2020
GBX	Greenbrier Companies Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Industrials	Railroads	NYSE	1994
GCO	Genesco Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	\N
GCTS	GCT Semiconductor Holding Inc. Common Stock	2026-06-08 16:48:03.265527+00	Technology	Semiconductors	NYSE	2021
GCV	Gabelli Convertible and Income Securities Fund Inc. (The) Common Stock	2026-06-08 16:48:03.265527+00	Finance	Finance/Investors Services	NYSE	\N
GL	Globe Life Inc. Common Stock	2026-06-08 16:48:03.265527+00	Finance	Life Insurance	NYSE	\N
ISD	PGIM High Yield Bond Fund Inc.	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2012
HLLY	Holley Inc. Common Stock	2026-06-08 16:48:03.265527+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	2020
IT	Gartner Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Other Consumer Services	NYSE	1993
ITGR	Integer Holdings Corporation Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Biotechnology: Electromedical & Electrotherapeutic Apparatus	NYSE	\N
ITT	ITT Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Fluid Controls	NYSE	2011
ITW	Illinois Tool Works Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	\N
IVR	INVESCO MORTGAGE CAPITAL INC Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2009
JMM	Nuveen Multi-Market Income Fund (MA)	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
JNJ	Johnson & Johnson Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
JOE	St. Joe Company (The) Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Homebuilding	NYSE	\N
IVR^C	INVESCO MORTGAGE CAPITAL INC 7.5% Fixed-to-Floating Series C Cumulative Redeemable Preferred Stock Liquation Preference $25.00 per Share	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
IVT	InvenTrust Properties Corp. Common Stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2021
IVZ	Invesco Ltd Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	\N
J	Jacobs Solutions Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Military/Government/Technical	NYSE	2022
JBGS	JBG SMITH Properties Common Shares	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	2017
JBI	Janus International Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Building Products	NYSE	2021
JBK	Lehman ABS 3.50 3.50% Adjustable Corp Backed Tr Certs GS Cap I	2026-06-08 16:48:03.279539+00	Finance	Finance: Consumer Services	NYSE	\N
JBL	Jabil Inc. Common Stock	2026-06-08 16:48:03.279539+00	Technology	Electrical Products	NYSE	1993
JBTM	JBT Marel Corporation Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Industrial Machinery/Components	NYSE	\N
JCE	Nuveen Core Equity Alpha Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2007
JEF	Jefferies Financial Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
JELD	JELD-WEN Holding Inc. Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Forest Products	NYSE	2017
JFR	Nuveen Floating Rate Income Fund Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2004
JGH	Nuveen Global High Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2014
JHI	John Hancock Investors Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
JHS	John Hancock Income Securities Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	\N
JILL	J. Jill Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Apparel	NYSE	2017
JLL	Jones Lang LaSalle Incorporated Common Stock	2026-06-08 16:48:03.279539+00	Finance	Real Estate	NYSE	\N
JLS	Nuveen Mortgage and Income Fund	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2009
JOBY	Joby Aviation Inc. Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Aerospace	NYSE	2020
MMD	NYLI MacKay DefinedTerm Muni Opportunities Fund Common Shares	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	2012
MMI	Marcus & Millichap Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Real Estate	NYSE	2013
MMM	3M Company Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Medical/Dental Instruments	NYSE	\N
MMS	Maximus Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Business Services	NYSE	1997
MMT	MFS Multimarket Income Trust Common Stock	2026-06-08 16:48:03.279539+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1987
MMU	Western Asset Managed Municipals Fund Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Managers	NYSE	1992
MNR	Mach Natural Resources LP Common Units representing Limited Partner Interests	2026-06-08 16:48:03.279539+00	Energy	Oil & Gas Production	NYSE	2023
MNTN	MNTN Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Advertising	NYSE	2025
MO	Altria Group Inc.	2026-06-08 16:48:03.279539+00	Health Care	Medicinal Chemicals and Botanical Products	NYSE	\N
MOD	Modine Manufacturing Company Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Auto Parts:O.E.M.	NYSE	\N
MOH	Molina Healthcare Inc Common Stock	2026-06-08 16:48:03.279539+00	Health Care	Medical Specialities	NYSE	2003
MOS	Mosaic Company (The) Common Stock	2026-06-08 16:48:03.279539+00	Industrials	Agricultural Chemicals	NYSE	\N
MOV	Movado Group Inc. Common Stock	2026-06-08 16:48:03.279539+00	Consumer Discretionary	Consumer Specialties	NYSE	\N
MP	MP Materials Corp. Common Stock	2026-06-08 16:48:03.279539+00	Basic Materials	Metal Mining	NYSE	2020
MPA	Blackrock MuniYield Pennsylvania Quality Fund Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	1992
MPC	Marathon Petroleum Corporation Common Stock	2026-06-08 16:48:03.279539+00	Energy	Integrated oil Companies	NYSE	\N
MPLX	MPLX LP Common Units Representing Limited Partner Interests	2026-06-08 16:48:03.279539+00	Energy	Natural Gas Distribution	NYSE	2012
MPT	Medical Properties Trust Inc. common stock	2026-06-08 16:48:03.279539+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
MPV	Barings Participation Investors Common Stock	2026-06-08 16:48:03.279539+00	Finance	Finance Companies	NYSE	1988
MQY	Blackrock MuniYield Quality Fund Inc. Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Bankers/Brokers/Service	NYSE	1992
MRK	Merck & Company Inc. Common Stock (new)	2026-06-08 16:48:03.279539+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	\N
MRP	Millrose Properties Inc. Class A Common Stock	2026-06-08 16:48:03.279539+00	Finance	Real Estate	NYSE	2025
MRSH	Marsh Common Stock	2026-06-08 16:48:03.279539+00	Finance	Specialty Insurers	NYSE	\N
MS	Morgan Stanley Common Stock	2026-06-08 16:48:03.279539+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
MS^A	Morgan Stanley Dep Shs repstg 1/1000 Pfd Ser A	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MS^E	Morgan Stanley DEPOSITARY SHARES REP 1/1000TH SHARES FIXED/FLTG PREFERRED STOCK SERIES E	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MS^F	Morgan Stanley Dep Shs Rpstg 1/1000th Int Prd Ser F Fxd to Flag	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MS^I	Morgan Stanley Depository Shares Representing 1/1000th Preferred Series 1 Fixed to Floating Non (Cum)	2026-06-08 16:48:03.279539+00	\N	\N	NYSE	\N
MSCI	MSCI Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Business Services	NYSE	\N
MSD	Morgan Stanley Emerging Markets Debt Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1993
MSDL	Morgan Stanley Direct Lending Fund Common Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	2024
MSGE	Madison Square Garden Entertainment Corp. Class A Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2023
MSGS	Madison Square Garden Sports Corp. Class A Common Stock (New)	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2015
NSP	Insperity Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Professional Services	NYSE	\N
OSK	Oshkosh Corporation (Holding Company)Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Auto Manufacturing	NYSE	\N
OTIS	Otis Worldwide Corporation Common Stock	2026-06-08 16:48:03.293305+00	Technology	Consumer Electronics/Appliances	NYSE	2020
OUT	OUTFRONT Media Inc. Common Stock	2026-06-08 16:48:03.293305+00	Real Estate	Real Estate Investment Trusts	NYSE	2014
OWL	Blue Owl Capital Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2020
OWLT	Owlet Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Industrial Machinery/Components	NYSE	2020
OXM	Oxford Industries Inc. Common Stock	2026-06-08 16:48:03.293305+00	Industrials	Garments and Clothing	NYSE	\N
OXY	Occidental Petroleum Corporation Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	\N
P	Everpure Inc. Class A common stock	2026-06-08 16:48:03.293305+00	Technology	Electronic Components	NYSE	2015
PACK	Ranpak Holdings Corp Class A Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Containers/Packaging	NYSE	2018
PACS	PACS Group Inc. Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Hospital/Nursing Management	NYSE	2024
PAG	Penske Automotive Group Inc. Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Retail-Auto Dealers and Gas Stations	NYSE	\N
PAI	Western Asset Investment Grade Income Fund Inc.	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
PAR	PAR Technology Corporation Common Stock	2026-06-08 16:48:03.293305+00	Miscellaneous	Office Equipment/Supplies/Services	NYSE	\N
PARR	Par Pacific Holdings Inc.  Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	\N
PATH	UiPath Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
PAXS	PIMCO Access Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2022
PAY	Paymentus Holdings Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Consumer Discretionary	Business Services	NYSE	2021
PAYC	Paycom Software Inc. Common Stock	2026-06-08 16:48:03.293305+00	Technology	Computer Software: Prepackaged Software	NYSE	2014
PB	Prosperity Bancshares Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Major Banks	NYSE	\N
PBF	PBF Energy Inc. Class A Common Stock	2026-06-08 16:48:03.293305+00	Energy	Integrated oil Companies	NYSE	2012
PBH	Prestige Consumer Healthcare Inc. Common Stock	2026-06-08 16:48:03.293305+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2005
PBI	Pitney Bowes Inc. Common Stock	2026-06-08 16:48:03.293305+00	Miscellaneous	Office Equipment/Supplies/Services	NYSE	\N
PBI^B	Pitney Bowes Inc 6.70% Notes Due 2043	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
PBT	Permian Basin Royalty Trust Common Stock	2026-06-08 16:48:03.293305+00	Energy	Oil & Gas Production	NYSE	\N
PCF	High Income Securities Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
PCG	Pacific Gas & Electric Co. Common Stock	2026-06-08 16:48:03.293305+00	Utilities	Power Generation	NYSE	\N
PCG^X	PG&E Corp 6.000% Series A Mandatory Convertible Preferred Stock	2026-06-08 16:48:03.293305+00	\N	\N	NYSE	\N
PCM	PCM Fund Inc. Common Stock	2026-06-08 16:48:03.293305+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1993
PCN	Pimco Corporate & Income Strategy Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2001
PCQ	PIMCO California Municipal Income Fund Common Stock	2026-06-08 16:48:03.293305+00	Finance	Investment Managers	NYSE	2001
PHM	PulteGroup Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Homebuilding	NYSE	\N
PHR	Phreesia Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Business Services	NYSE	2019
PII	Polaris Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Industrial Specialties	NYSE	\N
PIM	Putnam Master Intermediate Income Trust Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance Companies	NYSE	1988
PINE	Alpine Income Property Trust Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2019
PINE^A	Alpine Income Property Trust Inc. 8.00% Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PINS	Pinterest Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	Computer Software: Programming Data Processing	NYSE	2019
PIPR	Piper Sandler Companies Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Bankers/Brokers/Service	NYSE	2026
PJT	PJT Partners Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2015
PK	Park Hotels & Resorts Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Hotels/Resorts	NYSE	2016
PKE	Park Aerospace Corp. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Military/Government/Technical	NYSE	\N
PKG	Packaging Corporation of America Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Containers/Packaging	NYSE	2000
PL	Planet Labs PBC Class A Common Stock	2026-06-08 16:48:03.309287+00	Technology	Radio And Television Broadcasting And Communications Equipment	NYSE	2021
PLD	Prologis Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
PLNT	Planet Fitness Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Hotels/Resorts	NYSE	2015
PLOW	Douglas Dynamics Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Construction/Ag Equipment/Trucks	NYSE	2010
PM	Philip Morris International Inc Common Stock	2026-06-08 16:48:03.309287+00	Health Care	Medicinal Chemicals and Botanical Products	NYSE	\N
PML	Pimco Municipal Income Fund II Common Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2002
PMM	Putnam Managed Municipal Income Trust Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	1989
PMO	Putnam Municipal Opportunities Trust Common Stock	2026-06-08 16:48:03.309287+00	Finance	Finance Companies	NYSE	1993
PMT	PennyMac Mortgage Investment Trust Common Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2009
PMT^A	PennyMac Mortgage Investment Trust 8.125% Series A Fixed-to-Floating Rate Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
PMT^B	PennyMac Mortgage Investment Trust 8.00% Series B Fixed-to-Floating Rate Cumulative Redeemable Preferred Shares of Beneficial Interest	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
R	Ryder System Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Rental/Leasing Companies	NYSE	\N
RNST	Renasant Corporation Common Stock	2026-06-08 16:48:03.309287+00	Finance	Major Banks	NYSE	2023
ROK	Rockwell Automation Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Industrial Machinery/Components	NYSE	\N
ROL	Rollins Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Diversified Commercial Services	NYSE	\N
RPC	Ridgepost Capital Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Finance	Investment Managers	NYSE	2021
RPM	RPM International Inc. Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Paints/Coatings	NYSE	\N
RPT	Rithm Property Trust Inc. Common stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2015
RPT^C	Rithm Property Trust Inc. 9.875% Series C Fixed-to-Floating Rate Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RQI	Cohen & Steers Quality Income Realty Fund Inc Common Shares	2026-06-08 16:48:03.309287+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	2002
RRC	Range Resources Corporation Common Stock	2026-06-08 16:48:03.309287+00	Energy	Oil & Gas Production	NYSE	\N
RRX	Regal Rexnord Corporation Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Metal Fabrications	NYSE	1976
RS	Reliance Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Metal Fabrications	NYSE	1994
RSG	Republic Services Inc. Common Stock	2026-06-08 16:48:03.309287+00	Utilities	Environmental Services	NYSE	1998
RSI	Rush Street Interactive Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2020
RTO	Rentokil Initial plc American Depositary Shares (each representing five (5) Ordinary Shares)	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Other Consumer Services	NYSE	2022
RTX	RTX Corporation Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Aerospace	NYSE	\N
RVLV	Revolve Group Inc. Class A Common Stock	2026-06-08 16:48:03.309287+00	Consumer Discretionary	Catalog/Specialty Distribution	NYSE	2019
RVT	Royce Small-Cap Trust Inc. Common Stock	2026-06-08 16:48:03.309287+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1986
RVTY	Revvity Inc. Common Stock	2026-06-08 16:48:03.309287+00	Industrials	Biotechnology: Laboratory Analytical Instruments	NYSE	\N
RWT	Redwood Trust Inc. Common Stock	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	1995
RWT^A	Redwood Trust Inc. 10.00% Series A Fixed-Rate Reset Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
RWTN	Redwood Trust Inc. 9.125% Senior Notes Due 2029	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
RWTO	Redwood Trust Inc. 9.00% Senior Notes Due 2029	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2024
RWTP	Redwood Trust Inc. 9.125% Senior Notes Due 2030	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
RWTQ	Redwood Trust Inc. 9.500% Senior Notes Due 2030	2026-06-08 16:48:03.309287+00	Real Estate	Real Estate Investment Trusts	NYSE	2025
SCE^L	SCE TRUST VI	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SLG^I	SL Green Realty Corporation Preferred Series I	2026-06-08 16:48:03.309287+00	\N	\N	NYSE	\N
SOLV	Solventum Corporation Common Stock	2026-06-08 16:48:03.323955+00	Health Care	Medical/Dental Instruments	NYSE	2024
SOMN	Southern Company (The) 2025 Series A Corporate Units	2026-06-08 16:48:03.323955+00	Basic Materials	Metal Mining	NYSE	\N
SON	Sonoco Products Company Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Containers/Packaging	NYSE	\N
SOR	Source Capital Inc. Cmn Shs of BI	2026-06-08 16:48:03.323955+00	Finance	Investment Managers	NYSE	\N
SPB	Spectrum Brands Holdings Inc. Common Stock	2026-06-08 16:48:03.323955+00	Miscellaneous	Industrial Machinery/Components	NYSE	\N
SPCE	Virgin Galactic Holdings Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Transportation Services	NYSE	2017
SPE	Special Opportunities Fund Inc Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance/Investors Services	NYSE	\N
SPE^C	Special Opportunities Fund Inc. 2.75% Convertible Preferred Stock Series C	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
SPG	Simon Property Group Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
SPG^J	Simon Property Group Inc. Simon Property Group 8 3/8% Series J Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRC	Tejon Ranch Co Common Stock	2026-06-08 16:48:03.323955+00	Finance	Real Estate	NYSE	2000
TREX	Trex Company Inc. Common Stock	2026-06-08 16:48:03.323955+00	Basic Materials	Forest Products	NYSE	\N
TRGP	Targa Resources Inc. Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Natural Gas Distribution	NYSE	2010
TRN	Trinity Industries Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Railroads	NYSE	\N
TRNO	Terreno Realty Corporation Common Stock	2026-06-08 16:48:03.323955+00	Finance	Real Estate	NYSE	2010
TROX	Tronox Holdings plc Ordinary Shares (UK)	2026-06-08 16:48:03.323955+00	Industrials	Major Chemicals	NYSE	\N
TRTN^A	Triton International Limited 8.50% Series A Cumulative Redeemable Perpetual  Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTN^B	Triton International Limited 8.00% Series B Cumulative Redeemable Perpetual Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTN^C	Triton International Limited 7.375% Series C Cumulative Redeemable Perpetual Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTN^D	Triton International Limited 6.875% Series D Cumulative Redeemable Perpetual Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTN^E	Triton International Limited 5.75% Series E Cumulative Redeemable Perpetual Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTN^F	Triton International Limited 7.625% Series F Cumulative Redeemable Perpetual Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTN^G	Triton International Limited 7.500% Series G Cumulative Redeemable Perpetual Preference Shares	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRTX	TPG RE Finance Trust Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	2017
TRTX^C	TPG RE Finance Trust Inc. 6.25% Series C Cumulative Redeemable Preferred Stock $0.001 par value per share	2026-06-08 16:48:03.323955+00	\N	\N	NYSE	\N
TRU	TransUnion Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance: Consumer Services	NYSE	2015
TRV	The Travelers Companies Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Property-Casualty Insurers	NYSE	\N
TSI	TCW Strategic Income Fund Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Investment Managers	NYSE	\N
TSN	Tyson Foods Inc. Common Stock	2026-06-08 16:48:03.323955+00	Consumer Staples	Meat/Poultry/Fish	NYSE	\N
TSQ	Townsquare Media Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Broadcasting	NYSE	2014
TTC	Toro Company (The) Common Stock	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Tools/Hardware	NYSE	\N
TTI	Tetra Technologies Inc. Common Stock	2026-06-08 16:48:03.323955+00	Energy	Oil & Gas Production	NYSE	\N
TVC	Tennessee Valley Authority Common Stock	2026-06-08 16:48:03.323955+00	Utilities	Electric Utilities: Central	NYSE	\N
TVE	Tennessee Valley Authority	2026-06-08 16:48:03.323955+00	Utilities	Electric Utilities: Central	NYSE	\N
TWI	Titan International Inc. (DE) Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Steel/Iron Ore	NYSE	\N
TWLO	Twilio Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	2016
TWN	Taiwan Fund Inc. (The) Common Stock	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1986
TWO	Two Harbors Investment Corp	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
VRT	Vertiv Holdings LLC Class A Common Stock	2026-06-08 16:48:03.338671+00	Technology	Industrial Machinery/Components	NYSE	2018
VATE	INNOVATE Corp. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Metal Fabrications	NYSE	\N
VBF	Invesco Bond Fund Common Stock	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
VCV	Invesco California Value Municipal Income Trust Common Stock	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
VEEV	Veeva Systems Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	2013
VEL	Velocity Financial Inc. Common Stock	2026-06-08 16:48:03.323955+00	Finance	Finance: Consumer Services	NYSE	2020
VG	Venture Global Inc. Class A common stock	2026-06-08 16:48:03.323955+00	Utilities	Oil/Gas Transmission	NYSE	2025
VGI	Virtus Global Multi-Sector Income Fund Common Shares of Beneficial Interest	2026-06-08 16:48:03.323955+00	Finance	Investment Managers	NYSE	2012
VGM	Invesco Trust for Investment Grade Municipals Common Stock (DE)	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
VHI	Valhi Inc. Common Stock	2026-06-08 16:48:03.323955+00	Basic Materials	Major Chemicals	NYSE	\N
VIA	Via Transportation Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Technology	Computer Software: Prepackaged Software	NYSE	2025
VICI	VICI Properties Inc. Common Stock	2026-06-08 16:48:03.323955+00	Real Estate	Real Estate Investment Trusts	NYSE	2018
VIK	Viking Holdings Ltd Ordinary Shares	2026-06-08 16:48:03.323955+00	Consumer Discretionary	Marine Transportation	NYSE	2024
VIRT	Virtu Financial Inc. Class A Common Stock	2026-06-08 16:48:03.323955+00	Finance	Investment Bankers/Brokers/Service	NYSE	\N
VKQ	Invesco Municipal Trust Common Stock	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
VLO	Valero Energy Corporation Common Stock	2026-06-08 16:48:03.323955+00	Energy	Integrated oil Companies	NYSE	\N
VLT	Invesco High Income Trust II	2026-06-08 16:48:03.323955+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1989
VLTO	Veralto Corp Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Electrical Products	NYSE	2023
VMC	Vulcan Materials Company (Holding Company) Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Mining & Quarrying of Nonmetallic Minerals (No Fuels)	NYSE	\N
VMI	Valmont Industries Inc. Common Stock	2026-06-08 16:48:03.323955+00	Industrials	Metal Fabrications	NYSE	\N
VPV	Invesco Pennsylvania Value Municipal Income Trust Common Stock (DE)	2026-06-08 16:48:03.338671+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	\N
VRTS	Virtus Investment Partners Inc. Common Stock	2026-06-08 16:48:03.338671+00	Finance	Investment Managers	NYSE	\N
VSCO	Victorias Secret & Co. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Clothing/Shoe/Accessory Stores	NYSE	2021
VSH	Vishay Intertechnology Inc. Common Stock	2026-06-08 16:48:03.338671+00	Technology	Electrical Products	NYSE	\N
VST	Vistra Corp. Common Stock	2026-06-08 16:48:03.338671+00	Utilities	Electric Utilities: Central	NYSE	\N
VSTS	Vestis Corporation Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Consumer Specialties	NYSE	2023
VTN	Invesco Trust for Investment Grade New York Municipals Common Stock	2026-06-08 16:48:03.338671+00	Finance	Finance Companies	NYSE	\N
VTOL	Bristow Group Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Transportation Services	NYSE	\N
VTR	Ventas Inc. Common Stock	2026-06-08 16:48:03.338671+00	Real Estate	Real Estate Investment Trusts	NYSE	\N
VTS	Vitesse Energy Inc. Common Stock	2026-06-08 16:48:03.338671+00	Energy	Oil & Gas Production	NYSE	2023
VVR	Invesco Senior Income Trust Common Stock (DE)	2026-06-08 16:48:03.338671+00	Finance	Trusts Except Educational Religious and Charitable	NYSE	1998
WSO/B	Watsco Inc.	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
XPOF	Xponential Fitness Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Services-Misc. Amusement & Recreation	NYSE	2021
XPRO	Expro Group Holdings N.V. Common Stock	2026-06-08 16:48:03.338671+00	Energy	Oilfield Services/Equipment	NYSE	2013
XRN	Chiron Real Estate Inc. Common Stock	2026-06-08 16:48:03.338671+00	Real Estate	Real Estate Investment Trusts	NYSE	2016
XRN^A	Chiron Real Estate Inc. Series A Cumulative Redeemable Preferred Stock	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
XRN^B	Chiron Real Estate Inc. 8.00% Series B Cumulative Redeemable Preferred Stock $0.001 par value per share	2026-06-08 16:48:03.338671+00	\N	\N	NYSE	\N
XYL	Xylem Inc. Common Stock New	2026-06-08 16:48:03.338671+00	Industrials	Fluid Controls	NYSE	2011
XYZ	Block Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Prepackaged Software	NYSE	2015
YELP	Yelp Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Other Consumer Services	NYSE	2012
YETI	YETI Holdings Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Recreational Games/Products/Toys	NYSE	2018
YOU	Clear Secure Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
YUM	Yum! Brands Inc.	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Restaurants	NYSE	\N
YUMC	Yum China Holdings Inc. Common Stock	2026-06-08 16:48:03.338671+00	Consumer Discretionary	Restaurants	NYSE	2016
ZBH	Zimmer Biomet Holdings Inc. Common Stock	2026-06-08 16:48:03.338671+00	Health Care	Industrial Specialties	NYSE	\N
ZETA	Zeta Global Holdings Corp. Class A Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Prepackaged Software	NYSE	2021
ZIP	ZipRecruiter Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Technology	Computer Software: Programming Data Processing	NYSE	2021
ZTR	Virtus Total Return Fund Inc.	2026-06-08 16:48:03.338671+00	Finance	Investment Managers	NYSE	1988
ZTS	Zoetis Inc. Class A Common Stock	2026-06-08 16:48:03.338671+00	Health Care	Biotechnology: Pharmaceutical Preparations	NYSE	2013
ZVIA	Zevia PBC Class A Common Stock	2026-06-08 16:48:03.338671+00	Consumer Staples	Beverages (Production/Distribution)	NYSE	2021
ACU	Acme United Corporation. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Industrial Machinery/Components	AMEX	1988
AEF	abrdn Emerging Markets ex-China Fund Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	\N
AEON	AEON Biopharma Inc. Class A Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
AGIG	Abundia Global Impact Group Inc. Common stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	\N
AIRI	Air Industries Group Common Stock	2026-06-08 16:48:03.345943+00	Industrials	Military/Government/Technical	AMEX	\N
AMS	American Shared Hospital Services Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Medical Specialities	AMEX	1988
AREN	The Arena Group Holdings Inc. Common Stock	2026-06-08 16:48:03.345943+00	Technology	EDP Services	AMEX	2022
ARMP	Armata Pharmaceuticals Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Biological Products (No Diagnostic Substances)	AMEX	\N
ATNM	Actinium Pharmaceuticals Inc. (Delaware) Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Biotechnology: Pharmaceutical Preparations	AMEX	\N
AWX	Avalon Holdings Corporation Common Stock	2026-06-08 16:48:03.345943+00	Utilities	Environmental Services	AMEX	1998
BATL	Battalion Oil Corporation Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	\N
BCV	Bancroft Fund Ltd.	2026-06-08 16:48:03.345943+00	Finance	Finance/Investors Services	AMEX	1972
BCV^A	Bancroft Fund Limited 5.375% Series A Cumulative Preferred Shares	2026-06-08 16:48:03.345943+00	\N	\N	AMEX	\N
BDL	Flanigan's Enterprises Inc. Common Stock	2026-06-08 16:48:03.345943+00	Consumer Discretionary	Restaurants	AMEX	1972
BHB	Bar Harbor Bankshares Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Major Banks	AMEX	1997
BKTI	BK Technologies Corporation Common Stock	2026-06-08 16:48:03.345943+00	Technology	Radio And Television Broadcasting And Communications Equipment	AMEX	\N
BRBS	Blue Ridge Bankshares Inc. Common Stock	2026-06-08 16:48:03.345943+00	Finance	Major Banks	AMEX	\N
BRN	Barnwell Industries Inc. Common Stock	2026-06-08 16:48:03.345943+00	Energy	Oil & Gas Production	AMEX	1965
BURU	Nuburu Inc. Common Stock	2026-06-08 16:48:03.345943+00	Miscellaneous	Industrial Machinery/Components	AMEX	\N
CATX	Perspective Therapeutics Inc. Common Stock	2026-06-08 16:48:03.345943+00	Health Care	Medical/Dental Instruments	AMEX	\N
\.


--
-- Data for Name: stock_price_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_price_history (id, symbol, price_date, close, created_at, high, low, volume) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, create_date, last_modified) FROM stdin;
1	marksun	$2a$10$soHh4O23DayeX2Cye4UBjO/MgcBSFnriUZ1avznYcCwMIWSl/6zIG	2026-06-08 16:48:24.036845+00	2026-06-08 16:48:24.036845+00
\.


--
-- Data for Name: watchlist_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.watchlist_items (id, symbol, watchlist_id, create_date, last_modified) FROM stdin;
1	NVDA	1	2026-06-08 16:59:51.701669+00	2026-06-08 16:59:51.701669+00
2	AMD	1	2026-06-08 16:59:56.211364+00	2026-06-08 16:59:56.211364+00
3	INTC	1	2026-06-08 16:59:59.52769+00	2026-06-08 16:59:59.52769+00
4	ARM	1	2026-06-08 17:00:02.661227+00	2026-06-08 17:00:02.661227+00
5	MRVL	1	2026-06-08 17:00:27.852036+00	2026-06-08 17:00:27.852036+00
6	MU	1	2026-06-08 17:01:04.297553+00	2026-06-08 17:01:04.297553+00
7	SNDK	1	2026-06-08 17:01:08.305134+00	2026-06-08 17:01:08.305134+00
8	SMCI	2	2026-06-08 17:01:57.779806+00	2026-06-08 17:01:57.779806+00
9	DELL	2	2026-06-08 17:02:00.3667+00	2026-06-08 17:02:00.3667+00
10	HPE	2	2026-06-08 17:02:03.24195+00	2026-06-08 17:02:03.24195+00
11	FIG	3	2026-06-08 17:02:19.58499+00	2026-06-08 17:02:19.58499+00
12	AI	3	2026-06-08 17:02:20.943829+00	2026-06-08 17:02:20.943829+00
13	PLTR	3	2026-06-08 17:02:23.227971+00	2026-06-08 17:02:23.227971+00
14	AAPL	4	2026-06-08 17:02:36.858508+00	2026-06-08 17:02:36.858508+00
15	MSFT	4	2026-06-08 17:02:40.409585+00	2026-06-08 17:02:40.409585+00
16	TSLA	4	2026-06-08 17:02:43.590886+00	2026-06-08 17:02:43.590886+00
17	META	4	2026-06-08 17:02:46.829068+00	2026-06-08 17:02:46.829068+00
18	GOOG	4	2026-06-08 17:02:48.289858+00	2026-06-08 17:02:48.289858+00
19	AMZN	4	2026-06-08 17:02:51.572254+00	2026-06-08 17:02:51.572254+00
20	IBM	4	2026-06-08 17:02:54.57827+00	2026-06-08 17:02:54.57827+00
21	ORCL	4	2026-06-08 17:02:57.242089+00	2026-06-08 17:02:57.242089+00
22	NFLX	4	2026-06-08 17:03:00.247805+00	2026-06-08 17:03:00.247805+00
23	SMR	5	2026-06-08 17:03:35.611978+00	2026-06-08 17:03:35.611978+00
24	OKLO	5	2026-06-08 17:03:38.446708+00	2026-06-08 17:03:38.446708+00
25	NNE	5	2026-06-08 17:03:39.555895+00	2026-06-08 17:03:39.555895+00
27	TEAM	6	2026-06-08 17:03:59.025591+00	2026-06-08 17:03:59.025591+00
28	SNOW	6	2026-06-08 17:04:00.776755+00	2026-06-08 17:04:00.776755+00
29	CRM	6	2026-06-08 17:04:02.177482+00	2026-06-08 17:04:02.177482+00
30	NOW	6	2026-06-08 17:04:04.255369+00	2026-06-08 17:04:04.255369+00
31	DDOG	6	2026-06-08 17:04:07.230344+00	2026-06-08 17:04:07.230344+00
32	PD	6	2026-06-08 17:04:13.837193+00	2026-06-08 17:04:13.837193+00
33	GLD	7	2026-06-08 17:22:59.653895+00	2026-06-08 17:22:59.653895+00
34	QQQ	7	2026-06-08 17:23:01.221172+00	2026-06-08 17:23:01.221172+00
35	SPY	7	2026-06-08 17:23:02.923707+00	2026-06-08 17:23:02.923707+00
\.


--
-- Data for Name: watchlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.watchlists (id, name, user_id, create_date, last_modified) FROM stdin;
1	AI - Semi	1	2026-06-08 16:59:05.811279+00	2026-06-08 16:59:05.811279+00
2	AI - SERVER	1	2026-06-08 17:01:50.906857+00	2026-06-08 17:01:50.906857+00
3	AI -Software	1	2026-06-08 17:02:13.896302+00	2026-06-08 17:02:13.896302+00
4	Big Tech	1	2026-06-08 17:02:33.662404+00	2026-06-08 17:02:33.662404+00
5	Nuclear Energy	1	2026-06-08 17:03:29.70493+00	2026-06-08 17:03:29.70493+00
6	ERP	1	2026-06-08 17:03:53.248011+00	2026-06-08 17:03:53.248011+00
7	ETF	1	2026-06-08 17:22:53.82899+00	2026-06-08 17:22:53.82899+00
\.


--
-- Name: holdings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.holdings_id_seq', 67, true);


--
-- Name: investment_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investment_accounts_id_seq', 5, true);


--
-- Name: segment_momentum_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.segment_momentum_id_seq', 1, false);


--
-- Name: stock_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_alerts_id_seq', 1, false);


--
-- Name: stock_intraday_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_intraday_cache_id_seq', 1, false);


--
-- Name: stock_price_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_price_history_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: watchlist_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.watchlist_items_id_seq', 35, true);


--
-- Name: watchlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.watchlists_id_seq', 7, true);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: holdings holdings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings
    ADD CONSTRAINT holdings_pkey PRIMARY KEY (id);


--
-- Name: investment_accounts investment_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts
    ADD CONSTRAINT investment_accounts_pkey PRIMARY KEY (id);


--
-- Name: segment_momentum segment_momentum_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segment_momentum
    ADD CONSTRAINT segment_momentum_pkey PRIMARY KEY (id);


--
-- Name: stock_alerts stock_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_alerts
    ADD CONSTRAINT stock_alerts_pkey PRIMARY KEY (id);


--
-- Name: stock_intraday_cache stock_intraday_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_intraday_cache
    ADD CONSTRAINT stock_intraday_cache_pkey PRIMARY KEY (id);


--
-- Name: stock_metadata stock_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_metadata
    ADD CONSTRAINT stock_metadata_pkey PRIMARY KEY (symbol);


--
-- Name: stock_price_history stock_price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_price_history
    ADD CONSTRAINT stock_price_history_pkey PRIMARY KEY (id);


--
-- Name: holdings uq_holding_account_symbol; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings
    ADD CONSTRAINT uq_holding_account_symbol UNIQUE (account_id, symbol);


--
-- Name: stock_intraday_cache uq_intraday; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_intraday_cache
    ADD CONSTRAINT uq_intraday UNIQUE (symbol, bar_time);


--
-- Name: investment_accounts uq_inv_account_user_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts
    ADD CONSTRAINT uq_inv_account_user_name UNIQUE (user_id, name);


--
-- Name: segment_momentum uq_segment_date; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.segment_momentum
    ADD CONSTRAINT uq_segment_date UNIQUE (snapshot_date, sector);


--
-- Name: stock_price_history uq_stock_price_history; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_price_history
    ADD CONSTRAINT uq_stock_price_history UNIQUE (symbol, price_date);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: watchlist_items watchlist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlist_items
    ADD CONSTRAINT watchlist_items_pkey PRIMARY KEY (id);


--
-- Name: watchlists watchlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlists
    ADD CONSTRAINT watchlists_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_holdings_account; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_holdings_account ON public.holdings USING btree (account_id);


--
-- Name: idx_holdings_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_holdings_symbol ON public.holdings USING btree (symbol);


--
-- Name: idx_intraday_symbol_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_intraday_symbol_date ON public.stock_intraday_cache USING btree (symbol, trading_date);


--
-- Name: idx_inv_acct_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inv_acct_user ON public.investment_accounts USING btree (user_id);


--
-- Name: idx_segment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segment_date ON public.segment_momentum USING btree (snapshot_date DESC);


--
-- Name: idx_segment_sector; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_segment_sector ON public.segment_momentum USING btree (sector, snapshot_date DESC);


--
-- Name: idx_sph_symbol_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sph_symbol_date ON public.stock_price_history USING btree (symbol, price_date);


--
-- Name: idx_stock_alerts_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_alerts_user ON public.stock_alerts USING btree (user_id, symbol);


--
-- Name: holdings holdings_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings
    ADD CONSTRAINT holdings_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.investment_accounts(id) ON DELETE CASCADE;


--
-- Name: investment_accounts investment_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts
    ADD CONSTRAINT investment_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_alerts stock_alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_alerts
    ADD CONSTRAINT stock_alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: watchlist_items watchlist_items_watchlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlist_items
    ADD CONSTRAINT watchlist_items_watchlist_id_fkey FOREIGN KEY (watchlist_id) REFERENCES public.watchlists(id) ON DELETE CASCADE;


--
-- Name: watchlists watchlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlists
    ADD CONSTRAINT watchlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fkFwGrqKthiTvLMcqcw4gH9uCJtg0TiPkCx4ZEHprYevpDPEfb9mgM51fVWZpCn

