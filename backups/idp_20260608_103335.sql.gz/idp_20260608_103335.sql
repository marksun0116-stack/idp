--
-- PostgreSQL database dump
--

\restrict m8PjIUoR8pVctgVXbsPhN6PlPgjdR3PeL0Ucf3Wk9XXz3UypJHi6RxeAFUpGU0y

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_users (
    id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    password_hash character varying(255) NOT NULL,
    username character varying(255) NOT NULL
);


ALTER TABLE public.app_users OWNER TO postgres;

--
-- Name: app_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.app_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.app_users_id_seq OWNER TO postgres;

--
-- Name: app_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.app_users_id_seq OWNED BY public.app_users.id;


--
-- Name: auth_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_tokens (
    id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    token character varying(96) NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.auth_tokens OWNER TO postgres;

--
-- Name: auth_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_tokens_id_seq OWNER TO postgres;

--
-- Name: auth_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_tokens_id_seq OWNED BY public.auth_tokens.id;


--
-- Name: decision_record_evidence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_record_evidence (
    decision_record_id bigint NOT NULL,
    evidence character varying(2000) NOT NULL
);


ALTER TABLE public.decision_record_evidence OWNER TO postgres;

--
-- Name: decision_record_exit_criteria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_record_exit_criteria (
    decision_record_id bigint NOT NULL,
    exit_criterion character varying(2000) NOT NULL
);


ALTER TABLE public.decision_record_exit_criteria OWNER TO postgres;

--
-- Name: decision_record_risk_factors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_record_risk_factors (
    decision_record_id bigint NOT NULL,
    risk_factor character varying(2000) NOT NULL
);


ALTER TABLE public.decision_record_risk_factors OWNER TO postgres;

--
-- Name: decision_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_records (
    id bigint NOT NULL,
    activated_at timestamp(6) with time zone,
    confidence integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    decision_type character varying(255) NOT NULL,
    owner_id character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    thesis character varying(8000) NOT NULL,
    ticker character varying(255) NOT NULL,
    time_horizon character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    visibility character varying(255) NOT NULL,
    CONSTRAINT decision_records_decision_type_check CHECK (((decision_type)::text = ANY ((ARRAY['BUY'::character varying, 'SELL'::character varying, 'HOLD'::character varying, 'WATCH'::character varying, 'AVOID'::character varying])::text[]))),
    CONSTRAINT decision_records_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'CLOSED'::character varying, 'ARCHIVED'::character varying])::text[]))),
    CONSTRAINT decision_records_visibility_check CHECK (((visibility)::text = 'PRIVATE'::text))
);


ALTER TABLE public.decision_records OWNER TO postgres;

--
-- Name: decision_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.decision_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.decision_records_id_seq OWNER TO postgres;

--
-- Name: decision_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.decision_records_id_seq OWNED BY public.decision_records.id;


--
-- Name: decision_review_lessons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_review_lessons (
    decision_review_id bigint NOT NULL,
    lesson character varying(2000) NOT NULL
);


ALTER TABLE public.decision_review_lessons OWNER TO postgres;

--
-- Name: decision_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_reviews (
    id bigint NOT NULL,
    completed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL,
    due_date date NOT NULL,
    next_action character varying(2000),
    outcome_summary character varying(8000),
    owner_id character varying(255) NOT NULL,
    review_type character varying(255) NOT NULL,
    risk_assessment_accuracy integer,
    status character varying(255) NOT NULL,
    thesis_accuracy integer,
    decision_record_id bigint NOT NULL,
    CONSTRAINT decision_reviews_review_type_check CHECK (((review_type)::text = ANY ((ARRAY['THIRTY_DAYS'::character varying, 'NINETY_DAYS'::character varying, 'ONE_EIGHTY_DAYS'::character varying, 'ONE_YEAR'::character varying])::text[]))),
    CONSTRAINT decision_reviews_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'COMPLETED'::character varying, 'DISMISSED'::character varying, 'RESCHEDULED'::character varying])::text[])))
);


ALTER TABLE public.decision_reviews OWNER TO postgres;

--
-- Name: decision_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.decision_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.decision_reviews_id_seq OWNER TO postgres;

--
-- Name: decision_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.decision_reviews_id_seq OWNED BY public.decision_reviews.id;


--
-- Name: decision_revision_evidence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_revision_evidence (
    decision_revision_id bigint NOT NULL,
    evidence character varying(2000) NOT NULL
);


ALTER TABLE public.decision_revision_evidence OWNER TO postgres;

--
-- Name: decision_revision_exit_criteria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_revision_exit_criteria (
    decision_revision_id bigint NOT NULL,
    exit_criterion character varying(2000) NOT NULL
);


ALTER TABLE public.decision_revision_exit_criteria OWNER TO postgres;

--
-- Name: decision_revision_risk_factors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_revision_risk_factors (
    decision_revision_id bigint NOT NULL,
    risk_factor character varying(2000) NOT NULL
);


ALTER TABLE public.decision_revision_risk_factors OWNER TO postgres;

--
-- Name: decision_revisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.decision_revisions (
    id bigint NOT NULL,
    confidence integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    revision_number integer NOT NULL,
    thesis character varying(8000) NOT NULL,
    time_horizon character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    decision_record_id bigint NOT NULL
);


ALTER TABLE public.decision_revisions OWNER TO postgres;

--
-- Name: decision_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.decision_revisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.decision_revisions_id_seq OWNER TO postgres;

--
-- Name: decision_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.decision_revisions_id_seq OWNED BY public.decision_revisions.id;


--
-- Name: holdings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.holdings (
    id bigint NOT NULL,
    cost_basis numeric(19,6),
    created_at timestamp(6) with time zone NOT NULL,
    manual_price numeric(19,6),
    purchase_date date,
    shares numeric(19,6) NOT NULL,
    symbol character varying(255) NOT NULL,
    account_id bigint NOT NULL
);


ALTER TABLE public.holdings OWNER TO postgres;

--
-- Name: holdings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.holdings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.holdings_id_seq OWNER TO postgres;

--
-- Name: holdings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.holdings_id_seq OWNED BY public.holdings.id;


--
-- Name: investment_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_accounts (
    id bigint NOT NULL,
    account_type character varying(255) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    name character varying(255) NOT NULL,
    owner_id character varying(255) NOT NULL,
    CONSTRAINT investment_accounts_account_type_check CHECK (((account_type)::text = ANY ((ARRAY['BROKERAGE'::character varying, 'IRA'::character varying, 'ROTH_IRA'::character varying, 'FOUR_O_ONE_K'::character varying, 'HSA'::character varying])::text[])))
);


ALTER TABLE public.investment_accounts OWNER TO postgres;

--
-- Name: investment_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investment_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investment_accounts_id_seq OWNER TO postgres;

--
-- Name: investment_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investment_accounts_id_seq OWNED BY public.investment_accounts.id;


--
-- Name: investment_decision_alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_decision_alerts (
    id bigint NOT NULL,
    condition_type character varying(255) NOT NULL,
    condition_value numeric(10,2) NOT NULL,
    description character varying(255),
    status character varying(255) NOT NULL,
    triggered_at timestamp(6) with time zone,
    triggered_price numeric(10,2),
    decision_id bigint NOT NULL,
    CONSTRAINT investment_decision_alerts_condition_type_check CHECK (((condition_type)::text = ANY ((ARRAY['PRICE_ABOVE'::character varying, 'PRICE_BELOW'::character varying, 'PNL_ABOVE'::character varying, 'PNL_BELOW'::character varying])::text[]))),
    CONSTRAINT investment_decision_alerts_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'TRIGGERED'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.investment_decision_alerts OWNER TO postgres;

--
-- Name: investment_decision_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investment_decision_alerts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investment_decision_alerts_id_seq OWNER TO postgres;

--
-- Name: investment_decision_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investment_decision_alerts_id_seq OWNED BY public.investment_decision_alerts.id;


--
-- Name: investment_decision_edits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_decision_edits (
    id bigint NOT NULL,
    edited_at timestamp(6) with time zone NOT NULL,
    field_name character varying(50) NOT NULL,
    new_value character varying(2000),
    old_value character varying(2000),
    decision_id bigint NOT NULL
);


ALTER TABLE public.investment_decision_edits OWNER TO postgres;

--
-- Name: investment_decision_edits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investment_decision_edits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investment_decision_edits_id_seq OWNER TO postgres;

--
-- Name: investment_decision_edits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investment_decision_edits_id_seq OWNED BY public.investment_decision_edits.id;


--
-- Name: investment_decisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_decisions (
    id bigint NOT NULL,
    action character varying(255) NOT NULL,
    closed_at timestamp(6) with time zone,
    comments character varying(2000),
    created_at timestamp(6) with time zone NOT NULL,
    evidence character varying(2000),
    exit_pnl numeric(10,2),
    exit_price numeric(10,2),
    price numeric(10,2) NOT NULL,
    quantity integer NOT NULL,
    risks character varying(2000),
    source character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    symbol character varying(10) NOT NULL,
    thesis character varying(2000),
    title character varying(500) NOT NULL,
    transaction_date date NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    CONSTRAINT investment_decisions_action_check CHECK (((action)::text = ANY ((ARRAY['BUY'::character varying, 'SELL'::character varying, 'HOLD'::character varying, 'WATCH'::character varying, 'AVOID'::character varying])::text[]))),
    CONSTRAINT investment_decisions_source_check CHECK (((source)::text = ANY ((ARRAY['MANUAL'::character varying, 'AUTO'::character varying])::text[]))),
    CONSTRAINT investment_decisions_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'ACTIVE'::character varying, 'CLOSED'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.investment_decisions OWNER TO postgres;

--
-- Name: investment_decisions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investment_decisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investment_decisions_id_seq OWNER TO postgres;

--
-- Name: investment_decisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investment_decisions_id_seq OWNED BY public.investment_decisions.id;


--
-- Name: public_profile_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_profile_metrics (
    profile_id bigint NOT NULL,
    metric_id character varying(255) NOT NULL
);


ALTER TABLE public.public_profile_metrics OWNER TO postgres;

--
-- Name: public_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.public_profiles (
    id bigint NOT NULL,
    bio character varying(1000),
    created_at timestamp(6) with time zone NOT NULL,
    display_name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    owner_id character varying(255) NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.public_profiles OWNER TO postgres;

--
-- Name: public_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.public_profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.public_profiles_id_seq OWNER TO postgres;

--
-- Name: public_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.public_profiles_id_seq OWNED BY public.public_profiles.id;


--
-- Name: strategy_portfolios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strategy_portfolios (
    id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    description character varying(4000) NOT NULL,
    name character varying(255) NOT NULL,
    owner_id character varying(255) NOT NULL,
    starting_capital numeric(19,4) NOT NULL,
    visibility character varying(255) NOT NULL,
    CONSTRAINT strategy_portfolios_visibility_check CHECK (((visibility)::text = ANY ((ARRAY['PRIVATE'::character varying, 'PUBLIC'::character varying])::text[])))
);


ALTER TABLE public.strategy_portfolios OWNER TO postgres;

--
-- Name: strategy_portfolios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strategy_portfolios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strategy_portfolios_id_seq OWNER TO postgres;

--
-- Name: strategy_portfolios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strategy_portfolios_id_seq OWNED BY public.strategy_portfolios.id;


--
-- Name: strategy_symbol_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strategy_symbol_tags (
    tracked_symbol_id bigint NOT NULL,
    tag character varying(255) NOT NULL
);


ALTER TABLE public.strategy_symbol_tags OWNER TO postgres;

--
-- Name: strategy_tracked_symbols; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strategy_tracked_symbols (
    id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    note character varying(2000),
    symbol character varying(255) NOT NULL,
    visibility character varying(255) NOT NULL,
    strategy_id bigint NOT NULL,
    CONSTRAINT strategy_tracked_symbols_visibility_check CHECK (((visibility)::text = ANY ((ARRAY['PRIVATE'::character varying, 'PUBLIC'::character varying])::text[])))
);


ALTER TABLE public.strategy_tracked_symbols OWNER TO postgres;

--
-- Name: strategy_tracked_symbols_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strategy_tracked_symbols_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strategy_tracked_symbols_id_seq OWNER TO postgres;

--
-- Name: strategy_tracked_symbols_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strategy_tracked_symbols_id_seq OWNED BY public.strategy_tracked_symbols.id;


--
-- Name: strategy_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strategy_transactions (
    id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    decision_id bigint,
    executed_at timestamp(6) with time zone NOT NULL,
    price numeric(19,6) NOT NULL,
    quantity numeric(19,6) NOT NULL,
    side character varying(255) NOT NULL,
    symbol character varying(255) NOT NULL,
    strategy_id bigint NOT NULL,
    CONSTRAINT strategy_transactions_side_check CHECK (((side)::text = ANY ((ARRAY['BUY'::character varying, 'SELL'::character varying])::text[])))
);


ALTER TABLE public.strategy_transactions OWNER TO postgres;

--
-- Name: strategy_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strategy_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strategy_transactions_id_seq OWNER TO postgres;

--
-- Name: strategy_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strategy_transactions_id_seq OWNED BY public.strategy_transactions.id;


--
-- Name: app_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_users ALTER COLUMN id SET DEFAULT nextval('public.app_users_id_seq'::regclass);


--
-- Name: auth_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens ALTER COLUMN id SET DEFAULT nextval('public.auth_tokens_id_seq'::regclass);


--
-- Name: decision_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_records ALTER COLUMN id SET DEFAULT nextval('public.decision_records_id_seq'::regclass);


--
-- Name: decision_reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_reviews ALTER COLUMN id SET DEFAULT nextval('public.decision_reviews_id_seq'::regclass);


--
-- Name: decision_revisions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_revisions ALTER COLUMN id SET DEFAULT nextval('public.decision_revisions_id_seq'::regclass);


--
-- Name: holdings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings ALTER COLUMN id SET DEFAULT nextval('public.holdings_id_seq'::regclass);


--
-- Name: investment_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts ALTER COLUMN id SET DEFAULT nextval('public.investment_accounts_id_seq'::regclass);


--
-- Name: investment_decision_alerts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decision_alerts ALTER COLUMN id SET DEFAULT nextval('public.investment_decision_alerts_id_seq'::regclass);


--
-- Name: investment_decision_edits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decision_edits ALTER COLUMN id SET DEFAULT nextval('public.investment_decision_edits_id_seq'::regclass);


--
-- Name: investment_decisions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decisions ALTER COLUMN id SET DEFAULT nextval('public.investment_decisions_id_seq'::regclass);


--
-- Name: public_profiles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_profiles ALTER COLUMN id SET DEFAULT nextval('public.public_profiles_id_seq'::regclass);


--
-- Name: strategy_portfolios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_portfolios ALTER COLUMN id SET DEFAULT nextval('public.strategy_portfolios_id_seq'::regclass);


--
-- Name: strategy_tracked_symbols id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_tracked_symbols ALTER COLUMN id SET DEFAULT nextval('public.strategy_tracked_symbols_id_seq'::regclass);


--
-- Name: strategy_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_transactions ALTER COLUMN id SET DEFAULT nextval('public.strategy_transactions_id_seq'::regclass);


--
-- Data for Name: app_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_users (id, created_at, password_hash, username) FROM stdin;
\.


--
-- Data for Name: auth_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_tokens (id, created_at, token, user_id) FROM stdin;
\.


--
-- Data for Name: decision_record_evidence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_record_evidence (decision_record_id, evidence) FROM stdin;
\.


--
-- Data for Name: decision_record_exit_criteria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_record_exit_criteria (decision_record_id, exit_criterion) FROM stdin;
\.


--
-- Data for Name: decision_record_risk_factors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_record_risk_factors (decision_record_id, risk_factor) FROM stdin;
\.


--
-- Data for Name: decision_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_records (id, activated_at, confidence, created_at, decision_type, owner_id, status, thesis, ticker, time_horizon, title, updated_at, visibility) FROM stdin;
\.


--
-- Data for Name: decision_review_lessons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_review_lessons (decision_review_id, lesson) FROM stdin;
\.


--
-- Data for Name: decision_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_reviews (id, completed_at, created_at, due_date, next_action, outcome_summary, owner_id, review_type, risk_assessment_accuracy, status, thesis_accuracy, decision_record_id) FROM stdin;
\.


--
-- Data for Name: decision_revision_evidence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_revision_evidence (decision_revision_id, evidence) FROM stdin;
\.


--
-- Data for Name: decision_revision_exit_criteria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_revision_exit_criteria (decision_revision_id, exit_criterion) FROM stdin;
\.


--
-- Data for Name: decision_revision_risk_factors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_revision_risk_factors (decision_revision_id, risk_factor) FROM stdin;
\.


--
-- Data for Name: decision_revisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.decision_revisions (id, confidence, created_at, revision_number, thesis, time_horizon, title, decision_record_id) FROM stdin;
\.


--
-- Data for Name: holdings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.holdings (id, cost_basis, created_at, manual_price, purchase_date, shares, symbol, account_id) FROM stdin;
\.


--
-- Data for Name: investment_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_accounts (id, account_type, created_at, name, owner_id) FROM stdin;
\.


--
-- Data for Name: investment_decision_alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_decision_alerts (id, condition_type, condition_value, description, status, triggered_at, triggered_price, decision_id) FROM stdin;
\.


--
-- Data for Name: investment_decision_edits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_decision_edits (id, edited_at, field_name, new_value, old_value, decision_id) FROM stdin;
\.


--
-- Data for Name: investment_decisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_decisions (id, action, closed_at, comments, created_at, evidence, exit_pnl, exit_price, price, quantity, risks, source, status, symbol, thesis, title, transaction_date, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: public_profile_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.public_profile_metrics (profile_id, metric_id) FROM stdin;
\.


--
-- Data for Name: public_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.public_profiles (id, bio, created_at, display_name, handle, owner_id, updated_at) FROM stdin;
\.


--
-- Data for Name: strategy_portfolios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strategy_portfolios (id, created_at, description, name, owner_id, starting_capital, visibility) FROM stdin;
\.


--
-- Data for Name: strategy_symbol_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strategy_symbol_tags (tracked_symbol_id, tag) FROM stdin;
\.


--
-- Data for Name: strategy_tracked_symbols; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strategy_tracked_symbols (id, created_at, note, symbol, visibility, strategy_id) FROM stdin;
\.


--
-- Data for Name: strategy_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strategy_transactions (id, created_at, decision_id, executed_at, price, quantity, side, symbol, strategy_id) FROM stdin;
\.


--
-- Name: app_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.app_users_id_seq', 1, false);


--
-- Name: auth_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_tokens_id_seq', 1, false);


--
-- Name: decision_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.decision_records_id_seq', 1, false);


--
-- Name: decision_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.decision_reviews_id_seq', 1, false);


--
-- Name: decision_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.decision_revisions_id_seq', 1, false);


--
-- Name: holdings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.holdings_id_seq', 1, false);


--
-- Name: investment_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investment_accounts_id_seq', 1, false);


--
-- Name: investment_decision_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investment_decision_alerts_id_seq', 1, false);


--
-- Name: investment_decision_edits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investment_decision_edits_id_seq', 1, false);


--
-- Name: investment_decisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investment_decisions_id_seq', 1, false);


--
-- Name: public_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.public_profiles_id_seq', 1, false);


--
-- Name: strategy_portfolios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strategy_portfolios_id_seq', 1, false);


--
-- Name: strategy_tracked_symbols_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strategy_tracked_symbols_id_seq', 1, false);


--
-- Name: strategy_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strategy_transactions_id_seq', 1, false);


--
-- Name: app_users app_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT app_users_pkey PRIMARY KEY (id);


--
-- Name: auth_tokens auth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT auth_tokens_pkey PRIMARY KEY (id);


--
-- Name: decision_records decision_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_records
    ADD CONSTRAINT decision_records_pkey PRIMARY KEY (id);


--
-- Name: decision_reviews decision_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_reviews
    ADD CONSTRAINT decision_reviews_pkey PRIMARY KEY (id);


--
-- Name: decision_revisions decision_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_revisions
    ADD CONSTRAINT decision_revisions_pkey PRIMARY KEY (id);


--
-- Name: holdings holdings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings
    ADD CONSTRAINT holdings_pkey PRIMARY KEY (id);


--
-- Name: investment_accounts investment_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts
    ADD CONSTRAINT investment_accounts_pkey PRIMARY KEY (id);


--
-- Name: investment_decision_alerts investment_decision_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decision_alerts
    ADD CONSTRAINT investment_decision_alerts_pkey PRIMARY KEY (id);


--
-- Name: investment_decision_edits investment_decision_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decision_edits
    ADD CONSTRAINT investment_decision_edits_pkey PRIMARY KEY (id);


--
-- Name: investment_decisions investment_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decisions
    ADD CONSTRAINT investment_decisions_pkey PRIMARY KEY (id);


--
-- Name: public_profiles public_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_profiles
    ADD CONSTRAINT public_profiles_pkey PRIMARY KEY (id);


--
-- Name: strategy_portfolios strategy_portfolios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_portfolios
    ADD CONSTRAINT strategy_portfolios_pkey PRIMARY KEY (id);


--
-- Name: strategy_tracked_symbols strategy_tracked_symbols_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_tracked_symbols
    ADD CONSTRAINT strategy_tracked_symbols_pkey PRIMARY KEY (id);


--
-- Name: strategy_transactions strategy_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_transactions
    ADD CONSTRAINT strategy_transactions_pkey PRIMARY KEY (id);


--
-- Name: investment_decisions uk45l5bnoax9i46uvsh5ipd707w; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decisions
    ADD CONSTRAINT uk45l5bnoax9i46uvsh5ipd707w UNIQUE (user_id, symbol, transaction_date, action, quantity, price);


--
-- Name: public_profiles uk4e1v812yadgfx9u3mu8uhvp70; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_profiles
    ADD CONSTRAINT uk4e1v812yadgfx9u3mu8uhvp70 UNIQUE (owner_id);


--
-- Name: decision_reviews uk539lmrmfrbsjkcaaxewe5c5o6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_reviews
    ADD CONSTRAINT uk539lmrmfrbsjkcaaxewe5c5o6 UNIQUE (decision_record_id, review_type);


--
-- Name: strategy_tracked_symbols uk7oracrh6sq60hrvcu5r5w95ww; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_tracked_symbols
    ADD CONSTRAINT uk7oracrh6sq60hrvcu5r5w95ww UNIQUE (strategy_id, symbol);


--
-- Name: auth_tokens uk8eqyhmaqeqakfjut8vpdfm6cr; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT uk8eqyhmaqeqakfjut8vpdfm6cr UNIQUE (token);


--
-- Name: holdings ukbvkxotcxtq9rvkjhf3sa6eipw; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings
    ADD CONSTRAINT ukbvkxotcxtq9rvkjhf3sa6eipw UNIQUE (account_id, symbol);


--
-- Name: investment_accounts ukk46ki5va9juubc0c0tr20ueiq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_accounts
    ADD CONSTRAINT ukk46ki5va9juubc0c0tr20ueiq UNIQUE (owner_id, name);


--
-- Name: public_profiles ukmspf2dy4l9gt0jc3jmu5o8v4r; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_profiles
    ADD CONSTRAINT ukmspf2dy4l9gt0jc3jmu5o8v4r UNIQUE (handle);


--
-- Name: app_users ukspsnwr241e9k9c8p5xl4k45ih; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_users
    ADD CONSTRAINT ukspsnwr241e9k9c8p5xl4k45ih UNIQUE (username);


--
-- Name: investment_decision_edits fk19lm0yooxij8vo6lbpfbx68bj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decision_edits
    ADD CONSTRAINT fk19lm0yooxij8vo6lbpfbx68bj FOREIGN KEY (decision_id) REFERENCES public.investment_decisions(id);


--
-- Name: decision_revision_evidence fk1xjgoxfrqcqf3swg0pxmffxt4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_revision_evidence
    ADD CONSTRAINT fk1xjgoxfrqcqf3swg0pxmffxt4 FOREIGN KEY (decision_revision_id) REFERENCES public.decision_revisions(id);


--
-- Name: decision_revision_exit_criteria fk3yxl2lj4hffybmjciuukk3nam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_revision_exit_criteria
    ADD CONSTRAINT fk3yxl2lj4hffybmjciuukk3nam FOREIGN KEY (decision_revision_id) REFERENCES public.decision_revisions(id);


--
-- Name: holdings fk7x4wntxltl9mav4brmp73o402; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.holdings
    ADD CONSTRAINT fk7x4wntxltl9mav4brmp73o402 FOREIGN KEY (account_id) REFERENCES public.investment_accounts(id);


--
-- Name: investment_decision_alerts fk8hysr7qlmf5b9rp06hgjjp9a2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_decision_alerts
    ADD CONSTRAINT fk8hysr7qlmf5b9rp06hgjjp9a2 FOREIGN KEY (decision_id) REFERENCES public.investment_decisions(id);


--
-- Name: strategy_symbol_tags fkfd4o2ppdyw74kjf6nmanpo7vh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_symbol_tags
    ADD CONSTRAINT fkfd4o2ppdyw74kjf6nmanpo7vh FOREIGN KEY (tracked_symbol_id) REFERENCES public.strategy_tracked_symbols(id);


--
-- Name: decision_record_exit_criteria fkgfu7rvwtyagrqsfvbnso9sbdy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_record_exit_criteria
    ADD CONSTRAINT fkgfu7rvwtyagrqsfvbnso9sbdy FOREIGN KEY (decision_record_id) REFERENCES public.decision_records(id);


--
-- Name: decision_revision_risk_factors fkhywm9356aciqnh2178p8djp1b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_revision_risk_factors
    ADD CONSTRAINT fkhywm9356aciqnh2178p8djp1b FOREIGN KEY (decision_revision_id) REFERENCES public.decision_revisions(id);


--
-- Name: decision_record_evidence fkjhgydokxaa0y45pyg4p6x6xo4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_record_evidence
    ADD CONSTRAINT fkjhgydokxaa0y45pyg4p6x6xo4 FOREIGN KEY (decision_record_id) REFERENCES public.decision_records(id);


--
-- Name: decision_record_risk_factors fkk0m6ofhx5hndtkw1sjcncennh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_record_risk_factors
    ADD CONSTRAINT fkk0m6ofhx5hndtkw1sjcncennh FOREIGN KEY (decision_record_id) REFERENCES public.decision_records(id);


--
-- Name: strategy_tracked_symbols fkk34sk08bbnan61m750um4nbq6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_tracked_symbols
    ADD CONSTRAINT fkk34sk08bbnan61m750um4nbq6 FOREIGN KEY (strategy_id) REFERENCES public.strategy_portfolios(id);


--
-- Name: public_profile_metrics fkkutl2gu0vvsfoi42ghemwfa58; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.public_profile_metrics
    ADD CONSTRAINT fkkutl2gu0vvsfoi42ghemwfa58 FOREIGN KEY (profile_id) REFERENCES public.public_profiles(id);


--
-- Name: strategy_transactions fklf34cfr745ju6i97o20aoqmyk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strategy_transactions
    ADD CONSTRAINT fklf34cfr745ju6i97o20aoqmyk FOREIGN KEY (strategy_id) REFERENCES public.strategy_portfolios(id);


--
-- Name: decision_reviews fklfscfx69re06j87sjnc5qwx8y; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_reviews
    ADD CONSTRAINT fklfscfx69re06j87sjnc5qwx8y FOREIGN KEY (decision_record_id) REFERENCES public.decision_records(id);


--
-- Name: auth_tokens fknrsj4bkjx1hc58vcx4gikdiqk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_tokens
    ADD CONSTRAINT fknrsj4bkjx1hc58vcx4gikdiqk FOREIGN KEY (user_id) REFERENCES public.app_users(id);


--
-- Name: decision_revisions fkqnyo0d2of9sdvbf3imwngomo6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_revisions
    ADD CONSTRAINT fkqnyo0d2of9sdvbf3imwngomo6 FOREIGN KEY (decision_record_id) REFERENCES public.decision_records(id);


--
-- Name: decision_review_lessons fktmr07soioshfej1ye11ms90x2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.decision_review_lessons
    ADD CONSTRAINT fktmr07soioshfej1ye11ms90x2 FOREIGN KEY (decision_review_id) REFERENCES public.decision_reviews(id);


--
-- PostgreSQL database dump complete
--

\unrestrict m8PjIUoR8pVctgVXbsPhN6PlPgjdR3PeL0Ucf3Wk9XXz3UypJHi6RxeAFUpGU0y

